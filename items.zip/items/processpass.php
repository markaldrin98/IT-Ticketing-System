<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  

if(checkPost('Submit')){

}
else{
    redirect('index.php');
}

$username = callUsername();
$oldpass = checkPost('oldpass');
$newpass1 = checkPost('newpass');
$newpass2 = checkPost('confirmpass');
$tech_details = getTechDetails(callUsername());

if(($oldpass==$tech_details['password']) && $newpass1===$newpass2){//if posted password matches stored password && the two posted new passwords match, run this clause // <- second conditional shouldn't be necessary, because script in changepass.php prevents submission when the two don't match
    $queryString = 'UPDATE tech_credentials SET password = "'.escapeString($newpass1).'" WHERE username="'.$username.'"'; 
    if (mysqli_query($conn, $queryString)) { 
        redirect(checkPost('trail')."?attempt=success");//password successfully updated, return to previous page
    } 
    else {  
        checkSQLError();
    } 
}
else{//>password provided doesn't match stored password<-probably this || newpass1 doesn't match newpass2
    redirect(checkPost('trail')."?attempt=failed");
}

?>

