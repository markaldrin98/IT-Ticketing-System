-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 27, 2019 at 09:48 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testticketdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `tech_credentials`
--

CREATE TABLE IF NOT EXISTS `tech_credentials` (
  `employee_name` text NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `current_ticket` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech_credentials`
--

INSERT INTO `tech_credentials` (`employee_name`, `user_type`, `username`, `password`, `current_ticket`) VALUES
('Rizza Joy Batuyong', 'admin', 'ririjoy', 'password', NULL),
('tech1', 'tech', 'tech1username', 'password', '190508-017'),
('tech2', 'tech', 'tech2username', 'password', '190508-019'),
('tech3', 'tech', 'tech3username', 'password', '190523-003');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
