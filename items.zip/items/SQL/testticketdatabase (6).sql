-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 22, 2019 at 10:56 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `testticketdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `field_values`
--

CREATE TABLE IF NOT EXISTS `field_values` (
  `field` text NOT NULL,
  `value` text NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field_values`
--

INSERT INTO `field_values` (`field`, `value`, `details`) VALUES
('office', 'Accounting', ''),
('office', 'CAO', ''),
('office', 'BAC', ''),
('office', 'BGY Sec', ''),
('office', 'BPLO', ''),
('office', 'Budget', ''),
('office', 'BA', ''),
('office', 'CADAO', ''),
('office', 'CATO', ''),
('office', 'CCDRRMO', ''),
('office', 'CCMC', ''),
('office', 'CCMNC', ''),
('office', 'CCSWD', ''),
('office', 'CEMD', ''),
('office', 'City Admin', ''),
('office', 'COA', ''),
('office', 'CRD', ''),
('office', 'CRO', ''),
('office', 'CSC', ''),
('office', 'CTO', ''),
('office', 'DILG', ''),
('office', 'Eng', ''),
('office', 'GAD', ''),
('office', 'GSO', ''),
('office', 'Health', ''),
('office', 'HRMO', ''),
('office', 'IAS', ''),
('office', 'IT', ''),
('office', 'IT North', ''),
('office', 'Landtax', ''),
('office', 'Legal', ''),
('office', 'LEIPO', ''),
('office', 'License', ''),
('office', 'LIRO', ''),
('office', 'LIGA', ''),
('office', 'MO', ''),
('office', 'Negosyo Center', ''),
('office', 'OCBO', ''),
('office', 'OSCA', ''),
('office', 'OSEC', ''),
('office', 'Parks', ''),
('office', 'PIO', ''),
('office', 'Planning', ''),
('office', 'PLEB', ''),
('office', 'pub', ''),
('office', 'PWD', ''),
('office', 'Sangunian', ''),
('office', 'Sports', ''),
('office', 'Upao', ''),
('office', 'Vet', ''),
('office', 'OLUZA', ''),
('office', 'VM', ''),
('job_description', 'Service', ''),
('job_description', 'VR', ''),
('job_description', 'Configuration', ''),
('job_description', 'Research', ''),
('job_description', 'Paperwork', ''),
('job_description', 'Communication', ''),
('job_description', 'Registration', ''),
('job_description', 'Connection', ''),
('job_description', 'Setup', ''),
('job_description', 'Install', ''),
('job_description', 'Digital Editing', ''),
('job_description', 'Training', ''),
('concern', 'Connection - Internet', 'connecting to the internet'),
('concern', 'Connection - System', 'connecting to your local system'),
('concern', 'Connection - Network', 'connecting to the local network'),
('concern', 'Data Issues', 'missing, invalid, or deprecated data within internal applications'),
('concern', 'Data or Storage Device', 'backups, recovery, and storage media'),
('concern', 'Equipment - Computer', 'desktops, laptops, and their respective components'),
('concern', 'Equipment - Mobile Device', 'mobile devices such as smartphones or tablets'),
('concern', 'Equipment - Other', 'equipment not listed above- such as printers, projectors, scanners, or biometric devices'),
('concern', 'Software', 'your operating system or external applications such as MS Office and VM'),
('concern', 'System Issues', 'internal programs not working properly'),
('concern', 'Others', 'issues not listed above'),
('assessment', 'AV', ''),
('assessment', 'App', ''),
('assessment', 'Biometrics', ''),
('assessment', 'Laptop', ''),
('assessment', 'Backup', ''),
('assessment', 'Desktop', ''),
('assessment', 'CPU', ''),
('assessment', 'Layout', ''),
('assessment', 'Monitor', ''),
('assessment', 'Mouse', ''),
('assessment', 'Keyboard', ''),
('assessment', 'Printer', ''),
('assessment', 'Scanner', ''),
('assessment', 'AVR', ''),
('assessment', 'UPS', ''),
('assessment', 'Power', ''),
('assessment', 'Projector', ''),
('assessment', 'Photo', ''),
('assessment', 'Recovery', ''),
('assessment', 'Removable Device', ''),
('assessment', 'Mobile Device', ''),
('assessment', 'Network', ''),
('assessment', 'Internet', ''),
('assessment', 'internet filter', ''),
('assessment', 'Wifi', ''),
('assessment', 'Lined', ''),
('assessment', 'System', ''),
('assessment', 'SmartQ', ''),
('assessment', 'Server', ''),
('assessment', 'AD', ''),
('assessment', 'OS', ''),
('assessment', 'MS Office', ''),
('assessment', 'ID Signature', ''),
('assessment', 'VM', ''),
('assessment', 'LR', ''),
('assessment', 'Inventory', ''),
('assessment', 'Documentation', ''),
('assessment', 'Supply Run', ''),
('assessment', 'Others', ''),
('assessment', 'OR Error', ''),
('assessment', 'RunTime Error', ''),
('assessment', 'Date Error', ''),
('assessment', 'No Data Reflect', ''),
('assessment', 'Update Data', ''),
('assessment', 'Data Error', ''),
('assessment', 'System Issue', ''),
('status', 'Open', ''),
('status', 'Ongoing', ''),
('status', 'Completed', ''),
('status', 'Escalated', ''),
('status', 'Not Serviced', ''),
('participation', 'Supervised', ''),
('participation', 'Training', ''),
('participation', 'Performed', ''),
('participation', 'Consultation', '');

-- --------------------------------------------------------

--
-- Table structure for table `tech_credentials`
--

CREATE TABLE IF NOT EXISTS `tech_credentials` (
  `employee_name` text NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `current_ticket` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech_credentials`
--

INSERT INTO `tech_credentials` (`employee_name`, `user_type`, `username`, `password`, `current_ticket`) VALUES
('Rizza Joy Batuyong', 'admin', 'ririjoy', 'password', NULL),
('tech1', 'tech', 'tech1username', 'password', '190508-011'),
('tech2', 'tech', 'tech2username', 'password', '190508-019'),
('tech3', 'tech', 'tech3username', 'password', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `testcboxdata`
--

CREATE TABLE IF NOT EXISTS `testcboxdata` (
  `ticket_id` varchar(12) NOT NULL,
  `chat_log` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testcboxdata`
--

INSERT INTO `testcboxdata` (`ticket_id`, `chat_log`) VALUES
('190509-001', 'tech1<05/09/19 12:20>: lutang yung user<delimiter>admin1<05/09/19 12:21>: yeh, alien talaga yan'),
('190509-002', 'tech1<05/09/19 12:30>: lutang din yung user na to-:-admin1<05/09/19 12:33>: okay, noted din. balik ka nalang dito');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE IF NOT EXISTS `tickets` (
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_accepted` datetime DEFAULT NULL,
  `date_assessed` timestamp NULL DEFAULT NULL,
  `date_fulfilled` datetime DEFAULT NULL,
  `ticket_id` varchar(15) NOT NULL,
  `office` text,
  `client_name` text,
  `employee_number` int(11) DEFAULT NULL,
  `concern` text,
  `concern_details` text NOT NULL,
  `assessment` text NOT NULL,
  `job_description` text,
  `job_details` text NOT NULL,
  `participation` text,
  `approval_status` text,
  `respondent` text,
  `job_status` text,
  `remarks` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`date_created`, `date_accepted`, `date_assessed`, `date_fulfilled`, `ticket_id`, `office`, `client_name`, `employee_number`, `concern`, `concern_details`, `assessment`, `job_description`, `job_details`, `participation`, `approval_status`, `respondent`, `job_status`, `remarks`) VALUES
('2019-04-25 10:28:54', '2019-04-30 10:42:45', NULL, '2019-04-30 12:59:25', '190425-001', 'LVEE', 'Eman', 44554, 'Burning Tower', '', '', '', '', '', 'Approved', 'tech2', 'Ongoing', ''),
('2019-04-25 14:50:10', '2019-04-30 10:15:35', NULL, '2019-04-30 10:42:38', '190425-002', 'MTHD', 'Markyy', 4478, 'Random beeping noises coming from CPU', '', '', NULL, '', NULL, 'Not Approved', 'tech2', 'Open', NULL),
('2019-04-26 14:51:15', '2019-04-29 12:57:14', NULL, NULL, '190426-001', 'HR', 'Eman', 444, 'Umuusok yung mouse', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-04-29 14:23:33', '2019-04-29 16:53:36', NULL, NULL, '190429-001', 'ITS', 'Eman', 445544, 'Umuusok yung tower', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-04-29 14:24:17', '2019-04-30 08:52:47', NULL, '2019-04-30 08:57:01', '190429-002', 'ITS', 'Marky', 4444, 'May syotaan dito', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-05-08 13:55:32', NULL, NULL, '2019-05-20 15:57:59', '190508-001', 'ITDO', 'Riri', 554, 'Noone believes me', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 13:59:28', NULL, NULL, '2019-05-20 15:57:59', '190508-002', 'ITDO', 'Kay', 998, 'Nangangagat yung laptop', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:15:53', NULL, NULL, '2019-05-20 15:57:59', '190508-003', 'MI6', 'James', 7, 'Malfunctioning headset', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:17:57', NULL, NULL, '2019-05-20 15:57:59', '190508-004', 'ccrp', 'red', 9, 'jet boots not working', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:19:29', NULL, NULL, '2019-05-20 15:57:59', '190508-005', 'FAD', 'Lili', 23, 'No internet', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:20:27', NULL, NULL, '2019-05-20 15:57:59', '190508-006', 'CCRP', 'Chun', 909, 'Filesharing)', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:23:47', NULL, NULL, '2019-05-20 15:57:59', '190508-007', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:24:42', '2019-05-20 15:23:29', NULL, '2019-05-20 15:57:59', '190508-008', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-05-08 14:26:18', NULL, NULL, '2019-05-20 15:57:59', '190508-009', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:31:28', NULL, NULL, '2019-05-20 15:57:59', '190508-010', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:32:08', '2019-05-22 15:32:28', NULL, '2019-05-20 15:57:59', '190508-011', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-05-08 14:35:18', '2019-05-20 15:04:03', NULL, '2019-05-20 15:57:59', '190508-012', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-05-08 14:35:44', '2019-05-17 13:51:05', NULL, '2019-05-20 15:57:59', '190508-013', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech2', 'Open', NULL),
('2019-05-08 14:38:23', '2019-05-20 15:38:13', NULL, '2019-05-20 15:57:59', '190508-014', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-05-08 14:38:48', '2019-05-17 13:51:53', NULL, '2019-05-20 15:57:59', '190508-015', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech2', 'Open', NULL),
('2019-05-08 14:39:23', '2019-05-17 14:07:20', NULL, '2019-05-20 15:57:59', '190508-016', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-05-08 14:41:16', NULL, NULL, '2019-05-20 15:57:59', '190508-017', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:43:09', '2019-05-20 10:09:51', NULL, '2019-05-20 15:57:59', '190508-018', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', '', 'Open', NULL),
('2019-05-08 14:47:21', '2019-05-17 13:58:56', NULL, '2019-05-20 15:57:59', '190508-019', 'ITSS', 'Jo', 9999333, 'Nag-away ng mag-asawa', '', '', NULL, '', NULL, 'Not Approved', 'tech2', 'Open', NULL),
('2019-05-08 14:54:47', NULL, NULL, '2019-05-20 15:57:59', '190508-020', 'RDR', 'Norah', 233, 'Need extra keyboard', '', '', NULL, '', NULL, 'Approved', 'tech1', 'Open', NULL),
('2019-05-09 10:22:44', '2019-05-20 15:47:54', NULL, NULL, '190509-001', 'CEMD', 'Eman', 34567, 'Beeping desktop', '', '', NULL, 'ljjhgvhhjoihggcgv rrfddfdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', NULL, 'Not Approved', 'tech1', 'Ongoing', 'Rizza Joy Batuyong<2019-05-22 09:54:06>:Isn''t it nice to say ''I love you''?-:-Rizza Joy Batuyong<2019-05-22 09:54:24>:Isn''t it nice to say ''I love you''?-:-Rizza Joy Batuyong<2019-05-22 11:37:24>:asd-:-');

-- --------------------------------------------------------

--
-- Table structure for table `ticket_changelog`
--

CREATE TABLE IF NOT EXISTS `ticket_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `ticket` varchar(15) NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_changelog`
--

INSERT INTO `ticket_changelog` (`log_number`, `date_time_logged`, `admin`, `ticket`, `change_made`) VALUES
(1, '2019-04-25 07:18:33', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEEE to LVE'),
(2, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', '1', 'Changed Client Name from  to '),
(3, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', '2', 'Changed Client Name from  to '),
(4, '2019-04-25 08:08:58', 'Rizza Joy Batuyong', '1', 'Changed Client Name from Eman to '),
(5, '2019-04-25 08:09:21', 'Rizza Joy Batuyong', '1', 'Changed Client Name from Mmmmmmmmmmm to '),
(6, '2019-04-25 08:13:44', 'Rizza Joy Batuyong', '1', 'Changed Office from LVE to LVEE'),
(7, '2019-04-25 08:13:50', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEE to LVEEE'),
(8, '2019-04-25 08:13:57', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEEE to '),
(9, '2019-04-25 08:14:02', 'Rizza Joy Batuyong', '1', 'Changed Office from  to LVEE'),
(10, '2019-04-25 08:17:37', 'Rizza Joy Batuyong', '1', 'Changed Client Name from  to Emann'),
(11, '2019-04-25 08:17:59', 'Rizza Joy Batuyong', '2', 'Changed Client Name from  to Marky'),
(12, '2019-04-25 08:18:15', 'Rizza Joy Batuyong', '2', 'Changed Client Name from Marky to Markyy'),
(13, '2019-04-25 08:27:56', 'Rizza Joy Batuyong', '1', 'Changed client_name from Emann to Eman'),
(14, '2019-04-25 08:27:56', '', '1', 'Changed job_description from  to Keme'),
(15, '2019-04-25 08:27:57', '', '1', 'Changed participation from  to Keme din'),
(16, '2019-04-25 08:28:29', '', '1', 'Changed approval_status from Not Approved to Approved'),
(17, '2019-04-25 08:28:29', '', '1', 'Changed respondent from  to tech1'),
(18, '2019-04-25 08:28:29', '', '1', 'Changed job_status from  to Accepted'),
(19, '2019-04-25 08:28:30', '', '1', 'Changed remarks from  to asd'),
(20, '2019-04-25 08:29:04', '', '1', 'Changed remarks from asd to '),
(21, '2019-04-26 02:57:52', '', '1', 'Changed respondent from tech1 to tech2'),
(22, '2019-04-26 02:57:52', '', '2', 'Changed respondent from  to tech1'),
(23, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed client_name from  to '),
(24, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed job_description from  to '),
(25, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed participation from  to '),
(26, '2019-05-08 02:05:00', 'Rizza Joy Batuyong', '1', 'Changed client_name from  to '),
(27, '2019-05-08 02:05:32', 'Rizza Joy Batuyong', '1', 'Changed employee_number from  to '),
(28, '2019-05-08 03:37:38', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(29, '2019-05-08 03:37:45', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(30, '2019-05-08 03:38:19', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(31, '2019-05-08 03:40:26', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(32, '2019-05-08 03:40:27', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(33, '2019-05-08 03:40:47', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from 445544 to 44554'),
(34, '2019-05-08 03:41:24', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emann'),
(35, '2019-05-08 03:41:33', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(36, '2019-05-08 03:43:27', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(37, '2019-05-08 03:44:00', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(38, '2019-05-08 03:44:21', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(39, '2019-05-08 06:15:53', 'James', '190505', 'Ticket 190508-003 created with the following parameters: 7,James,MI6,Malfunctioning headset'),
(40, '2019-05-08 06:17:57', 'red', '190504', 'Ticket 190508-004 created with the following parameters: 9,red,ccrp,jet boots not working'),
(41, '2019-05-08 06:19:30', 'Lili', '190503', 'Ticket 190508-005 created with the following parameters: 23,Lili,FAD,No internet'),
(42, '2019-05-08 06:20:27', 'Chun', '190502', 'Ticket 190508-006 created with the following parameters: 909,Chun,CCRP,Filesharing)'),
(43, '2019-05-08 06:23:47', 'Jo', '190501', ''),
(44, '2019-05-08 06:24:42', 'Jo', '190500', 'Ticket 190508-008 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(45, '2019-05-08 06:26:18', 'Jo', '190508-009', 'Ticket 190508-009 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(46, '2019-05-08 06:31:28', 'Jo', '190508-010', 'Ticket 190508-010 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(47, '2019-05-08 06:32:09', 'Jo', '190508-011', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(48, '2019-05-08 06:35:18', 'Jo', '190508-012', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(49, '2019-05-08 06:35:44', 'Jo', '190508-013', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(50, '2019-05-08 06:38:23', 'Jo', '190508-014', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(51, '2019-05-08 06:38:48', 'Jo', '190508-015', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(52, '2019-05-08 06:39:23', 'Jo', '190508-016', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(53, '2019-05-08 06:41:16', 'Jo', '190508-017', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(54, '2019-05-08 06:43:09', 'Jo', '190508-018', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(55, '2019-05-08 06:45:37', 'Jo', '190508-018', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(56, '2019-05-08 06:47:21', 'Jo', '190508-019', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(57, '2019-05-08 06:54:47', 'Norah', '190508-020', 'Ticket created with the following parameters: 233,Norah,RDR,Need extra keyboard'),
(58, '2019-05-08 08:59:14', 'Rizza Joy Batuyong', '190508-020', 'Changed approval_status from Not Approved to Approved'),
(59, '2019-05-08 08:59:14', 'Rizza Joy Batuyong', '190508-020', 'Changed respondent from empty to tech1'),
(60, '2019-05-09 02:22:44', 'Eman', '190509-001', 'Ticket created with the following parameters: 34567,Eman,ITDO,Beeping desktop');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`), ADD KEY `ticket_id` (`ticket_id`), ADD KEY `ticket_id_2` (`ticket_id`), ADD KEY `ticket_id_3` (`ticket_id`);

--
-- Indexes for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
