-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2019 at 11:12 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testticketdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `device_changelog`
--

CREATE TABLE `device_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `device_id` varchar(15) NOT NULL,
  `admin` text NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_changelog`
--

INSERT INTO `device_changelog` (`log_number`, `date_time_logged`, `device_id`, `admin`, `change_made`) VALUES
(1, '2019-06-25 06:33:01', 'DT-201900010', 'tech3', 'Registered new'),
(2, '2019-06-25 06:34:02', 'DT-201900010', 'tech3', 'Registered new'),
(3, '2019-06-30 16:20:14', 'TB-201900002', 'tech1', 'Registered new peripheral: Monitor - Benq 17 inches'),
(4, '2019-07-05 06:31:30', 'LT-201900005', 'Rizza Joy Batuyong', 'Device registered - Laptop belonging to Mark at IT.'),
(5, '2019-07-05 06:44:05', 'LT-201900006', 'Jeremy Villanueva', 'Device registered - Laptop belonging to Dennis at CRD.'),
(6, '2019-07-05 06:50:33', 'LT-201900007', 'Jeremy Villanueva', 'Device registered - Laptop belonging to Blondie at CRD.'),
(7, '2019-07-05 06:54:31', 'MD-201900002', 'Jeremy Villanueva', 'Device registered - Mobile Device belonging to Baby at CRD.'),
(8, '2019-07-05 06:58:07', 'MD-201900003', 'Jeremy Villanueva', 'Device registered - Mobile Device belonging to Beatrix at CRD.'),
(9, '2019-07-05 07:00:33', 'MD-201900004', 'Jeremy Villanueva', 'Device registered - Mobile Device belonging to Bea at CRD.'),
(10, '2019-07-05 07:01:35', 'MD-201900005', 'Jeremy Villanueva', 'Device registered - Mobile Device belonging to Carol at CRD.'),
(11, '2019-07-05 07:02:22', 'MD-201900006', 'Jeremy Villanueva', 'Device registered - Mobile Device belonging to Carol at CRD.'),
(12, '2019-07-05 07:04:10', 'MD-201900007', 'Jeremy Villanueva', 'Device registered - Mobile Device belonging to Carol at CRD.'),
(13, '2019-07-05 08:48:57', 'MD-201900008', 'Roy Manuel', 'Device registered - Mobile Device belonging to Rose at CATO.'),
(14, '2019-07-05 08:49:47', 'LT-201900008', 'Roy Manuel', 'Device registered - Laptop belonging to Ririri at COA.');

-- --------------------------------------------------------

--
-- Table structure for table `device_list`
--

CREATE TABLE `device_list` (
  `device_id` varchar(15) NOT NULL,
  `device_type` text NOT NULL,
  `owner` text NOT NULL,
  `office` text NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_list`
--

INSERT INTO `device_list` (`device_id`, `device_type`, `owner`, `office`, `date_registered`) VALUES
('DT-201900001', 'Desktop', 'Mark', 'IT', '2019-06-20 22:42:59'),
('DT-201900002', 'Desktop', 'Kyle', 'CEMD', '2019-06-29 12:22:03'),
('LT-201900001', 'Laptop', 'Marky Mark', 'IT', '2019-06-02 21:10:30'),
('LT-201900002', 'Laptop', 'Kala DS', 'IT', '2019-06-06 23:49:08'),
('LT-201900003', 'Laptop', 'Eriri', 'City Admin', '2019-06-25 02:42:18'),
('LT-201900004', 'Laptop', 'Eriri', 'City Admin', '2019-06-25 02:43:11'),
('LT-201900005', 'Laptop', 'Mark', 'IT', '2019-07-05 00:31:30'),
('LT-201900006', 'Laptop', 'Dennis', 'CRD', '2019-07-05 00:44:05'),
('LT-201900007', 'Laptop', 'Blondie', 'CRD', '2019-07-05 00:50:33'),
('LT-201900008', 'Laptop', 'Ririri', 'COA', '2019-07-05 02:49:47'),
('MD-201900001', 'Mobile Device', 'Eriri', 'City Admin', '2019-06-03 00:05:09'),
('MD-201900002', 'Mobile Device', 'Baby', 'CRD', '2019-07-05 00:54:31'),
('MD-201900003', 'Mobile Device', 'Beatrix', 'CRD', '2019-07-05 00:58:07'),
('MD-201900004', 'Mobile Device', 'Bea', 'CRD', '2019-07-05 01:00:33'),
('MD-201900005', 'Mobile Device', 'Carol', 'CRD', '2019-07-05 01:01:35'),
('MD-201900006', 'Mobile Device', 'Carol', 'CRD', '2019-07-05 01:02:22'),
('MD-201900007', 'Mobile Device', 'Carol', 'CRD', '2019-07-05 01:04:10'),
('MD-201900008', 'Mobile Device', 'Rose', 'CATO', '2019-07-05 02:48:56'),
('TB-201900001', 'Tablet', 'Marky Mark', 'BGY Sec', '2019-06-20 23:11:00'),
('TB-201900002', 'Tablet', 'Marky Mark', 'BGY Sec', '2019-06-20 23:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `device_parts_table`
--

CREATE TABLE `device_parts_table` (
  `device_id` varchar(15) NOT NULL,
  `peripheral` text NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_parts_table`
--

INSERT INTO `device_parts_table` (`device_id`, `peripheral`, `details`) VALUES
('LT-201900001', 'Processor', 'i7'),
('LT-201900001', 'Hard Drive', '1TB'),
('LT-201900001', 'Mouse', 'A4Tech'),
('LT-201900002', 'Mouse', 'A4 Tech'),
('LT-201900002', 'Keyboard', 'A4 Tech'),
('LT-201900002', 'Speaker', '300 Watts'),
('LT-201900002', 'X', 'YZ'),
('LT-201900002', 'X', 'YZ'),
('LT-201900002', 'PSU', '600 Watts'),
('TB-201900002', 'Monitor', 'Benq 17 inches');

-- --------------------------------------------------------

--
-- Table structure for table `device_service_history`
--

CREATE TABLE `device_service_history` (
  `device_id` varchar(15) NOT NULL,
  `ticket_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device_specs_table`
--

CREATE TABLE `device_specs_table` (
  `device_id` varchar(15) NOT NULL,
  `specification` text NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_specs_table`
--

INSERT INTO `device_specs_table` (`device_id`, `specification`, `details`) VALUES
('MD-201900001', 'RAM', '16GB'),
('LT-201900002', 'RAM', '8GB'),
('LT-201900002', 'Processor', 'i7 3.6GHz'),
('LT-201900002', 'Storage', '1TB');

-- --------------------------------------------------------

--
-- Table structure for table `field_values`
--

CREATE TABLE `field_values` (
  `field` text NOT NULL,
  `value` text NOT NULL,
  `details` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field_values`
--

INSERT INTO `field_values` (`field`, `value`, `details`) VALUES
('office', 'Accounting', ''),
('office', 'CAO', ''),
('office', 'BAC', ''),
('office', 'BGY Sec', ''),
('office', 'BPLO', ''),
('office', 'Budget', ''),
('office', 'BA', ''),
('office', 'CADAO', ''),
('office', 'CATO', ''),
('office', 'CCDRRMO', ''),
('office', 'CCMC', ''),
('office', 'CCMNC', ''),
('office', 'CCSWD', ''),
('office', 'CEMD', ''),
('office', 'City Admin', ''),
('office', 'COA', ''),
('office', 'CRD', ''),
('office', 'CRO', ''),
('office', 'CSC', ''),
('office', 'CTO', ''),
('office', 'DILG', ''),
('office', 'Eng', ''),
('office', 'GAD', ''),
('office', 'GSO', ''),
('office', 'Health', ''),
('office', 'HRMO', ''),
('office', 'IAS', ''),
('office', 'IT', ''),
('office', 'IT North', ''),
('office', 'Landtax', ''),
('office', 'Legal', ''),
('office', 'LEIPO', ''),
('office', 'License', ''),
('office', 'LIRO', ''),
('office', 'LIGA', ''),
('office', 'MO', ''),
('office', 'Negosyo Center', ''),
('office', 'OCBO', ''),
('office', 'OSCA', ''),
('office', 'OSEC', ''),
('office', 'Parks', ''),
('office', 'PIO', ''),
('office', 'Planning', ''),
('office', 'PLEB', ''),
('office', 'pub', ''),
('office', 'PWD', ''),
('office', 'Sangunian', ''),
('office', 'Sports', ''),
('office', 'Upao', ''),
('office', 'Vet', ''),
('office', 'OLUZA', ''),
('office', 'VM', ''),
('job_description', 'Service', ''),
('job_description', 'VR', ''),
('job_description', 'Configuration', ''),
('job_description', 'Research', ''),
('job_description', 'Paperwork', ''),
('job_description', 'Communication', ''),
('job_description', 'Registration', ''),
('job_description', 'Connection', ''),
('job_description', 'Setup', ''),
('job_description', 'Install', ''),
('job_description', 'Digital Editing', ''),
('job_description', 'Training', ''),
('concern', 'Connection - Internet', 'connecting to the internet'),
('concern', 'Connection - System', 'connecting to your local system'),
('concern', 'Connection - Network', 'connecting to the local network'),
('concern', 'Data Issues', 'missing, invalid, or deprecated data within internal applications'),
('concern', 'Data or Storage Device', 'backups, recovery, and storage media'),
('concern', 'Equipment - Computer', 'desktops, laptops, and their respective components'),
('concern', 'Equipment - Mobile Device', 'mobile devices such as smartphones or tablets'),
('concern', 'Equipment - Other', 'equipment not listed above- such as printers, projectors, scanners, or biometric devices'),
('concern', 'Software', 'your operating system or external applications such as MS Office and VM'),
('concern', 'System Issues', 'internal programs not working properly'),
('concern', 'Others', 'issues not listed above'),
('assessment', 'AV', ''),
('assessment', 'App', ''),
('assessment', 'Biometrics', ''),
('assessment', 'Laptop', ''),
('assessment', 'Backup', ''),
('assessment', 'Desktop', ''),
('assessment', 'CPU', ''),
('assessment', 'Layout', ''),
('assessment', 'Monitor', ''),
('assessment', 'Mouse', ''),
('assessment', 'Keyboard', ''),
('assessment', 'Printer', ''),
('assessment', 'Scanner', ''),
('assessment', 'AVR', ''),
('assessment', 'UPS', ''),
('assessment', 'Power', ''),
('assessment', 'Projector', ''),
('assessment', 'Photo', ''),
('assessment', 'Recovery', ''),
('assessment', 'Removable Device', ''),
('assessment', 'Mobile Device', ''),
('assessment', 'Network', ''),
('assessment', 'Internet', ''),
('assessment', 'internet filter', ''),
('assessment', 'Wifi', ''),
('assessment', 'Lined', ''),
('assessment', 'System', ''),
('assessment', 'SmartQ', ''),
('assessment', 'Server', ''),
('assessment', 'AD', ''),
('assessment', 'OS', ''),
('assessment', 'MS Office', ''),
('assessment', 'ID Signature', ''),
('assessment', 'VM', ''),
('assessment', 'LR', ''),
('assessment', 'Inventory', ''),
('assessment', 'Documentation', ''),
('assessment', 'Supply Run', ''),
('assessment', 'Others', ''),
('assessment', 'OR Error', ''),
('assessment', 'RunTime Error', ''),
('assessment', 'Date Error', ''),
('assessment', 'No Data Reflect', ''),
('assessment', 'Update Data', ''),
('assessment', 'Data Error', ''),
('assessment', 'System Issue', ''),
('status', 'Open', ''),
('status', 'Ongoing', ''),
('status', 'Resolved', ''),
('status', 'Escalated', ''),
('status', 'Not Serviced', ''),
('participation', 'Supervised', ''),
('participation', 'Training', ''),
('participation', 'Performed', ''),
('participation', 'Consultation', ''),
('device_type', 'Desktop', 'DT'),
('device_type', 'Laptop', 'LT'),
('device_type', 'Mobile Device', 'MD'),
('device_type', 'Tablet', 'TB'),
('device_type', 'Others', 'TH'),
('software', 'Windows OS', ''),
('software', 'MS Office', ''),
('software', 'Antivirus Software', ''),
('software', 'Adobe Photoshop/Creative Suite', ''),
('software', 'Others', ''),
('specification', 'Memory', ''),
('specification', 'Storage', ''),
('specification', 'Motherboard', ''),
('specification', 'Mac Address', ''),
('specification', 'IP Address', ''),
('specification', 'Processor', ''),
('specification', 'Video Card', ''),
('peripheral', 'Mouse', ''),
('peripheral', 'Keyboard', ''),
('peripheral', 'Speakers', ''),
('peripheral', 'Monitor', ''),
('peripheral', 'Web Camera', ''),
('status', 'Suspended', NULL),
('office', 'LANUZA', NULL),
('device_type', 'Biometrics', 'BM'),
('office', 'MARK', 'sample description'),
('office', 'XXA', NULL),
('concern', 'Equipment - Biometrics', 'biometric devices');

-- --------------------------------------------------------

--
-- Table structure for table `field_values_changelog`
--

CREATE TABLE `field_values_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field_values_changelog`
--

INSERT INTO `field_values_changelog` (`log_number`, `date_time_logged`, `admin`, `change_made`) VALUES
(1, '2019-06-25 06:34:02', 'tech3', 'Added: Test - TestValue'),
(2, '2019-06-29 18:27:16', 'tech1', 'Created new entry [status - Suspended - NULL]'),
(3, '2019-07-05 08:57:18', 'Test Admin', 'Created new entry [office - LANUZA - NULL]'),
(4, '2019-07-05 08:58:18', 'Test Admin', 'Created new entry [device_type - Biometrics - BM]'),
(5, '2019-07-05 09:16:51', 'Test Admin', 'Created new entry [office - MARK - sample description]'),
(6, '2019-07-05 09:20:54', 'Test Admin', 'Created new entry [office - XXA - NULL]'),
(7, '2019-07-05 09:23:43', 'Test Admin', 'Created new entry [concern - Equipment - Biometrics - biometric devices]');

-- --------------------------------------------------------

--
-- Table structure for table `tech_credentials`
--

CREATE TABLE `tech_credentials` (
  `tech_index` int(11) NOT NULL,
  `employee_name` text NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `status` text NOT NULL,
  `designation` text NOT NULL,
  `password` text NOT NULL,
  `current_ticket` varchar(15) DEFAULT NULL,
  `suspended_ticket` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech_credentials`
--

INSERT INTO `tech_credentials` (`tech_index`, `employee_name`, `user_type`, `username`, `status`, `designation`, `password`, `current_ticket`, `suspended_ticket`) VALUES
(1, 'Rizza Joy Batuyong', 'admin', 'ririjoy', 'active', '', 'password', NULL, ''),
(2, 'Cerina Santos', 'intern', 'inday_reng', 'active', '', 'password', NULL, ''),
(3, 'Mark Aldrin Lastica', 'intern', 'markymark', 'active', '', 'password', '190705-006', ''),
(4, 'Jeremy Villanueva', 'intern', 'klmdea', 'active', '', 'password', '190705-003-B', '190705-003-A'),
(5, 'Roy Manuel', 'tech', 'roymanuel', 'active', '', 'newpassword', '190705-005', '190705-002'),
(6, 'Test Admin', 'admin', 'admin', 'active', '', 'password', NULL, ''),
(7, 'Krista Wood', 'intern', 'itawood', 'active', '', 'ilovemark', NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `testcboxdata`
--

CREATE TABLE `testcboxdata` (
  `ticket_id` varchar(12) NOT NULL,
  `chat_log` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testcboxdata`
--

INSERT INTO `testcboxdata` (`ticket_id`, `chat_log`) VALUES
('190509-001', 'tech1<05/09/19 12:20>: lutang yung user<delimiter>admin1<05/09/19 12:21>: yeh, alien talaga yan'),
('190509-002', 'tech1<05/09/19 12:30>: lutang din yung user na to-:-admin1<05/09/19 12:33>: okay, noted din. balik ka nalang dito');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_accepted` datetime DEFAULT NULL,
  `date_assessed` datetime DEFAULT NULL,
  `date_suspended` datetime DEFAULT NULL,
  `date_resumed` datetime DEFAULT NULL,
  `date_fulfilled` datetime DEFAULT NULL,
  `ticket_id` varchar(15) NOT NULL,
  `office` text,
  `client_first_name` text,
  `client_last_name` text,
  `client_name` text,
  `employee_type` text,
  `concern` text,
  `concern_details` text NOT NULL,
  `device_id` varchar(15) NOT NULL,
  `assessment` text NOT NULL,
  `job_description` text,
  `job_details` text NOT NULL,
  `participation` text,
  `admin` text NOT NULL,
  `approval_status` text,
  `respondent` text,
  `job_status` text,
  `remarks` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`date_created`, `date_accepted`, `date_assessed`, `date_suspended`, `date_resumed`, `date_fulfilled`, `ticket_id`, `office`, `client_first_name`, `client_last_name`, `client_name`, `employee_type`, `concern`, `concern_details`, `device_id`, `assessment`, `job_description`, `job_details`, `participation`, `admin`, `approval_status`, `respondent`, `job_status`, `remarks`) VALUES
('2019-07-05 09:11:42', NULL, NULL, NULL, NULL, '2019-07-05 09:11:42', '190705-001', 'Accounting', NULL, NULL, 'Janice', 'regular', 'Connection - System', 'Sample data', '', '', 'Service', '', 'Supervised', 'Test Admin', 'Not Approved', 'Roy Manuel', 'Resolved', NULL),
('2019-05-05 09:11:42', NULL, '2019-07-05 13:58:19', '2019-07-05 13:58:57', NULL, '2019-07-05 13:59:45', '190705-002', 'CSC', NULL, NULL, 'Pamela', 'regular', 'Connection - Network', 'Sample Data', '', 'ID Signature', 'Research', 'Sample Data', 'Performed', 'Test Admin', 'Approved', 'Roy Manuel', 'Unresolved - Escalated', NULL),
('2019-07-05 13:59:45', '2019-07-05 14:03:36', '2019-07-05 14:04:22', NULL, NULL, '2019-07-05 14:04:36', '190705-002-A', 'CSC', NULL, NULL, 'Pamela, Rizza Joy Batuyong', 'regular', 'Connection - Network', 'Sample Data', '', 'AV', 'Connection', 'Sample', NULL, '', 'Approved', 'Roy Manuel', 'Unresolved - Escalated', NULL),
('2019-07-05 14:04:36', NULL, '2019-07-05 14:14:28', NULL, NULL, '2019-07-05 14:14:46', '190705-002-B', 'CSC', NULL, NULL, 'Pamela, Rizza Joy Batuyong, Roy Manuel', 'regular', 'Connection - Network', 'Sample Data', '', 'App', 'Configuration', 'Sample', NULL, '', 'Not Approved', 'Roy Manuel', 'Resolved', NULL),
('2019-07-05 14:16:09', NULL, '2019-07-05 14:17:19', NULL, NULL, '2019-07-05 14:20:42', '190705-003', 'BAC', NULL, NULL, 'mark', 'regular', 'Data Issues', '09420942', '', 'Data Error', 'Connection', 'Sample', 'Training', 'Rizza Joy Batuyong', 'Not Approved', 'Roy Manuel', 'Resolved', NULL),
('2019-07-05 14:20:03', NULL, '2019-07-05 14:23:27', '2019-07-05 14:23:34', NULL, '2019-07-05 14:25:46', '190705-003-A', 'BAC', NULL, NULL, 'mark, Rizza Joy Batuyong', 'regular', 'Data Issues', '09420942', '', 'AVR', 'Configuration', 'Sample', NULL, '', 'Approved', 'Jeremy Villanueva', 'Unresolved - Escalated', 'Rizza Joy Batuyong<2019-07-05 14:25:38>:Sample-:-'),
('2019-07-05 14:25:46', '2019-07-05 16:24:45', NULL, NULL, NULL, NULL, '190705-003-B', 'BAC', NULL, NULL, 'mark, Rizza Joy Batuyong, Rizza Joy Batuyong', 'regular', 'Data Issues', '09420942', '', '', NULL, '', NULL, '', 'Not Approved', 'Jeremy Villanueva', 'Ongoing', NULL),
('2019-07-05 14:35:03', '2019-07-05 14:35:16', '2019-07-05 15:07:53', NULL, NULL, '2019-07-05 15:12:59', '190705-004', 'CRD', NULL, NULL, 'Julius', 'regular', 'Software', 'Sample Data', 'MD-201900007', 'Biometrics', 'Install', 'Sample data', NULL, 'Test Admin', 'Approved', 'Jeremy Villanueva', 'Resolved', NULL),
('2019-07-05 16:43:36', '2019-06-05 16:47:11', '2019-06-05 16:47:48', NULL, NULL, '2019-06-18 00:00:00', '190705-005', 'Accounting', NULL, NULL, 'MaangasAko', 'regular', 'Software', 'Ayaw bumukas ng PC', '', 'CPU', 'Digital Editing', 'Sample data', NULL, '', 'Not Approved', 'Roy Manuel', 'Ongoing', NULL),
('2019-07-05 17:03:25', '2019-07-05 17:13:30', '2019-07-05 17:37:19', NULL, NULL, '2019-07-05 17:30:32', '190705-006', 'CCMNC', NULL, NULL, 'Jinky Nadal', 'regular', 'System Issues', 'Sample data', '', 'RunTime Error', 'Research', 'Sample dataxxx', NULL, 'Test Admin', 'Approved', 'Roy Manuel', 'Resolved', NULL),
('2019-07-05 13:59:45', '2019-07-05 14:03:36', '2019-07-05 14:04:22', NULL, NULL, '2019-07-05 14:04:36', '190705-008', 'CSC', NULL, NULL, 'Pamela, Rizza Joy Batuyong', 'regular', 'Connection - Network', 'Sample Data', '', 'AV', 'Connection', 'Sample', NULL, '', 'Approved', 'Roy Manuel', 'Unresolved - Escalated', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_changelog`
--

CREATE TABLE `ticket_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `ticket` varchar(15) NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_changelog`
--

INSERT INTO `ticket_changelog` (`log_number`, `date_time_logged`, `admin`, `ticket`, `change_made`) VALUES
(1, '2019-04-25 07:18:33', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEEE to LVE'),
(2, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', '1', 'Changed Client Name from  to '),
(3, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', '2', 'Changed Client Name from  to '),
(4, '2019-04-25 08:08:58', 'Rizza Joy Batuyong', '1', 'Changed Client Name from Eman to '),
(5, '2019-04-25 08:09:21', 'Rizza Joy Batuyong', '1', 'Changed Client Name from Mmmmmmmmmmm to '),
(6, '2019-04-25 08:13:44', 'Rizza Joy Batuyong', '1', 'Changed Office from LVE to LVEE'),
(7, '2019-04-25 08:13:50', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEE to LVEEE'),
(8, '2019-04-25 08:13:57', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEEE to '),
(9, '2019-04-25 08:14:02', 'Rizza Joy Batuyong', '1', 'Changed Office from  to LVEE'),
(10, '2019-04-25 08:17:37', 'Rizza Joy Batuyong', '1', 'Changed Client Name from  to Emann'),
(11, '2019-04-25 08:17:59', 'Rizza Joy Batuyong', '2', 'Changed Client Name from  to Marky'),
(12, '2019-04-25 08:18:15', 'Rizza Joy Batuyong', '2', 'Changed Client Name from Marky to Markyy'),
(13, '2019-04-25 08:27:56', 'Rizza Joy Batuyong', '1', 'Changed client_name from Emann to Eman'),
(14, '2019-04-25 08:27:56', '', '1', 'Changed job_description from  to Keme'),
(15, '2019-04-25 08:27:57', '', '1', 'Changed participation from  to Keme din'),
(16, '2019-04-25 08:28:29', '', '1', 'Changed approval_status from Not Approved to Approved'),
(17, '2019-04-25 08:28:29', '', '1', 'Changed respondent from  to tech1'),
(18, '2019-04-25 08:28:29', '', '1', 'Changed job_status from  to Accepted'),
(19, '2019-04-25 08:28:30', '', '1', 'Changed remarks from  to asd'),
(20, '2019-04-25 08:29:04', '', '1', 'Changed remarks from asd to '),
(21, '2019-04-26 02:57:52', '', '1', 'Changed respondent from tech1 to tech2'),
(22, '2019-04-26 02:57:52', '', '2', 'Changed respondent from  to tech1'),
(23, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed client_name from  to '),
(24, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed job_description from  to '),
(25, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed participation from  to '),
(26, '2019-05-08 02:05:00', 'Rizza Joy Batuyong', '1', 'Changed client_name from  to '),
(27, '2019-05-08 02:05:32', 'Rizza Joy Batuyong', '1', 'Changed employee_number from  to '),
(28, '2019-05-08 03:37:38', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(29, '2019-05-08 03:37:45', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(30, '2019-05-08 03:38:19', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(31, '2019-05-08 03:40:26', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(32, '2019-05-08 03:40:27', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(33, '2019-05-08 03:40:47', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from 445544 to 44554'),
(34, '2019-05-08 03:41:24', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emann'),
(35, '2019-05-08 03:41:33', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(36, '2019-05-08 03:43:27', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(37, '2019-05-08 03:44:00', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(38, '2019-05-08 03:44:21', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(39, '2019-05-08 06:15:53', 'James', '190505', 'Ticket 190508-003 created with the following parameters: 7,James,MI6,Malfunctioning headset'),
(40, '2019-05-08 06:17:57', 'red', '190504', 'Ticket 190508-004 created with the following parameters: 9,red,ccrp,jet boots not working'),
(41, '2019-05-08 06:19:30', 'Lili', '190503', 'Ticket 190508-005 created with the following parameters: 23,Lili,FAD,No internet'),
(42, '2019-05-08 06:20:27', 'Chun', '190502', 'Ticket 190508-006 created with the following parameters: 909,Chun,CCRP,Filesharing)'),
(43, '2019-05-08 06:23:47', 'Jo', '190501', ''),
(44, '2019-05-08 06:24:42', 'Jo', '190500', 'Ticket 190508-008 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(45, '2019-05-08 06:26:18', 'Jo', '190508-009', 'Ticket 190508-009 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(46, '2019-05-08 06:31:28', 'Jo', '190508-010', 'Ticket 190508-010 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(47, '2019-05-08 06:32:09', 'Jo', '190508-011', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(48, '2019-05-08 06:35:18', 'Jo', '190508-012', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(49, '2019-05-08 06:35:44', 'Jo', '190508-013', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(50, '2019-05-08 06:38:23', 'Jo', '190508-014', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(51, '2019-05-08 06:38:48', 'Jo', '190508-015', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(52, '2019-05-08 06:39:23', 'Jo', '190508-016', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(53, '2019-05-08 06:41:16', 'Jo', '190508-017', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(54, '2019-05-08 06:43:09', 'Jo', '190508-018', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(55, '2019-05-08 06:45:37', 'Jo', '190508-018', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(56, '2019-05-08 06:47:21', 'Jo', '190508-019', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(57, '2019-05-08 06:54:47', 'Norah', '190508-020', 'Ticket created with the following parameters: 233,Norah,RDR,Need extra keyboard'),
(58, '2019-05-08 08:59:14', 'Rizza Joy Batuyong', '190508-020', 'Changed approval_status from Not Approved to Approved'),
(59, '2019-05-08 08:59:14', 'Rizza Joy Batuyong', '190508-020', 'Changed respondent from empty to tech1'),
(60, '2019-05-09 02:22:44', 'Eman', '190509-001', 'Ticket created with the following parameters: 34567,Eman,ITDO,Beeping desktop'),
(61, '2019-05-23 02:15:19', 'Mark Lastica', '190523-001', 'Ticket created with the following parameters: 565,Mark Lastica,BA,Connection - Internet'),
(62, '2019-05-23 02:30:45', 'Jeremy Villanueva', '190523-002', 'Ticket created with the following parameters: 89898,Jeremy Villanueva,BA,Equipment - Computer'),
(63, '2019-05-23 03:06:34', 'ds', '190523-003', 'Ticket created with the following parameters: 432,ds,BPLO,System Issues'),
(64, '2019-06-03 02:14:47', 'mark', '190603-001', 'Ticket created with the following parameters: 42424,mark,BA,'),
(65, '2019-06-03 02:17:45', 'mark', '190603-002', 'Ticket created with the following parameters: 090909,mark,CADAO,'),
(66, '2019-06-03 02:20:44', 'Par', '190603-003', 'Ticket created with the following parameters: 456,Par,BGY Sec,'),
(67, '2019-06-03 02:24:32', 'par', '190603-004', 'Ticket created with the following parameters: 21212,par,BA,Others'),
(68, '2019-06-03 02:27:23', 'par', '190603-005', 'Ticket created with the following parameters: 21212,par,BA,Others'),
(69, '2019-06-03 02:28:01', 'si par', '190603-006', 'Ticket created with the following parameters: 09,si par,CCSWD,Others'),
(70, '2019-06-03 04:43:33', '3131', '190603-007', 'Ticket created with the following parameters: 313,3131,COA,'),
(71, '2019-06-03 04:47:23', '4242', '190603-008', 'Ticket created with the following parameters: 4242,4242,COA,'),
(72, '2019-06-03 05:33:33', '444242', '190603-009', 'Ticket created with the following parameters: 42424,444242,BAC,'),
(73, '2019-06-10 01:33:57', 'Mark', '190610-001', 'Ticket created with the following parameters: 0909,Mark,BGY Sec,Equipment - Mobile Device'),
(74, '2019-06-10 02:06:46', 'Carlos Mancin', '190610-002', 'Ticket created with the following parameters: 4554-AJN,Carlos Mancin,BGY Sec,System Issues'),
(75, '2019-06-10 02:08:17', 'Oscar Benilde', '190610-003', 'Ticket created with the following parameters: 444RTT,Oscar Benilde,OSEC,Equipment - Other'),
(76, '2019-06-10 02:26:36', 'T. Tinio', '190610-004', 'Ticket created with the following parameters: Not Applicable - JO,T. Tinio,CRO,Data Issues'),
(77, '2019-06-10 06:42:50', 'Mam Mel', '190610-005', 'Ticket created with the following parameters: 09090909,Mam Mel,IT,Others'),
(78, '2019-06-10 08:35:56', 'Rizza Joy Batuyong', '190610-001', 'Respondent changed from  to tech1'),
(79, '2019-06-11 00:24:15', 'Rizza Joy Batuyong', '190508-004', 'Respondent changed from  to tech1'),
(80, '2019-06-11 00:24:15', 'Rizza Joy Batuyong', '190508-004', 'Remarks changed from  to ASAP'),
(81, '2019-06-11 02:14:20', 'Rizza Joy Batuyong', '190603-007', 'Respondent changed from  to tech1'),
(82, '2019-06-11 02:14:32', 'Rizza Joy Batuyong', '190603-007', 'Remarks changed from  to asd'),
(83, '2019-06-11 02:14:45', 'Rizza Joy Batuyong', '190603-007', 'Remarks changed from Rizza Joy Batuyong<2019-06-11 10:14:32>:asd-:- to markymarkymarky'),
(84, '2019-06-11 02:15:35', 'Gracia Lastica', '190611-001', 'Ticket created with the following parameters: Not Applicable - JO,Gracia Lastica,CTO,Connection - Network'),
(85, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Assessment changed from  to Network'),
(86, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Job_description changed from  to Service'),
(87, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Job_details changed from  to Replaced LAN cable'),
(88, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Participation changed from  to Performed'),
(89, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Approval_status changed from Not Approved to Approved'),
(90, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Respondent changed from  to tech1'),
(91, '2019-06-11 02:17:16', 'Rizza Joy Batuyong', '190611-001', 'Job_status changed from Open to Ongoing'),
(92, '2019-06-11 02:17:16', 'Rizza Joy Batuyong', '190611-001', 'Remarks changed from  to MarkyMarkyMarky'),
(93, '2019-06-14 07:12:06', 'tech1', '190610-002-A', 'Ticket escalated with the following parameters: , , BGY Sec, System Issues'),
(94, '2019-06-14 07:19:00', 'tech1', '190610-002-B', 'Ticket escalated with the following parameters: , , BGY Sec, System Issues'),
(95, '2019-06-14 07:22:50', 'tech1', '190610-002-C', 'Ticket escalated with the following parameters: 4554, , BGY Sec, System Issues'),
(96, '2019-06-14 07:24:14', 'tech1', '190610-002-D', 'Ticket escalated with the following parameters: 4554, Carlos Mancin * escalated from tech1,tech1,tech1, BGY Sec, System Issues'),
(97, '2019-06-14 07:26:15', 'tech1', '190610-004-A', 'Ticket escalated with the following parameters: 0, T. Tinio, CRO, Data Issues'),
(98, '2019-06-18 06:18:40', 'Rizza Joy Batuyong', '190610-005', 'Participation changed from  to Consultation'),
(99, '2019-06-18 06:23:18', 'Rizza Joy Batuyong', '190610-005', 'Participation changed from Consultation to Performed'),
(100, '2019-06-18 06:26:18', 'Rizza Joy Batuyong', '190610-005', 'Approval_status changed from Approved to Not Approved'),
(101, '2019-06-18 06:32:44', 'Rizza Joy Batuyong', '190610-005', 'Approval_status changed from Not Approved to Approved'),
(102, '2019-06-18 06:34:29', 'Rizza Joy Batuyong', '190610-005', 'Approval_status changed from Approved to Not Approved'),
(103, '2019-06-21 04:32:26', 'Mark Lastica', '190621-001', 'Ticket created with the following parameters: 78787,Mark Lastica,Budget,Equipment - Mobile Device - Ayaw bumukas'),
(104, '2019-06-21 04:39:29', 'Rizza Joy Batuyong', '190621-001', 'Participation changed from  to Supervised'),
(105, '2019-06-21 04:39:29', 'Rizza Joy Batuyong', '190621-001', 'Approval_status changed from Not Approved to Approved'),
(106, '2019-06-21 04:39:30', 'Rizza Joy Batuyong', '190621-001', 'Job_status changed from Ongoing to Completed'),
(107, '2019-06-21 04:39:30', 'Rizza Joy Batuyong', '190621-001', 'Remarks changed from  to User Error'),
(108, '2019-06-21 04:39:45', 'Rizza Joy Batuyong', '190621-001', 'Remarks changed from Rizza Joy Batuyong<2019-06-21 12:39:30>:User Error-:- to Hindi nacharge ng user'),
(109, '2019-06-21 04:55:54', 'Mark', '190621-002', 'Ticket created with the following parameters: 43,Mark,Budget,Data or Storage Device - fghj'),
(110, '2019-06-21 04:56:19', 'tech1', '190610-004-B', 'Ticket escalated with the following parameters: 0, T. Tinio, tech1, CRO, Data Issues'),
(111, '2019-06-21 04:58:02', 'tech1', '190610-002-E', 'Ticket escalated with the following parameters: 4554, Carlos Mancin * escalated from tech1,tech1,tech1, tech1, BGY Sec, System Issues'),
(112, '2019-06-21 05:26:45', '4242', '190621-003', 'Ticket created with the following parameters: 091091,4242,BAC,Connection - System - 4242'),
(113, '2019-06-24 08:03:16', 'tech3', '190508-011-A', 'Ticket escalated with the following parameters: 9999333, Jo, ITSS, Nag-away ng mag-asawa'),
(114, '2019-06-24 08:11:49', 'tech3', '190603-009-A', 'Ticket escalated with the following parameters: 42424, 444242, BAC, '),
(115, '2019-06-29 17:50:34', 'Stanley', '190629-001', 'Ticket created with the following parameters: Not Applicable - JO,Stanley,CCSWD,Connection - Network - Sample data'),
(116, '2019-06-30 17:16:00', 'Sample Client', '190630-001', 'Ticket created with the following parameters: Not Applicable - JO,Sample Client,CRD,Connection - Internet - Sample data'),
(117, '2019-06-30 21:21:35', 'tech1', '190629-001-A', 'Ticket escalated with the following parameters: Not Applicable - JO, Stanley, CCSWD, Connection - Network'),
(118, '2019-07-02 01:27:27', 'Rizza Joy Batuyong', '190630-001', 'Respondent changed from  to tech2'),
(119, '2019-07-02 01:28:10', 'Rizza Joy Batuyong', '190630-001', 'Respondent changed from  to tech2'),
(120, '2019-07-02 01:28:58', 'Rizza Joy Batuyong', '190630-001', 'Respondent changed from  to tech2'),
(121, '2019-07-02 01:29:15', 'Rizza Joy Batuyong', '190630-001', 'Respondent changed from  to tech2'),
(122, '2019-07-02 01:32:33', 'Rizza Joy Batuyong', '190630-001', 'Respondent changed from  to tech2'),
(123, '2019-07-02 01:40:35', 'Rizza Joy Batuyong', '190630-001', 'Respondent changed from  to tech2'),
(124, '2019-07-02 01:44:21', 'Rizza Joy Batuyong', '190630-001', 'Job_status changed from Open to Suspended'),
(125, '2019-07-02 01:50:55', 'Rizza Joy Batuyong', '190630-001', 'Job_status changed from Suspended to Ongoing'),
(126, '2019-07-05 01:11:42', 'Janice', '190705-001', 'Ticket created with the following parameters: regular,Janice,Accounting,Connection - System - Sample data'),
(127, '2019-07-05 01:26:57', 'Test Admin', '190705-001', 'Respondent changed from  to Roy Manuel'),
(128, '2019-07-05 01:35:47', 'Pamela', '190705-002', 'Ticket created with the following parameters: regular,Pamela,CSC,Connection - Network - Sample Data'),
(129, '2019-07-05 01:35:56', 'Test Admin', '190705-002', 'Respondent changed from  to Roy Manuel'),
(130, '2019-07-05 01:42:28', 'Test Admin', '190705-002', 'Respondent changed from  to Roy Manuel'),
(131, '2019-07-05 01:43:19', 'Test Admin', '190705-002', 'Respondent changed from  to Roy Manuel'),
(132, '2019-07-05 01:45:10', 'Test Admin', '190705-002', 'Respondent changed from  to Roy Manuel'),
(133, '2019-07-05 05:59:45', 'Rizza Joy Batuyong', '190705-002-A', 'Ticket escalated with the following parameters: regular, Pamela, CSC, Connection - Network'),
(134, '2019-07-05 06:04:36', 'Roy Manuel', '190705-002-B', 'Ticket escalated with the following parameters: regular, Pamela, Rizza Joy Batuyong, CSC, Connection - Network'),
(135, '2019-07-05 06:05:13', 'Rizza Joy Batuyong', '190705-002-B', 'Respondent changed from  to Roy Manuel'),
(136, '2019-07-05 06:16:09', 'mark', '190705-003', 'Ticket created with the following parameters: regular,mark,BAC,Data Issues - 09420942'),
(137, '2019-07-05 06:16:34', 'Rizza Joy Batuyong', '190705-003', 'Respondent changed from  to Roy Manuel'),
(138, '2019-07-05 06:20:03', 'Rizza Joy Batuyong', '190705-003-A', 'Ticket escalated with the following parameters: regular, mark, BAC, Data Issues'),
(139, '2019-07-05 06:21:35', 'Rizza Joy Batuyong', '190705-003', 'Participation changed from  to Training'),
(140, '2019-07-05 06:21:43', 'Rizza Joy Batuyong', '190705-003', 'Approval_status changed from Approved to Not Approved'),
(141, '2019-07-05 06:22:13', 'Rizza Joy Batuyong', '190705-003-A', 'Respondent changed from  to Jeremy Villanueva'),
(142, '2019-07-05 06:25:38', 'Rizza Joy Batuyong', '190705-003-A', 'Remarks changed from  to Sample'),
(143, '2019-07-05 06:25:46', 'Rizza Joy Batuyong', '190705-003-B', 'Ticket escalated with the following parameters: regular, mark, Rizza Joy Batuyong, BAC, Data Issues'),
(144, '2019-07-05 06:35:03', 'Julius', '190705-004', 'Ticket created with the following parameters: regular,Julius,CRD,Software - Sample Data'),
(145, '2019-07-05 08:43:36', 'MaangasAko', '190705-005', 'Ticket created with the following parameters: regular,MaangasAko,Accounting,Others - Ayaw bumukas ng PC'),
(146, '2019-07-05 09:03:25', 'Jinky Nadal', '190705-006', 'Ticket created with the following parameters: regular,Jinky Nadal,CCMNC,System Issues - Sample data'),
(147, '2019-07-05 09:05:35', 'Test Admin', '190705-006', 'Respondent changed from Cerina Santos to Mark Aldrin Lastica'),
(148, '2019-07-05 09:29:08', 'Test Admin', '190705-004', 'Approval_status changed from Not Approved to Approved'),
(149, '2019-07-05 09:37:59', 'Test Admin', '190705-006', 'Approval_status changed from Not Approved to Approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `device_changelog`
--
ALTER TABLE `device_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- Indexes for table `device_list`
--
ALTER TABLE `device_list`
  ADD UNIQUE KEY `device_id` (`device_id`),
  ADD KEY `device_id_2` (`device_id`);

--
-- Indexes for table `field_values_changelog`
--
ALTER TABLE `field_values_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- Indexes for table `tech_credentials`
--
ALTER TABLE `tech_credentials`
  ADD PRIMARY KEY (`tech_index`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `ticket_id_2` (`ticket_id`),
  ADD KEY `ticket_id_3` (`ticket_id`);

--
-- Indexes for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `device_changelog`
--
ALTER TABLE `device_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `field_values_changelog`
--
ALTER TABLE `field_values_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tech_credentials`
--
ALTER TABLE `tech_credentials`
  MODIFY `tech_index` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
