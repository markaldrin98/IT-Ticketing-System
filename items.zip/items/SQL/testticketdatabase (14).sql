-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 26, 2019 at 02:42 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testticketdatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `device_changelog`
--

CREATE TABLE `device_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `device_id` varchar(15) NOT NULL,
  `admin` text NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_changelog`
--

INSERT INTO `device_changelog` (`log_number`, `date_time_logged`, `device_id`, `admin`, `change_made`) VALUES
(1, '2019-06-25 06:33:01', 'DT-201900010', 'tech3', 'Registered new'),
(2, '2019-06-25 06:34:02', 'DT-201900010', 'tech3', 'Registered new');

-- --------------------------------------------------------

--
-- Table structure for table `device_list`
--

CREATE TABLE `device_list` (
  `device_id` varchar(15) NOT NULL,
  `device_type` text NOT NULL,
  `owner` text NOT NULL,
  `office` text NOT NULL,
  `date_registered` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_list`
--

INSERT INTO `device_list` (`device_id`, `device_type`, `owner`, `office`, `date_registered`) VALUES
('DT-201900001', 'Desktop', 'Mark', 'IT', '2019-06-20 22:42:59'),
('LT-201900001', 'Laptop', 'Marky Mark', 'IT', '2019-06-02 21:10:30'),
('LT-201900002', 'Laptop', 'Kala DS', 'IT', '2019-06-06 23:49:08'),
('LT-201900003', 'Laptop', 'Eriri', 'City Admin', '2019-06-25 02:42:18'),
('LT-201900004', 'Laptop', 'Eriri', 'City Admin', '2019-06-25 02:43:11'),
('MD-201900001', 'Mobile Device', 'Eriri', 'City Admin', '2019-06-03 00:05:09'),
('TB-201900001', 'Tablet', 'Marky Mark', 'BGY Sec', '2019-06-20 23:11:00'),
('TB-201900002', 'Tablet', 'Marky Mark', 'BGY Sec', '2019-06-20 23:11:17');

-- --------------------------------------------------------

--
-- Table structure for table `device_parts_table`
--

CREATE TABLE `device_parts_table` (
  `device_id` varchar(15) NOT NULL,
  `peripheral` text NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_parts_table`
--

INSERT INTO `device_parts_table` (`device_id`, `peripheral`, `details`) VALUES
('LT-201900001', 'Processor', 'i7'),
('LT-201900001', 'Hard Drive', '1TB'),
('LT-201900001', 'Mouse', 'A4Tech'),
('LT-201900002', 'Mouse', 'A4 Tech'),
('LT-201900002', 'Keyboard', 'A4 Tech'),
('LT-201900002', 'Speaker', '300 Watts'),
('LT-201900002', 'X', 'YZ'),
('LT-201900002', 'X', 'YZ'),
('LT-201900002', 'PSU', '600 Watts');

-- --------------------------------------------------------

--
-- Table structure for table `device_service_history`
--

CREATE TABLE `device_service_history` (
  `device_id` varchar(15) NOT NULL,
  `ticket_id` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `device_specs_table`
--

CREATE TABLE `device_specs_table` (
  `device_id` varchar(15) NOT NULL,
  `specification` text NOT NULL,
  `details` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `device_specs_table`
--

INSERT INTO `device_specs_table` (`device_id`, `specification`, `details`) VALUES
('MD-201900001', 'RAM', '16GB'),
('LT-201900002', 'RAM', '8GB'),
('LT-201900002', 'Processor', 'i7 3.6GHz'),
('LT-201900002', 'Storage', '1TB');

-- --------------------------------------------------------

--
-- Table structure for table `field_values`
--

CREATE TABLE `field_values` (
  `field` text NOT NULL,
  `value` text NOT NULL,
  `details` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field_values`
--

INSERT INTO `field_values` (`field`, `value`, `details`) VALUES
('office', 'Accounting', ''),
('office', 'CAO', ''),
('office', 'BAC', ''),
('office', 'BGY Sec', ''),
('office', 'BPLO', ''),
('office', 'Budget', ''),
('office', 'BA', ''),
('office', 'CADAO', ''),
('office', 'CATO', ''),
('office', 'CCDRRMO', ''),
('office', 'CCMC', ''),
('office', 'CCMNC', ''),
('office', 'CCSWD', ''),
('office', 'CEMD', ''),
('office', 'City Admin', ''),
('office', 'COA', ''),
('office', 'CRD', ''),
('office', 'CRO', ''),
('office', 'CSC', ''),
('office', 'CTO', ''),
('office', 'DILG', ''),
('office', 'Eng', ''),
('office', 'GAD', ''),
('office', 'GSO', ''),
('office', 'Health', ''),
('office', 'HRMO', ''),
('office', 'IAS', ''),
('office', 'IT', ''),
('office', 'IT North', ''),
('office', 'Landtax', ''),
('office', 'Legal', ''),
('office', 'LEIPO', ''),
('office', 'License', ''),
('office', 'LIRO', ''),
('office', 'LIGA', ''),
('office', 'MO', ''),
('office', 'Negosyo Center', ''),
('office', 'OCBO', ''),
('office', 'OSCA', ''),
('office', 'OSEC', ''),
('office', 'Parks', ''),
('office', 'PIO', ''),
('office', 'Planning', ''),
('office', 'PLEB', ''),
('office', 'pub', ''),
('office', 'PWD', ''),
('office', 'Sangunian', ''),
('office', 'Sports', ''),
('office', 'Upao', ''),
('office', 'Vet', ''),
('office', 'OLUZA', ''),
('office', 'VM', ''),
('job_description', 'Service', ''),
('job_description', 'VR', ''),
('job_description', 'Configuration', ''),
('job_description', 'Research', ''),
('job_description', 'Paperwork', ''),
('job_description', 'Communication', ''),
('job_description', 'Registration', ''),
('job_description', 'Connection', ''),
('job_description', 'Setup', ''),
('job_description', 'Install', ''),
('job_description', 'Digital Editing', ''),
('job_description', 'Training', ''),
('concern', 'Connection - Internet', 'connecting to the internet'),
('concern', 'Connection - System', 'connecting to your local system'),
('concern', 'Connection - Network', 'connecting to the local network'),
('concern', 'Data Issues', 'missing, invalid, or deprecated data within internal applications'),
('concern', 'Data or Storage Device', 'backups, recovery, and storage media'),
('concern', 'Equipment - Computer', 'desktops, laptops, and their respective components'),
('concern', 'Equipment - Mobile Device', 'mobile devices such as smartphones or tablets'),
('concern', 'Equipment - Other', 'equipment not listed above- such as printers, projectors, scanners, or biometric devices'),
('concern', 'Software', 'your operating system or external applications such as MS Office and VM'),
('concern', 'System Issues', 'internal programs not working properly'),
('concern', 'Others', 'issues not listed above'),
('assessment', 'AV', ''),
('assessment', 'App', ''),
('assessment', 'Biometrics', ''),
('assessment', 'Laptop', ''),
('assessment', 'Backup', ''),
('assessment', 'Desktop', ''),
('assessment', 'CPU', ''),
('assessment', 'Layout', ''),
('assessment', 'Monitor', ''),
('assessment', 'Mouse', ''),
('assessment', 'Keyboard', ''),
('assessment', 'Printer', ''),
('assessment', 'Scanner', ''),
('assessment', 'AVR', ''),
('assessment', 'UPS', ''),
('assessment', 'Power', ''),
('assessment', 'Projector', ''),
('assessment', 'Photo', ''),
('assessment', 'Recovery', ''),
('assessment', 'Removable Device', ''),
('assessment', 'Mobile Device', ''),
('assessment', 'Network', ''),
('assessment', 'Internet', ''),
('assessment', 'internet filter', ''),
('assessment', 'Wifi', ''),
('assessment', 'Lined', ''),
('assessment', 'System', ''),
('assessment', 'SmartQ', ''),
('assessment', 'Server', ''),
('assessment', 'AD', ''),
('assessment', 'OS', ''),
('assessment', 'MS Office', ''),
('assessment', 'ID Signature', ''),
('assessment', 'VM', ''),
('assessment', 'LR', ''),
('assessment', 'Inventory', ''),
('assessment', 'Documentation', ''),
('assessment', 'Supply Run', ''),
('assessment', 'Others', ''),
('assessment', 'OR Error', ''),
('assessment', 'RunTime Error', ''),
('assessment', 'Date Error', ''),
('assessment', 'No Data Reflect', ''),
('assessment', 'Update Data', ''),
('assessment', 'Data Error', ''),
('assessment', 'System Issue', ''),
('status', 'Open', ''),
('status', 'Ongoing', ''),
('status', 'Completed', ''),
('status', 'Escalated', ''),
('status', 'Not Serviced', ''),
('participation', 'Supervised', ''),
('participation', 'Training', ''),
('participation', 'Performed', ''),
('participation', 'Consultation', ''),
('device_type', 'Desktop', ''),
('device_type', 'Laptop', ''),
('device_type', 'Mobile Device', ''),
('device_type', 'Tablet', ''),
('device_type', 'Others', ''),
('software', 'Windows OS', ''),
('software', 'MS Office', ''),
('software', 'Antivirus Software', ''),
('software', 'Adobe Photoshop/Creative Suite', ''),
('software', 'Others', ''),
('specification', 'Memory', ''),
('specification', 'Storage', ''),
('specification', 'Motherboard', ''),
('specification', 'Mac Address', ''),
('specification', 'IP Address', ''),
('specification', 'Processor', ''),
('specification', 'Video Card', ''),
('peripheral', 'Mouse', ''),
('peripheral', 'Keyboard', ''),
('peripheral', 'Speakers', ''),
('peripheral', 'Monitor', ''),
('peripheral', 'Web Camera', '');

-- --------------------------------------------------------

--
-- Table structure for table `field_values_changelog`
--

CREATE TABLE `field_values_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `field_values_changelog`
--

INSERT INTO `field_values_changelog` (`log_number`, `date_time_logged`, `admin`, `change_made`) VALUES
(1, '2019-06-25 06:34:02', 'tech3', 'Added: Test - TestValue');

-- --------------------------------------------------------

--
-- Table structure for table `tech_credentials`
--

CREATE TABLE `tech_credentials` (
  `employee_name` text NOT NULL,
  `user_type` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `current_ticket` varchar(15) DEFAULT NULL,
  `suspended_ticket` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tech_credentials`
--

INSERT INTO `tech_credentials` (`employee_name`, `user_type`, `username`, `password`, `current_ticket`, `suspended_ticket`) VALUES
('Rizza Joy Batuyong', 'admin', 'ririjoy', 'password', NULL, ''),
('tech1', 'tech', 'tech1username', 'password', '190508-013', ''),
('tech2', 'tech', 'tech2username', 'password', '190610-003', ''),
('tech3', 'tech', 'tech3username', 'password', '190603-008', '190610-004-B');

-- --------------------------------------------------------

--
-- Table structure for table `testcboxdata`
--

CREATE TABLE `testcboxdata` (
  `ticket_id` varchar(12) NOT NULL,
  `chat_log` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testcboxdata`
--

INSERT INTO `testcboxdata` (`ticket_id`, `chat_log`) VALUES
('190509-001', 'tech1<05/09/19 12:20>: lutang yung user<delimiter>admin1<05/09/19 12:21>: yeh, alien talaga yan'),
('190509-002', 'tech1<05/09/19 12:30>: lutang din yung user na to-:-admin1<05/09/19 12:33>: okay, noted din. balik ka nalang dito');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_accepted` datetime DEFAULT NULL,
  `date_assessed` timestamp NULL DEFAULT NULL,
  `date_suspended` timestamp NULL DEFAULT NULL,
  `date_resumed` timestamp NULL DEFAULT NULL,
  `date_fulfilled` datetime DEFAULT NULL,
  `ticket_id` varchar(15) NOT NULL,
  `office` text,
  `client_name` text,
  `employee_number` text,
  `concern` text,
  `concern_details` text NOT NULL,
  `device_id` varchar(15) NOT NULL,
  `assessment` text NOT NULL,
  `job_description` text,
  `job_details` text NOT NULL,
  `participation` text,
  `approval_status` text,
  `respondent` text,
  `job_status` text,
  `remarks` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tickets`
--

INSERT INTO `tickets` (`date_created`, `date_accepted`, `date_assessed`, `date_suspended`, `date_resumed`, `date_fulfilled`, `ticket_id`, `office`, `client_name`, `employee_number`, `concern`, `concern_details`, `device_id`, `assessment`, `job_description`, `job_details`, `participation`, `approval_status`, `respondent`, `job_status`, `remarks`) VALUES
('2019-04-25 10:28:54', '2019-04-30 10:42:45', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-04-30 12:59:25', '190425-001', 'LVEE', 'Eman', '44554', 'Burning Tower', '', '', '', '', '', '', 'Approved', NULL, 'Ongoing', ''),
('2019-04-25 14:50:10', '2019-06-06 11:55:49', '2019-06-06 03:59:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-04-30 10:42:38', '190425-002', 'MTHD', 'Markyy', '4478', 'Random beeping noises coming from CPU', '', '', 'Backup', 'Service', 'Backup to FD', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-04-26 14:51:15', '2019-04-29 12:57:14', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190426-001', 'HR', 'Eman', '444', 'Umuusok yung mouse', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-04-29 14:23:33', '2019-04-29 16:53:36', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190429-001', 'ITS', 'Eman', '445544', 'Umuusok yung tower', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-04-29 14:24:17', '2019-04-30 08:52:47', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-04-30 08:57:01', '190429-002', 'ITS', 'Marky', '4444', 'May syotaan dito', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 13:55:32', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-001', 'ITDO', 'Riri', '554', 'Noone believes me', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 13:59:28', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-002', 'ITDO', 'Kay', '998', 'Nangangagat yung laptop', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:15:53', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-003', 'MI6', 'James', '7', 'Malfunctioning headset', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:17:57', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-004', 'ccrp', 'red', '9', 'jet boots not working', '', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Open', 'Rizza Joy Batuyong<2019-06-11 08:24:15>:ASAP-:-'),
('2019-05-08 14:19:29', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-005', 'FAD', 'Lili', '23', 'No internet', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:20:27', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-006', 'CCRP', 'Chun', '909', 'Filesharing)', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:23:47', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-007', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:24:42', '2019-05-20 15:23:29', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-008', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:26:18', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-009', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:31:28', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-010', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:32:08', '2019-06-24 16:03:03', '2019-05-23 02:25:56', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-06-24 16:10:59', '190508-011', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', 'Internet', 'Service', 'Replaced LAN cable', NULL, 'Approved', 'tech3', 'Unresolved - Escalated', NULL),
('2019-06-24 16:03:16', NULL, NULL, NULL, NULL, NULL, '190508-011-A', 'ITSS', 'Jo, tech3', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Escalated', NULL),
('2019-05-08 14:35:18', '2019-05-20 15:04:03', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-012', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:35:44', '2019-06-25 16:24:28', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-013', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-05-08 14:38:23', '2019-05-20 15:38:13', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-014', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:38:48', '2019-05-17 13:51:53', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-015', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:39:23', '2019-05-17 14:07:20', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-016', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:41:16', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-017', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:43:09', '2019-05-20 10:09:51', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-018', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:47:21', '2019-05-17 13:58:56', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-019', 'ITSS', 'Jo', '9999333', 'Nag-away ng mag-asawa', '', 'LT-201900001', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-08 14:54:47', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-05-20 15:57:59', '190508-020', 'RDR', 'Norah', '233', 'Need extra keyboard', '', '', '', NULL, '', NULL, 'Approved', NULL, 'Open', NULL),
('2019-05-09 10:22:44', '2019-05-20 15:47:54', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190509-001', 'CEMD', 'Eman', '34567', 'Beeping desktop', '', '', '', NULL, 'ljjhgvhhjoihggcgv rrfddfdffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff', NULL, 'Not Approved', NULL, 'Ongoing', 'Rizza Joy Batuyong<2019-05-22 09:54:06>:Isn\'t it nice to say \'I love you\'?-:-Rizza Joy Batuyong<2019-05-22 09:54:24>:Isn\'t it nice to say \'I love you\'?-:-Rizza Joy Batuyong<2019-05-22 11:37:24>:asd-:-'),
('2019-05-23 10:15:19', '2019-06-19 11:56:22', '2019-06-21 04:11:44', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190523-001', 'BA', 'Mark Lastica', '565', 'Connection - Internet', '', '', 'AD', 'Digital Editing', 'dfghjkl', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-05-23 10:30:45', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190523-002', 'BA', 'Jeremy Villanueva', '89898', 'Equipment - Computer', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-05-23 11:06:34', '2019-05-24 14:15:02', '2019-05-31 08:44:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190523-003', 'BPLO', 'ds', '432', 'System Issues', '', 'MD-201900001', 'CPU', 'Install', 'installed ms office', NULL, 'Not Approved', NULL, 'Ongoing', 'Rizza Joy Batuyong<2019-06-01 17:57:13>:Try-:-'),
('2019-06-03 10:14:47', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-001', 'BA', 'mark', '42424', '', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-03 10:17:45', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-002', 'CADAO', 'mark', '90909', '', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-03 10:20:44', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-003', 'BGY Sec', 'Par', '456', '', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-03 10:24:32', NULL, '2019-06-19 03:54:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-004', 'BA', 'par', '21212', 'Others', '', '', 'Date Error', 'Paperwork', 'sdfghjk', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-03 10:27:23', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-005', 'BA', 'par', '21212', 'Others', 'par', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-03 10:28:01', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-006', 'CCSWD', 'si par', '9', 'Others', 'nice one par', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-03 12:43:33', '2019-06-04 10:30:53', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-007', 'COA', '3131', '313', '', '', '', '', NULL, '', NULL, 'Not Approved', 'tech1', 'Ongoing', 'Rizza Joy Batuyong<2019-06-11 10:14:32>:asd-:-Rizza Joy Batuyong<2019-06-11 10:14:46>:markymarkymarky-:-'),
('2019-06-03 12:47:23', '2019-06-24 16:42:00', '2019-06-24 08:42:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190603-008', 'COA', '4242', '4242', '', '', 'DT-201900002', 'Inventory', 'Research', 'sam', NULL, 'Not Approved', 'tech3', 'Ongoing', NULL),
('2019-06-03 13:33:33', '2019-06-24 16:11:25', '2019-06-24 08:11:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-06-24 16:12:18', '190603-009', 'BAC', '444242', '42424', '', '', '', 'App', 'Digital Editing', 'Sample Data', NULL, 'Approved', 'tech3', 'Unresolved - Escalated', NULL),
('2019-06-24 16:11:49', NULL, NULL, NULL, NULL, NULL, '190603-009-A', 'BAC', '444242, tech3', '42424', '', '', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Escalated', NULL),
('2019-06-10 09:33:57', NULL, '2019-06-19 03:55:29', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190610-001', 'BGY Sec', 'Mark', '909', 'Equipment - Mobile Device', 'No wifi', '', 'Keyboard', 'Research', ' bnm', NULL, 'Not Approved', 'tech1', 'Open', NULL),
('2019-06-10 10:06:46', '2019-06-13 12:09:44', '2019-06-13 07:10:39', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190610-002', 'BGY Sec', 'Carlos Mancin', '4554', 'System Issues', 'Ayaw magstart ng system', '', 'App', 'Configuration', 'Configured system app', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-06-14 15:12:06', '2019-06-14 15:18:15', '2019-06-14 07:18:31', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190610-002-A', 'BGY Sec', 'Carlos Mancin * escalated from tech1', '4554', 'System Issues', 'Ayaw magstart ng system', '', 'Backup', 'Registration', 'Sample Job Details', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-06-14 15:18:59', '2019-06-14 15:22:28', '2019-06-14 07:22:43', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190610-002-B', 'BGY Sec', 'Carlos Mancin * escalated from tech1,tech1', '4554', 'System Issues', 'Ayaw magstart ng system', '', 'Backup', 'Research', 'Random inconsequential string', NULL, 'Not Approved', 'tech1', 'Ongoing', NULL),
('2019-06-14 15:22:50', '2019-06-14 15:23:53', '2019-06-14 07:24:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-06-14 15:25:25', '190610-002-C', 'BGY Sec', 'Carlos Mancin * escalated from tech1,tech1,tech1', '4554', 'System Issues', 'Ayaw magstart ng system', '', 'AV', 'Research', 'Zxc', NULL, 'Not Approved', 'tech1', 'Unresolved - Escalated', NULL),
('2019-06-14 15:24:14', '2019-06-21 12:57:31', '2019-06-21 04:58:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-06-21 12:58:02', '190610-002-D', 'BGY Sec', 'Carlos Mancin * escalated from tech1,tech1,tech1, tech1', '4554', 'System Issues', 'Ayaw magstart ng system', '', 'AVR', 'Connection', 'gh', NULL, 'Approved', 'tech1', 'Unresolved - Escalated', NULL),
('2019-06-21 12:58:01', '2019-06-21 12:58:28', '2019-06-21 07:16:01', NULL, NULL, '2019-06-21 15:17:40', '190610-002-E', 'BGY Sec', 'Carlos Mancin * escalated from tech1,tech1,tech1, tech1, tech1', '4554', 'System Issues', 'Ayaw magstart ng system', 'MD-201900001', 'Inventory', 'Setup', 'dfgbgfd', NULL, 'Not Approved', 'tech1', 'Resolved', NULL),
('2019-06-10 10:08:17', '2019-06-10 11:44:28', NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190610-003', 'OSEC', 'Oscar Benilde', '444', 'Equipment - Other', 'Sira bio sa 2nd floor', 'LT-201900002', '', NULL, '', NULL, 'Not Approved', 'tech2', 'Ongoing', NULL),
('2019-06-10 10:26:35', '2019-06-14 15:25:49', '2019-06-14 07:26:12', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-06-14 15:26:15', '190610-004', 'CRO', 'T. Tinio', '0', 'Data Issues', 'Mali yung nakalagay sa DTR', '', 'Laptop', 'Service', 'Malfunctioning KBoard', NULL, 'Not Approved', 'tech1', 'Unresolved - Escalated', NULL),
('2019-06-14 15:26:15', '2019-06-21 12:42:05', '2019-06-21 04:56:17', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2019-06-21 12:56:19', '190610-004-A', 'CRO', 'T. Tinio, tech1', '0', 'Data Issues', 'Mali yung nakalagay sa DTR', 'LT-201900002', 'Inventory', 'Service', 'fghjk', NULL, 'Approved', 'tech1', 'Unresolved - Escalated', NULL),
('2019-06-21 12:56:19', '2019-06-24 16:41:20', '2019-06-24 08:41:33', '2019-06-24 08:41:42', NULL, NULL, '190610-004-B', 'CRO', 'T. Tinio, tech1, tech1', '0', 'Data Issues', 'Mali yung nakalagay sa DTR', '', 'AV', 'Configuration', 'sam', NULL, 'Not Approved', 'tech3', 'Suspended', NULL),
('2019-06-10 14:42:50', NULL, '2019-06-18 09:05:46', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190610-005', 'IT', 'Mam Mel', '09090909', 'Others', 'PBB - Naibigay bigla', '', 'Mouse', 'Install: Others - In Utero', 'seven nation army\r\n', 'Performed', 'Not Approved', 'tech3', 'Open', NULL),
('2019-06-11 10:15:35', NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '190611-001', 'CTO', 'Gracia Lastica', 'Not Applicable - JO', 'Connection - Network', 'No network', '', 'Network', 'Service', 'Replaced LAN cable', 'Performed', 'Approved', 'tech1', 'Ongoing', 'Rizza Joy Batuyong<2019-06-11 10:17:16>:MarkyMarkyMarky-:-'),
('2019-06-21 12:32:26', '2019-06-21 12:35:42', '2019-06-21 04:37:19', NULL, NULL, NULL, '190621-001', 'Budget', 'Mark Lastica', '78787', 'Equipment - Mobile Device', 'Ayaw bumukas', 'LT-201900001', 'Mobile Device', 'Service', 'Low batt lang pala', 'Supervised', 'Approved', 'tech1', 'Completed', 'Rizza Joy Batuyong<2019-06-21 12:39:30>:User Error-:-Rizza Joy Batuyong<2019-06-21 12:39:45>:Hindi nacharge ng user-:-'),
('2019-06-21 12:55:54', NULL, NULL, NULL, NULL, NULL, '190621-002', 'Budget', 'Mark', '43', 'Data or Storage Device', 'fghj', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL),
('2019-06-21 13:26:45', NULL, NULL, NULL, NULL, NULL, '190621-003', 'BAC', '4242', '091091', 'Connection - System', '4242', '', '', NULL, '', NULL, 'Not Approved', NULL, 'Open', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ticket_changelog`
--

CREATE TABLE `ticket_changelog` (
  `log_number` int(11) NOT NULL,
  `date_time_logged` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin` text NOT NULL,
  `ticket` varchar(15) NOT NULL,
  `change_made` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ticket_changelog`
--

INSERT INTO `ticket_changelog` (`log_number`, `date_time_logged`, `admin`, `ticket`, `change_made`) VALUES
(1, '2019-04-25 07:18:33', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEEE to LVE'),
(2, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', '1', 'Changed Client Name from  to '),
(3, '2019-04-25 07:24:50', 'Rizza Joy Batuyong', '2', 'Changed Client Name from  to '),
(4, '2019-04-25 08:08:58', 'Rizza Joy Batuyong', '1', 'Changed Client Name from Eman to '),
(5, '2019-04-25 08:09:21', 'Rizza Joy Batuyong', '1', 'Changed Client Name from Mmmmmmmmmmm to '),
(6, '2019-04-25 08:13:44', 'Rizza Joy Batuyong', '1', 'Changed Office from LVE to LVEE'),
(7, '2019-04-25 08:13:50', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEE to LVEEE'),
(8, '2019-04-25 08:13:57', 'Rizza Joy Batuyong', '1', 'Changed Office from LVEEE to '),
(9, '2019-04-25 08:14:02', 'Rizza Joy Batuyong', '1', 'Changed Office from  to LVEE'),
(10, '2019-04-25 08:17:37', 'Rizza Joy Batuyong', '1', 'Changed Client Name from  to Emann'),
(11, '2019-04-25 08:17:59', 'Rizza Joy Batuyong', '2', 'Changed Client Name from  to Marky'),
(12, '2019-04-25 08:18:15', 'Rizza Joy Batuyong', '2', 'Changed Client Name from Marky to Markyy'),
(13, '2019-04-25 08:27:56', 'Rizza Joy Batuyong', '1', 'Changed client_name from Emann to Eman'),
(14, '2019-04-25 08:27:56', '', '1', 'Changed job_description from  to Keme'),
(15, '2019-04-25 08:27:57', '', '1', 'Changed participation from  to Keme din'),
(16, '2019-04-25 08:28:29', '', '1', 'Changed approval_status from Not Approved to Approved'),
(17, '2019-04-25 08:28:29', '', '1', 'Changed respondent from  to tech1'),
(18, '2019-04-25 08:28:29', '', '1', 'Changed job_status from  to Accepted'),
(19, '2019-04-25 08:28:30', '', '1', 'Changed remarks from  to asd'),
(20, '2019-04-25 08:29:04', '', '1', 'Changed remarks from asd to '),
(21, '2019-04-26 02:57:52', '', '1', 'Changed respondent from tech1 to tech2'),
(22, '2019-04-26 02:57:52', '', '2', 'Changed respondent from  to tech1'),
(23, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed client_name from  to '),
(24, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed job_description from  to '),
(25, '2019-05-08 02:04:43', 'Rizza Joy Batuyong', '1', 'Changed participation from  to '),
(26, '2019-05-08 02:05:00', 'Rizza Joy Batuyong', '1', 'Changed client_name from  to '),
(27, '2019-05-08 02:05:32', 'Rizza Joy Batuyong', '1', 'Changed employee_number from  to '),
(28, '2019-05-08 03:37:38', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(29, '2019-05-08 03:37:45', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(30, '2019-05-08 03:38:19', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(31, '2019-05-08 03:40:26', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(32, '2019-05-08 03:40:27', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from  to '),
(33, '2019-05-08 03:40:47', 'Rizza Joy Batuyong', '190428', 'Changed employee_number from 445544 to 44554'),
(34, '2019-05-08 03:41:24', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emann'),
(35, '2019-05-08 03:41:33', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(36, '2019-05-08 03:43:27', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(37, '2019-05-08 03:44:00', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(38, '2019-05-08 03:44:21', 'Rizza Joy Batuyong', '190428', 'Changed client_name from Eman to Emannnn'),
(39, '2019-05-08 06:15:53', 'James', '190505', 'Ticket 190508-003 created with the following parameters: 7,James,MI6,Malfunctioning headset'),
(40, '2019-05-08 06:17:57', 'red', '190504', 'Ticket 190508-004 created with the following parameters: 9,red,ccrp,jet boots not working'),
(41, '2019-05-08 06:19:30', 'Lili', '190503', 'Ticket 190508-005 created with the following parameters: 23,Lili,FAD,No internet'),
(42, '2019-05-08 06:20:27', 'Chun', '190502', 'Ticket 190508-006 created with the following parameters: 909,Chun,CCRP,Filesharing)'),
(43, '2019-05-08 06:23:47', 'Jo', '190501', ''),
(44, '2019-05-08 06:24:42', 'Jo', '190500', 'Ticket 190508-008 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(45, '2019-05-08 06:26:18', 'Jo', '190508-009', 'Ticket 190508-009 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(46, '2019-05-08 06:31:28', 'Jo', '190508-010', 'Ticket 190508-010 created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(47, '2019-05-08 06:32:09', 'Jo', '190508-011', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(48, '2019-05-08 06:35:18', 'Jo', '190508-012', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(49, '2019-05-08 06:35:44', 'Jo', '190508-013', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(50, '2019-05-08 06:38:23', 'Jo', '190508-014', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(51, '2019-05-08 06:38:48', 'Jo', '190508-015', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(52, '2019-05-08 06:39:23', 'Jo', '190508-016', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(53, '2019-05-08 06:41:16', 'Jo', '190508-017', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(54, '2019-05-08 06:43:09', 'Jo', '190508-018', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(55, '2019-05-08 06:45:37', 'Jo', '190508-018', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(56, '2019-05-08 06:47:21', 'Jo', '190508-019', 'Ticket created with the following parameters: 9999333,Jo,ITSS,Nag-away ng mag-asawa'),
(57, '2019-05-08 06:54:47', 'Norah', '190508-020', 'Ticket created with the following parameters: 233,Norah,RDR,Need extra keyboard'),
(58, '2019-05-08 08:59:14', 'Rizza Joy Batuyong', '190508-020', 'Changed approval_status from Not Approved to Approved'),
(59, '2019-05-08 08:59:14', 'Rizza Joy Batuyong', '190508-020', 'Changed respondent from empty to tech1'),
(60, '2019-05-09 02:22:44', 'Eman', '190509-001', 'Ticket created with the following parameters: 34567,Eman,ITDO,Beeping desktop'),
(61, '2019-05-23 02:15:19', 'Mark Lastica', '190523-001', 'Ticket created with the following parameters: 565,Mark Lastica,BA,Connection - Internet'),
(62, '2019-05-23 02:30:45', 'Jeremy Villanueva', '190523-002', 'Ticket created with the following parameters: 89898,Jeremy Villanueva,BA,Equipment - Computer'),
(63, '2019-05-23 03:06:34', 'ds', '190523-003', 'Ticket created with the following parameters: 432,ds,BPLO,System Issues'),
(64, '2019-06-03 02:14:47', 'mark', '190603-001', 'Ticket created with the following parameters: 42424,mark,BA,'),
(65, '2019-06-03 02:17:45', 'mark', '190603-002', 'Ticket created with the following parameters: 090909,mark,CADAO,'),
(66, '2019-06-03 02:20:44', 'Par', '190603-003', 'Ticket created with the following parameters: 456,Par,BGY Sec,'),
(67, '2019-06-03 02:24:32', 'par', '190603-004', 'Ticket created with the following parameters: 21212,par,BA,Others'),
(68, '2019-06-03 02:27:23', 'par', '190603-005', 'Ticket created with the following parameters: 21212,par,BA,Others'),
(69, '2019-06-03 02:28:01', 'si par', '190603-006', 'Ticket created with the following parameters: 09,si par,CCSWD,Others'),
(70, '2019-06-03 04:43:33', '3131', '190603-007', 'Ticket created with the following parameters: 313,3131,COA,'),
(71, '2019-06-03 04:47:23', '4242', '190603-008', 'Ticket created with the following parameters: 4242,4242,COA,'),
(72, '2019-06-03 05:33:33', '444242', '190603-009', 'Ticket created with the following parameters: 42424,444242,BAC,'),
(73, '2019-06-10 01:33:57', 'Mark', '190610-001', 'Ticket created with the following parameters: 0909,Mark,BGY Sec,Equipment - Mobile Device'),
(74, '2019-06-10 02:06:46', 'Carlos Mancin', '190610-002', 'Ticket created with the following parameters: 4554-AJN,Carlos Mancin,BGY Sec,System Issues'),
(75, '2019-06-10 02:08:17', 'Oscar Benilde', '190610-003', 'Ticket created with the following parameters: 444RTT,Oscar Benilde,OSEC,Equipment - Other'),
(76, '2019-06-10 02:26:36', 'T. Tinio', '190610-004', 'Ticket created with the following parameters: Not Applicable - JO,T. Tinio,CRO,Data Issues'),
(77, '2019-06-10 06:42:50', 'Mam Mel', '190610-005', 'Ticket created with the following parameters: 09090909,Mam Mel,IT,Others'),
(78, '2019-06-10 08:35:56', 'Rizza Joy Batuyong', '190610-001', 'Respondent changed from  to tech1'),
(79, '2019-06-11 00:24:15', 'Rizza Joy Batuyong', '190508-004', 'Respondent changed from  to tech1'),
(80, '2019-06-11 00:24:15', 'Rizza Joy Batuyong', '190508-004', 'Remarks changed from  to ASAP'),
(81, '2019-06-11 02:14:20', 'Rizza Joy Batuyong', '190603-007', 'Respondent changed from  to tech1'),
(82, '2019-06-11 02:14:32', 'Rizza Joy Batuyong', '190603-007', 'Remarks changed from  to asd'),
(83, '2019-06-11 02:14:45', 'Rizza Joy Batuyong', '190603-007', 'Remarks changed from Rizza Joy Batuyong<2019-06-11 10:14:32>:asd-:- to markymarkymarky'),
(84, '2019-06-11 02:15:35', 'Gracia Lastica', '190611-001', 'Ticket created with the following parameters: Not Applicable - JO,Gracia Lastica,CTO,Connection - Network'),
(85, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Assessment changed from  to Network'),
(86, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Job_description changed from  to Service'),
(87, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Job_details changed from  to Replaced LAN cable'),
(88, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Participation changed from  to Performed'),
(89, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Approval_status changed from Not Approved to Approved'),
(90, '2019-06-11 02:17:15', 'Rizza Joy Batuyong', '190611-001', 'Respondent changed from  to tech1'),
(91, '2019-06-11 02:17:16', 'Rizza Joy Batuyong', '190611-001', 'Job_status changed from Open to Ongoing'),
(92, '2019-06-11 02:17:16', 'Rizza Joy Batuyong', '190611-001', 'Remarks changed from  to MarkyMarkyMarky'),
(93, '2019-06-14 07:12:06', 'tech1', '190610-002-A', 'Ticket escalated with the following parameters: , , BGY Sec, System Issues'),
(94, '2019-06-14 07:19:00', 'tech1', '190610-002-B', 'Ticket escalated with the following parameters: , , BGY Sec, System Issues'),
(95, '2019-06-14 07:22:50', 'tech1', '190610-002-C', 'Ticket escalated with the following parameters: 4554, , BGY Sec, System Issues'),
(96, '2019-06-14 07:24:14', 'tech1', '190610-002-D', 'Ticket escalated with the following parameters: 4554, Carlos Mancin * escalated from tech1,tech1,tech1, BGY Sec, System Issues'),
(97, '2019-06-14 07:26:15', 'tech1', '190610-004-A', 'Ticket escalated with the following parameters: 0, T. Tinio, CRO, Data Issues'),
(98, '2019-06-18 06:18:40', 'Rizza Joy Batuyong', '190610-005', 'Participation changed from  to Consultation'),
(99, '2019-06-18 06:23:18', 'Rizza Joy Batuyong', '190610-005', 'Participation changed from Consultation to Performed'),
(100, '2019-06-18 06:26:18', 'Rizza Joy Batuyong', '190610-005', 'Approval_status changed from Approved to Not Approved'),
(101, '2019-06-18 06:32:44', 'Rizza Joy Batuyong', '190610-005', 'Approval_status changed from Not Approved to Approved'),
(102, '2019-06-18 06:34:29', 'Rizza Joy Batuyong', '190610-005', 'Approval_status changed from Approved to Not Approved'),
(103, '2019-06-21 04:32:26', 'Mark Lastica', '190621-001', 'Ticket created with the following parameters: 78787,Mark Lastica,Budget,Equipment - Mobile Device - Ayaw bumukas'),
(104, '2019-06-21 04:39:29', 'Rizza Joy Batuyong', '190621-001', 'Participation changed from  to Supervised'),
(105, '2019-06-21 04:39:29', 'Rizza Joy Batuyong', '190621-001', 'Approval_status changed from Not Approved to Approved'),
(106, '2019-06-21 04:39:30', 'Rizza Joy Batuyong', '190621-001', 'Job_status changed from Ongoing to Completed'),
(107, '2019-06-21 04:39:30', 'Rizza Joy Batuyong', '190621-001', 'Remarks changed from  to User Error'),
(108, '2019-06-21 04:39:45', 'Rizza Joy Batuyong', '190621-001', 'Remarks changed from Rizza Joy Batuyong<2019-06-21 12:39:30>:User Error-:- to Hindi nacharge ng user'),
(109, '2019-06-21 04:55:54', 'Mark', '190621-002', 'Ticket created with the following parameters: 43,Mark,Budget,Data or Storage Device - fghj'),
(110, '2019-06-21 04:56:19', 'tech1', '190610-004-B', 'Ticket escalated with the following parameters: 0, T. Tinio, tech1, CRO, Data Issues'),
(111, '2019-06-21 04:58:02', 'tech1', '190610-002-E', 'Ticket escalated with the following parameters: 4554, Carlos Mancin * escalated from tech1,tech1,tech1, tech1, BGY Sec, System Issues'),
(112, '2019-06-21 05:26:45', '4242', '190621-003', 'Ticket created with the following parameters: 091091,4242,BAC,Connection - System - 4242'),
(113, '2019-06-24 08:03:16', 'tech3', '190508-011-A', 'Ticket escalated with the following parameters: 9999333, Jo, ITSS, Nag-away ng mag-asawa'),
(114, '2019-06-24 08:11:49', 'tech3', '190603-009-A', 'Ticket escalated with the following parameters: 42424, 444242, BAC, ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `device_changelog`
--
ALTER TABLE `device_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- Indexes for table `device_list`
--
ALTER TABLE `device_list`
  ADD UNIQUE KEY `device_id` (`device_id`),
  ADD KEY `device_id_2` (`device_id`);

--
-- Indexes for table `field_values_changelog`
--
ALTER TABLE `field_values_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`),
  ADD KEY `ticket_id` (`ticket_id`),
  ADD KEY `ticket_id_2` (`ticket_id`),
  ADD KEY `ticket_id_3` (`ticket_id`);

--
-- Indexes for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  ADD PRIMARY KEY (`log_number`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `device_changelog`
--
ALTER TABLE `device_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `field_values_changelog`
--
ALTER TABLE `field_values_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ticket_changelog`
--
ALTER TABLE `ticket_changelog`
  MODIFY `log_number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
