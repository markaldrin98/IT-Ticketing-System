<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="refresh" content="60">
  <title>IT Ticketing System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <!-- Bootstrap core CSS -->
  <link href="bootstrap/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
  <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic,700italic' rel='stylesheet' type='text/css'>
  
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/createticket.css">
  <!-- Custom styles for this template -->
</head>
<style>
 body {width:100%; height:100%; overflow:hidden !important; margin:0; }
 html {width:100%; height:100%; overflow:hidden; }
</style>

<?php
  if(checkGet('deactivate_success')){
    $deactivatedTech=getTechDetails(checkGet('deactivate_success'));
    sendAlert("Succesfully deactivated ".$deactivatedTech['employee_name']);
  }
  else if(checkGet('deactivate_failure')){
    $deactivatedTech=getTechDetails(checkGet('deactivate_success'));
    sendAlert("Failed to deactivate ".$deactivatedTech['employee_name']);
  }
?>

<body id="page-top">
  <!-- Header -->
  <header class="masthead">
    <div class="container">
      <div class="intro-text">
        <div class="intro-lead-in">Welcome to the ITDO Ticketing Portal!</div>
        <div class="intro-heading text-uppercase">It's Nice To Meet You!</div>
        <a href="createticket.php" class="btn btn-primary btn-xl text-uppercase js-scroll-trigger" href="#services">Create A Ticket</a>
        <br><br>
        <div class="contactUs">Contact Us
        <div class="small">Direct - 336-5689 | Local - 2221</div>
        </div>
      </div>
    </div>
  </header>
</div>
</body>

</html>
<script>

window.onload=loadingScreen();
</script>