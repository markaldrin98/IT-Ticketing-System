<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/ticketcreated.css">
</head>
<body>

<center>
  <div class="container marginTop">
    <div class="page-header">
    <h3 class="whiteText">Success!</h3>
      <p class="whiteText">Your ticket was successfully sent to the IT Department.</p>
      <?php
        if(checkPost('ticket_id')!=false){
          
          if(callUser()){//if there is a user logged in
            echo "<h3 class='whiteText'>Your ticket number is</h3><h1 class='whiteText'><a href='viewticket.php?ticket_id=".checkPost('ticket_id')."'><".checkPost('ticket_id')."></a></h1>";
          }
          else{
            echo "<h3 class='whiteText'>Your ticket number is</h3><h1 class='whiteText'><".checkPost('ticket_id')."></h1>";            
          }
        }
      ?>
      <p class="whiteText">Click <a href="createticket.php">here</a> to return to ticket creation.</p>

      
    </div>
</div>
</center>
<div class="row">
<center>

 </center>
</div>
</body>
</html>
