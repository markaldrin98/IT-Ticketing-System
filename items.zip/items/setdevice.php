<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<?php
if(checkPost('Submit')) {//checks if device_id is set
            $device_id=checkPost('device_id');
            $updateQuery="UPDATE tickets SET device_id='".$device_id."' WHERE ticket_id='".checkPost('ticket_id')."'";
            //$updateResult = mysqli_query($conn,$updateQuery);
            if($updateResult = mysqli_query($conn,$updateQuery)){
                redirect('activeticket.php');
            }
            else {    //report sql error
                echo mysqli_error($conn);
            }
}
else{
    redirect('index.php');
}
                  
?>
</div>
