<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/createticket.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
</head>
<body>
<div class="container" style="max-width: 600px;">
  <br>
  <div class="lineBorder">
<form class="login100-form validate-form" action='createuser.php' method='post'>
<center>
  <img src="img/ITDOLogo.png" width="40%">
  <br><br>
  <h2>Register A New User</h2>
</center>
<br>
<center>
  <?php

    if(checkUserPrivilege()!="admin"){
      redirect('index.php');
    }

    if(checkGet('attempt')=='success'){
      echo "<span style='color:green;'>";
      echo "Registration of new ".checkGet('user_type')." ".checkGet('newUser')." was successful!";
    }
    else if(checkGet('attempt')=='failure'){
      echo "<span style='color:red;'>";
      echo "Registration of new ".checkGet('user_type')." ".checkGet('newUser')." was not successful.";
      echo checkGet('message');
    }
    echo "</span>";
  ?>
</center>
    <div class="form-group">
      <label for='employee_name'  title="Enter new user's full name" data-title='Name'>Name</label>
      <input type="text" required autocomplete="off" class="form-control" name="employee_name" placeholder="Enter new user's full name"/>
    </div>	
    <div class="form-group">
      <label for='username' title='Name' data-title='Name'>Username</label>
      <input type="text" class="form-control" required autocomplete="off" required name='username' placeholder="Enter new user's username">
    </div>        
    <div class="form-group">
      <label for='user_type' title="User Type" data-title="User Type">User Type</label>
         <select class="form-control" name="user_type" required>
         	<option disabled selected value="">--select a user type--</option>
          <option value="intern">Intern</option>
          <option value="tech">Tech</option>
          <option value="admin">Admin</option>
         </select>
    </div>
    <input type='submit' class="btn btn-default sendTicketBtn" name='Submit' class="form-submit" value="Register User"/>
</form>
</div>
</div>
<br>
</div>
</body>

<script>


</script>
</html>