<?php include 'misc/config.php';?>
<?php
	//redirect('index.php');
?>
<div style="color:white;">

<style>
/* Tooltip container */
.tooltip {
  position: relative;
  display: inline-block;
  border-bottom: 1px dotted black; /* If you want dots under the hoverable text */
}

/* Tooltip text */
.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  padding: 5px 0;
  border-radius: 6px;
 
  /* Position the tooltip text - see examples below! */
  position: absolute;
  z-index: 1;
}

/* Show the tooltip text when you mouse over the tooltip container */
.tooltip:hover .tooltiptext {
  visibility: visible;
}
</style>

<script>
function hideTables(){
  console.log("Hiding tables");
  tableElements = document.getElementsByClassName('fieldDiv');
  for(counter=0;counter<tableElements.length;counter++){
    tableElements[counter].style.display='none';
  }
}

function showTable(tableSelect){
  hideTables();
  document.getElementById(tableSelect.value).style.display='block';
}
</script>

<div style="color:white;">
<?php
echo "<br><br><br><br><br><br><br>";



      $values=retrieveOptionsNum('designation',true);
      print_r($values);
      toConsole(in_array('Cecil III',$values));

?>
 <br>
<div class="tooltip">Hover over me
  <span class="tooltiptext">Tooltip text</span>
</div>

    <script>
        function endChanged(){
        startDate = document.getElementById('startDate');
        endDate = document.getElementById('endDate');
            startDate.max=endDate.value;
            if(startDate.value > endDate.value){
                startDate.value = endDate.value;
            }
        }
        function startChanged(){
        startDate = document.getElementById('startDate');
        endDate = document.getElementById('endDate');
            endDate.min=startDate.value;
            if(endDate.value < startDate.value){
                endDate.value = startDate.value;
            }
        }
    </script>

<input form='searchForm' type='date' id='startDate' class='form-control' name='startDate' value='$startDate' max='$endDate' onchange='startChanged()'>

 <table>
 	<tr>
 		<td></td><td></td>
 	</tr>
 	<tr>
 		<td></td><td></td>
 	</tr>
 </table>
</div>

</div>
<script>  
hideTables();

</script>