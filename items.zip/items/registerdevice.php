<?php include 'misc/config.php';?>
<?php

$insertCheck = false;
$updateCheck = false;

if(checkPost('device_type')) {//checks if device_id is set
    $device_type=escapeString(checkPost('device_type'));
    $owner=escapeString(checkPost('owner')); //retrieves posted values
    $office=checkPost('office');
    $ticket_id=checkPost('ticket_id');
    $current_time= date('Y-m-d H:i:s');

    //---------------BELOW CODE BLOCK FORMS START OF THE NEW DEVICE'S ID STRING---------------//
    $idString = '';
    switch(checkPost('device_type')){
        case 'Desktop':
            $idString = 'DT-';
        break;
        case 'Laptop':
            $idString = 'LT-';
        break;
        case 'Mobile Device':
            $idString = 'MD-';
        break;
        case 'Tablet':
            $idString = 'TB-';
        break;
        default:
            $idString = 'TH-';
        break;
    }
        $idString .= date('Y');

    //---------------BELOW CODE BLOCK CHECKS device_list TO DETERMINE NEW DEVICE'S device_id----------------//
    $idQuery="SELECT MAX(RIGHT(device_id, 5)) AS 'maxim' FROM device_list WHERE device_id LIKE '".$idString."%'";
        $idResult = mysqli_query($conn,$idQuery);
            if(!$idResult || mysqli_num_rows($idResult)==0) {//no appropriate records are extant
                toConsole('No device of this type registered yet');
                $idString.="00001";
            }
            else{
                $idRes = mysqli_fetch_array($idResult);
                toConsole('Retrieved '.$idRes["maxim"]);
                $idString .= sprintf('%05d',(intval($idRes['maxim'])+1));
            }

    //---------------BELOW CODE BLOCK INSERTS NEW DEVICE INTO DB & LOGS TRANSACTION----------------//
    $queryString = 'INSERT INTO device_list VALUES ("'.$idString.'","'.$device_type.'","'.$owner.'","'.$office.'","'.$current_time.'");'; //query string to create entry in the ticket table - probs more efficient to just use joins for the extra details
   if (mysqli_query($conn, $queryString)) {
    //echo $qString;    
        $logString=mysqli_real_escape_string($conn,"Device registered - ".$device_type." belonging to ".$owner." at ".$office.".");
        logDeviceChange(callUser(), $idString, $logString);
        $insertCheck = true;
    } 
    else {    //report sql error
        echo mysqli_error($conn);
    }

    $queryString = 'UPDATE tickets SET device_id = "'.$idString.'" WHERE ticket_id="'.$ticket_id.'"';  
        if (mysqli_query($conn, $queryString)) { 
            $updateCheck = true;
        }

    if($insertCheck && $updateCheck){
        toConsole('Redirecting');
        if(checkPost('trail')){
            redirect(checkPost('trail'));
        }
        else{
            redirect('activeticket.php');
        }
    }
    else{
        toConsole('Doing nothing');
    }
}
else{
    redirect('index.php');
}
                  
?>

