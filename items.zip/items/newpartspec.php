<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<?php
if(checkPost('Submit')) {//checks if device_id is set
    $operation = checkPost('Submit');
    $target = '';
    $field = '';
    $type = '';
    $device_id = checkPost('device_id');
    $value = checkPost('new_value');
    $details = checkPost('new_detail');
    $redirect = checkPost('trail');
    toConsole($redirect);
    toConsole("Operation: ".$operation);

    if($operation == 'Add Peripheral'){
        $target = 'device_parts_table';
        $type = 'peripheral';
    }
    else if($operation == 'Add Specification'){
        $target = 'device_specs_table';
        $type = 'specification';
    }

    if($value == "Others"){//clause detects if "Others" was selected, adjusts query accordingly
        //code block inserts specified value into field_values
        if(!array_key_exists(checkPost('new_item'),retrieveOptions($type,true))){//given value is not included in the options
            $insertQuery = "INSERT INTO field_values values('$type','".checkPost('new_item')."',NULL)";    
            if(mysqli_query($conn, $insertQuery)) {
                echo "Insertion of new option succeded";
            }
            else{
                echo "Insertion of new option failed";
            }
            logFieldValueChange(callUser(),"Added: $type - checkPost('new_item')");
        }
        $value = $checkPost('new_item');//query below will save the value specified on the form instead of "Others"
    }

    $insertQuery = "INSERT INTO ".$target." VALUES('$device_id','$value','$details')";
    echo $insertQuery;
    echo "<br><br><br><br><br>";
    if(mysqli_query($conn, $insertQuery)) {
        echo "Query successful";
        if($redirect){
            toConsole("Redirecting to : ".$redirect);
            $logString = "Registered new ".$type.": ".$value." - ".$details;
            logDeviceChange(callUser(),$device_id,$logString);
            redirect($redirect."?device_id=".$device_id);
        }
    } 
    else{
        echo "Query failure";
        echo $insertQuery;
        checkSQLError();
    }
}
else{
    redirect('index.php');
}
                  
?>

</div>