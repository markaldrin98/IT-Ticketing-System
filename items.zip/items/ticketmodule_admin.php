
<?php
function displayAdmin(){    //function that displays admin interface
        global $colorSwitch,$conn;
        $specialMessage='';
        $resultString="";
        if(checkPost('searchstr')!=false){  //code block chooses what to output based on posted search box - comment this code block out if using JS search filter
            $searchString = checkPost('searchstr');
            $resultString .= "
            SELECT * FROM tickets 
            WHERE 
                (client_name LIKE '%$searchString%' 
                OR client_last_name LIKE '%$searchString%' 
                OR client_first_name LIKE '%$searchString%' 
                OR job_details LIKE '%$searchString%' 
                OR job_description LIKE '%$searchString%' 
                OR office LIKE '%$searchString%' 
                OR remarks LIKE '%$searchString%' 
                OR assessment LIKE '%$searchString%' 
                OR concern LIKE '%$searchString%'  
                OR concern_details LIKE '%$searchString%'
                OR respondent LIKE '%$searchString%' 
                OR admin LIKE '%$searchString%' 
                OR ticket_id LIKE '%$searchString%'
                )";
            //$resultString = "SELECT * FROM tickets ";
            //above query selects all tickets that are either not completed or not approved and have no tech assigned and satisfy search query
        }
        else{
            $resultString .= "SELECT * FROM tickets WHERE 1";
            //above query selects all tickets that are either not completed or not approved
        }
        if($startDate = checkPost('startDate')){
            $resultString .= " AND date_created >= '$startDate'";
        }
        if($endDate = checkPost('endDate')){
            $resultString .= " AND date_created <= '$endDate'";
        }
        $resultString.=" ORDER BY date_created DESC";    

        $result = mysqli_query($conn,$resultString);
        echo("<!--".$resultString."-->");
        //toConsole(addslashes($resultString));
        if(!$result || mysqli_num_rows($result)==0) {//checks to make sure there are tickets to be displayed
            //$specialMessage="<p class='whiteText'>No tickets to display!</p>";
            echo $specialMessage;
        }
        else{
        }
            //code block initializes the head row of the ticket table
            echo "  
                <thead>
                <tr bgcolor='#AAAAAA' height='40' style='width:100%;'>";
                    $fieldArray = retrieveFields('tickets');
                    $fieldsToShow = array("date_created","ticket_id","office","client_name","concern","respondent");
                    for($i=0;$i<count($fieldArray)-1;$i++){
                        if(in_array($fieldArray[$i],$fieldsToShow)){ //if field should be displayed
                            echo "<th class='headerStyle'>".ucwords(str_replace('_',' ',$fieldArray[$i]))."
                            </th>";                            
                        }
                        else{                            
                            echo "<th class='headerStyle' style='display:none;'>".ucwords(str_replace('_',' ',$fieldArray[$i]))."
                            </th>";              
                        }
                    }
                echo "<th style='display:none;'>rems</th></tr></thead><tbody>";  
            $rowCount = mysqli_num_rows($result);
            if(!$rowCount){
                echo "<tr class='whiteText'><td colspan='100%' style='text-align:center;'>No tickets to display!</td></tr>";
            }
            while($res = mysqli_fetch_array($result,MYSQLI_ASSOC)) {             //iterates through all tickets
                $optionString = "";

                    echo '<tr 
                    ';
                    $classes = "";
                    //below code block determines which color a row should have
                    $priority = "0";
                    if($res['job_status']=='Escalated'){
                        $priority = "1";
                        $classes .= "rowText rowColorRed";
                    }
                    else if($res['job_status']=='Suspended'){//ticket has been suspended
                        $priority = "2";
                        $classes .= "rowText rowColorYellow";
                    }
                    else if($res['job_status']=='Ongoing'){//ticket has been accepted and is currently in progress
                        $priority = "3";
                        $classes .= "rowText rowColorGreen";
                    }
                    else if(($res['job_status']=='Closed') && ($res['approval_status']!='Approved')){//tech has marked the ticket 'finished' but the ticket is still waiting for admin approval           
                        $priority = "4";
                        $classes .= "rowText rowColorBlue";
                    }
                    else if($res['job_status']=='Open'){//ticket has an undefined status || ticket is open
                        $priority = "6";
                    }
                    else if((($res['job_status']=='Closed') || $res['job_status']=='Unresolved' || $res['job_status']=='Unresolved - Escalated') && ($res['approval_status']=='Approved')){//tech has marked the ticket 'finished' and the ticket has been approved by the admin, ticket is archived
                        $priority = "5";
                        $classes .= "rowText rowColorGray";
                    }
                    echo "data-priority='$priority'";

                        if($res['date_fulfilled'] && $res['approval_status']=='Approved'){//checks if the ticket has been completed - if so, makes the ticket invisible
                            echo ' data-completion-status="completed"';
                            $classes.=" completed_ticket pointerElements";
                        }
                        else{
                            echo ' data-completion-status="not completed"';
                            $classes.=" incomplete_ticket pointerElements";
                        }
                    echo " class=\"$classes\"";
                    //echo 'onclick="callModal('.$res["ticket_id"].')"';   
                    echo ' onclick="viewTicket(this)" id="'.$res["ticket_id"].'"';
                    echo '>';
                    /*for($i=0;$i<count($res);$i++){
                        echo "<td>".$res[i]."</td>";
                    }*/

                    foreach ($res as $key => $value) {       
                            //echo "<td>".."</td>";                 
                            if ($key == 'is_archived' || $key == 'remarks'){
                                if($key=='remarks'){
                                        echo "<td style='display:none;'>".prepareChatlog($value)."</td>";
                                }
                                else{
                                    echo "<td style='display:none;'>".$value."</td>";
                                }        
                            }
                            else if($key=='client_name'){
                                    echo "<td style='' class='expandTD'>".$res['client_first_name']." ".$res['client_last_name']."</td>";
                            }
                            else if($key=='job_status'){
                                    echo "<td class='jstatus' style='display:none;'>".$value."</td>";
                            }
                            else{       
                                if(in_array($key,$fieldsToShow)){//if field should be displayed, true
                                    //echo "<td style='display:none;'>".$value."</td>";
                                    echo "<td style='' class='expandTD'>".$value."</td>";
                                }
                                else{//field should not be displayed
                                    echo "<td style='display:none;'>".$value."</td>";
                                }
                            }
                    }
                    echo "</tr>";

            }//end of while loop
            echo '
                        </tbody></table> 
                    </div>
                
                        <center>
                            <!--<input form="mainForm" class="btn btn-default" type="submit" name="Submit" value="Save Changes" 
                            style="background-color: #242e39; border-color: black; color:white; padding: 15px; width: 20%;">-->';
                            //code block closes table

    }//end of displayAdmin function
?>