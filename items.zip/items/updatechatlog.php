<?php include 'misc/config.php';?>
<div style="color:white;">

<?php
if(checkPost('Submit')){
	//do nothing
}
else{
	redirect('index.php');
}
        $ticket_id=checkPost("ticket_id");
        $qString ='SELECT * FROM tickets WHERE ticket_id="'.checkPost("ticket_id").'"';//retrieves ticket with the same id as the id posted
        $result = mysqli_query($conn,$qString);
        $res = mysqli_fetch_array($result);
        
        $queryString = "UPDATE tickets SET ticket_id='".checkPost("ticket_id")."'";//initializes update query
                  
                        $oldRemark = mysqli_real_escape_string ($conn,$res['remarks']);//escapes stored chat log
                        $currentUser = mysqli_real_escape_string ($conn,callUser());
                        $newRemark = checkPost('remarks');//formats new remark
                        $newRemark = mysqli_real_escape_string ($conn,$newRemark);//escapes new remark
                        if($oldRemark==''){//code block determines if chat log is empty - if it is, insert a new remark - if it isn't, add new remark to old remark string
                            $queryString.=", remarks= CONCAT('".$currentUser."<',now(),'>:".$newRemark."-:-"."')";
                        }
                        else{
                            $queryString.=", remarks= CONCAT('".$oldRemark."','".$currentUser."<',now(),'>:".$newRemark."-:-"."')"; 
                        }
        $queryString.= " WHERE ticket_id='".checkPost("ticket_id")."'";
        print($queryString);

        if(mysqli_query($conn,$queryString)){//ticket updated, return to outstanding.php
            toConsole("Update success!");
            //var_dump($queryString);
            if($trail=checkPost('trail')){
                redirect($trail); 
            }
            else{
                redirect("outstanding.php?attempt=success&ticket_id=$ticket_id&op=update");           
            }
        }
        else{
            toConsole("Update failure!");
            var_dump($queryString);
            checkSQLError();
        }
?>

</div>