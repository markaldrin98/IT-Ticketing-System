<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/changepass.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
 
</head>
<div class="container" style="max-width: 600px;">
  <br>
  <div class="lineBorder">

  <?php

//echo $_SESSION['loggedin'];
    if(callUser()){      
    }
    else{
      redirect("index.php");
    }
    echo "
    <form class='login100-form validate-form' action='processpass.php' method='post'>
      <center>
        <img src='img/ITDOLogo.png' style='width: 40%;'>
        <br><br>
        <h2>Change Password</h2>
        <br>     
      </center>                      
";

if(strtoupper(checkGet('attempt'))=='FAILED'){//if a previous attempt to change password returned 'failed'
  echo "<center><p style='color:red;'>Incorrect password provided!</p></center>";
}
else if(strtoupper(checkGet('attempt'))=='SUCCESS'){
  echo "<center><p style='color:green;'>Password changed successfully.</p></center>";
}
  echo "    
      <div class='form-group'>
          <label>Username</label>
          <input type='text'  placeholder='".callUsername()."' class='form-control' disabled>
      </div>        
      <div class='form-group'>
      <label>Old Password</label>
        <div class='input-group mb-3'>
              <input type='Password' class='form-control myInput' id='oldpass' required name='oldpass' name='password'>
            <div class='input-group-append'>";

?>

              <button class='btn btn-outline-primary' type='button' id='button-addon2' onclick='showPass("oldpass",this)'><i id='changeIcon' class='fa fa-eye'></i></button>
            </div>
        </div>
    </div>

      <div class='form-group'>
        <label for='newpass' title='Enter your New Password' data-title='New Password'>New Password</label>
          <div class='input-group mb-3'>
              <input type='Password' id='newpass' required name='newpass' class='form-control' onkeyup='checkPassMatch();'>
              <div class='input-group-append'>
                <button class='btn btn-outline-primary' type='button' id='button-addon2' onclick='showPass("newpass",this)'><i id='changeIcon' class='fa fa-eye'></i></button>
              </div>
          </div>
      </div>

      <div class='form-group'>
        <label for='confirmnewpass' title='Confirm your New Password' data-title='Confirm New Password'>Confirm New Password</label>
          <div class='input-group mb-3'>
            <input type='Password' id='confirmpass' required name='confirmpass' class='form-control' onkeyup='checkPassMatch();'>
            <div class='input-group-append'>
                <button class='btn btn-outline-primary' type='button' id='button-addon2' onclick='showPass("confirmpass",this)'><i id='changeIcon' class='fa fa-eye'></i></button>
              </div>
          </div>
          <p id='message'></p>
      </div>

            <?php echo"
                   
            <input type='submit' value='Update' id='updatePass' name='Submit' class='btn sendTicketBtn'>
    </div>
  <input type='hidden' name='trail' value='".getUrl('base')."'>
</form>

";
    
  ?>
  <br>
</div>
</div>
</center>
</div>
</body>
</html>
<script>
function checkPassMatch() {
  console.log("checkPassMatch called");
  if ((document.getElementById('newpass').value == document.getElementById('confirmpass').value) && (document.getElementById('newpass').value.length > 6)) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = ' Matching';
    document.getElementById('updatePass').disabled = false;
  } 
  else {
      if(document.getElementById('newpass').value.length <= 6){
      document.getElementById('message').style.color = 'red';
      document.getElementById('message').innerHTML = ' Password must be longer than 6 characters';
      document.getElementById('updatePass').disabled = true;
      }
      else{
      document.getElementById('message').style.color = 'red';
      document.getElementById('message').innerHTML = ' Not Matching';
      document.getElementById('updatePass').disabled = true;
      }
  }
}

function showPass(pass_id,icon_element) {
  var x = document.getElementById(pass_id);
  var iconChange = document.getElementById("changeIcon");

  if (x.type === "password") {
    x.type = "text";
    icon_element.innerHTML = "<i class='fa fa-eye-slash'></i>";

  } else {
    x.type = "password";
    icon_element.innerHTML = "<i class='fa fa-eye'></i>";
  }
}

</script>
