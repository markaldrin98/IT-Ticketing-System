<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php
include_once("misc/config.php");  

    global $conn;

echo "<br><br><br><br><br><br><br><br>";  
    if(checkPost("Submit")){//checks to see if 'Submit' has been posted - if it is not set, then the user accessed this page through unintended channels
        $device_id=checkPost("device_id");
        $owner=checkPost("owner");
        $office=checkPost("office");
        $trail=checkPost("trail");

        $deviceDetails=getDeviceDetails($device_id);

        $updateQuery = "UPDATE device_list SET office='$office', owner='$owner' WHERE device_id='$device_id'";
        if($updateResult = mysqli_query($conn, $updateQuery)){
            if($owner != $deviceDetails['owner']){
                logDeviceChange(callUser(),$device_id,("Owner changed from ".$deviceDetails['owner']." to "."$owner."));
            }
            if($office != $deviceDetails['office']){
                logDeviceChange(callUser(),$device_id,("Office changed from ".$deviceDetails['office']." to "."$office."));
            }
            if($trail)redirect($trail);
            else redirect('devicemanagement.php');
        }
        else{
            checkSQLError();
        }
    }
    else{
        redirect('index.php');//and should thus be redirected back to the index
    }


?>

</div>