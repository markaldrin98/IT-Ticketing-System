<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/devicemanagement.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
  <link rel="stylesheet" type="text/css" href="css/fontStyle.css">
 </head>
<body>
<div class="container" id="big_container" style="margin-top: 80px; max-width: 800px;">

<?php
    global $searchstr;
    global $adminModalId;
    global $techModalId;
    $searchstr='';
    if(isset($_POST['searchstr']) && $_POST['searchstr']!=''){
        $searchstr = $_POST['searchstr'];
    }
        echo '
            <!--html for search bar and associated filters-->
                <!--<form id="searchForm" name="searchForm "method="post" action="outstanding.php"></form>-->
                <!--<input form="searchForm" type="submit" name="Submit" value="Search" style="background-color: #242e39; border-color: black; color:white;">-->
                <center>
                    <div class="input-group" style="max-width: 500px;"> 
                        <input type="text" class="form-control  radiusLeft" type="text" name="searchstr" id="searchstr" placeholder="Search...">

                            <div class="input-group-btn">
                                <input form="searchForm" type="submit" value="Search" id="searchButton" name="searchButton" class="btn btn-default radiusCenter" onclick="filterTable()">
                                <input form="searchForm" type="submit" value="Reset" id="resetButton" name="resetButton" class="btn btn-default radiusRight" onclick="resetTable()">
                                <br><br>
                            </div>
                    </div>
                </center>
            <!-- end of html for search bar and associated filters-->
        ';
        ?>
    <center>
<?php
    $specialMessage='';//used to output 'no tickets to display' where there are no tickets to display

  $colorSwitch=0;
?>
    
    <form method="post" id="mainForm" action="updatetickets.php"></form>
    <form method="post" id="acceptForm" action="acceptticket.php"></form>

    <!--START OF THE VERY LARGE DISPLAY TABLE-->
    <div class="table-responsive">
    <table width='100%' border=0  id="outputTable" name="outputTable">

<?php 

    global $colorSwitch,$conn;
        $specialMessage='';

        $result = mysqli_query($conn, "SELECT * FROM device_list ORDER BY device_id DESC");
        //above query selects all devices

        if(!$result || mysqli_num_rows($result)==0) {//checks to make sure there are devices to be displayed
            $specialMessage="<p class='whiteText'>No devices to display!</p>";
            echo $specialMessage;
        }
        else{
        }
            //code block initializes the head row of the ticket table
            echo "
                <tr bgcolor='#AAAAAA' height='40' style='width:100%;'>";
                    $fieldArray = retrieveFields('device_list');
                    for($i=0;$i<count($fieldArray);$i++){
                        echo "<th class='headerStyle' style=''>".ucwords(str_replace('_',' ',$fieldArray[$i]))."
                        </th>";//formats table header columns
                    }
                echo "</tr>";  

            while($res = mysqli_fetch_array($result,MYSQLI_ASSOC)) {//iterates through all devices
                $optionString = "";

                    echo '<tr
                    ';
                    echo ' onclick="viewTicket(this)" id="'.$res["device_id"].'"';
                    echo '>';
                    /*for($i=0;$i<count($res);$i++){
                        echo "<td>".$res[i]."</td>";
                    }*/

                    foreach ($res as $key => $value) {
                        if ($key == 'is_archived' || $key == 'remarks'){
                            if($key=='remarks'){
                                echo "<td style='display:none;'>".prepareChatlog($value)."</td>";
                            }
                            else{
                                echo "<td style='display:none;'>".$value."</td>";
                            }        
                        }
                        else{                   
                            //echo "<td style='display:none;'>".$value."</td>";
                            echo "<td style=''>".$value."</td>";
                        }
                    }
                    echo "</tr>";

            }//end of while loop
            echo '
                        </table> 
                        <br>
                        <center><button class="btn btn-default buttonNewDevice"  data-toggle="modal" data-target="#deviceRegistrationModal">Add New Device</button></center>
                    </div>
                        <center>
                            <!--<input form="mainForm" class="btn btn-default" type="submit" name="Submit" value="Save Changes" 
                            style="background-color: #242e39; border-color: black; color:white; padding: 15px; width: 20%;">-->';
                            //code block closes table
        ?>
            
        <br><br>

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODAL CODE FOR CREATING A DEVICE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<!--
<div class="borderLine"> 
-->
<div class="ticket">
    <div class="modal fade" id="deviceRegistrationModal" style="color:black;">
        <div class="modal-dialog">
          <div class="modal-content">
                <div id="home" class="container tab-pane active">  
                    <div class="modal-header"><!-- Modal Header -->
                        <h4 class="modal-title">Register New Device</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body"><!-- Modal body -->
                      <form id='registerDeviceForm' action='createdevice.php' method='post'><!--form used to register new device-->
                        <?php createHiddenInput('trail',basename($_SERVER['PHP_SELF']));?>
                          <?php echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";?>
                          <div class="form-group">
                              <label>Device Type</label>
                                <?php
                                  $valueArray = retrieveOptions('device_type',true);
                                  outputSelect('device_type','',$valueArray,true);
                                ?>
                          </div>
                          <div class="form-group">
                              <label>Owner:</label>
                              <input type='text' class="form-control" name='owner' id='owner' required>
                          </div>
                          <div class="form-group">
                              <label>Office:</label>
                              <?php
                                $valueArray = retrieveOptions('office',true);
                                outputSelect('office',$res['office'],$valueArray,true);
                                createHiddenInput('trail',getUrl('FULL'));
                              ?>
                          </div>
                          <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Register">
                      </form>
                  </div>  
              </div>  
          </div>
        </div>
      <!--</div>--> 
  <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF MODAL CODE FOR SETTING A DEVICE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
</div>
</div>
</body>
<script>

var grandTable = document.getElementById('outputTable');

//------------------FUNCTION CHECKS WHICH CELLS UNDER TIME_ELAPSED COLUMN SHOULD BE UPDATED------------//
//currently not supported
function updateTimers(){    
    for (var i = 0, row; row = grandTable.rows[i]; i++) {   //iterates through the rows of grandTable/outputTable        
       //rows would be accessed using the "row" variable assigned in the for loop
            //function here to check whether date_accepted is set - index 1
        if((row.cells[1].innerHTML != "") && (row.cells[2].innerHTML == "")){   //date_accepted is set, date_fulfilled is not
            //console.log(row.cells[14]);
            toTick = row.cells[14].getElementsByTagName('span');
            clockTick(toTick[0],toTick[1],toTick[2]);
        }
    }
}
//------------END OF FUNCTION THAT CHECKS WHICH CELLS UNDER TIME_ELAPSED COLUMN SHOULD BE UPDATED------------//

//----------------------------------FUNCTION UPDATES TIME VALUES IN THE TIME_ELAPSED COLUMN------------------------------//
//currently not used
function clockTick(hourSpan, minuteSpan, secondSpan){ 
    var hours = parseInt(hourSpan.innerHTML);
    var minutes = parseInt(minuteSpan.innerHTML);
    var seconds = parseInt(secondSpan.innerHTML);

    seconds++;
    if(seconds==60){
      minutes++;
      seconds=0;
    }
    if(minutes==60){
      hours++;
      minutes=0;
    }
    hourSpan.innerHTML=hours.pad(2);
    minuteSpan.innerHTML=minutes.pad(2);
    secondSpan.innerHTML=seconds.pad(2);
}
//---------------------------END OF FUNCTION THAT UPDATES TIME VALUES IN THE TIME_ELAPSED COLUMN---------------------------//

function persistentClock(){ //calls the clock update function every second
setInterval(updateTimers, 1000);
}

//persistentClock(); //initializes timer scripts

window.onload=pageLoads();
window.onload=loadingScreen();
function pageLoads(){//called onload to trigger checkbox functions
    if(document.getElementById('showArchived')){
        toggleCbox(document.getElementById('showArchived'));        
    }
    if(document.getElementById('hideIncomplete')){
        toggleNegativeCbox(document.getElementById('hideIncomplete'));
    }
}

function setValue(elementId,setValue){//function to set .value of a control
    element = document.getElementById(elementId);
    element.value = setValue;
}

function setInner(elementId,setValue){//function to set innerHTML of an element
    element = document.getElementById(elementId);
    element.innerHTML = setValue;
}

function viewTicket(rowElement){
    window.location.href = "viewticket.php?ticket_id="+rowElement.id;
}

//-------------------JS FILTER FUNCTION FOR PURE TEXT TABLES-----------------//
var query = document.getElementById('searchstr');

    query.addEventListener("keydown", function (e) {//code block makes the search bar call filterTable() when enter is pressed
        if (e.keyCode === 13) {  //checks whether the pressed key is "Enter"
            filterTable();
        }
    });

var filter = query.value.toUpperCase();
var table = document.getElementById('outputTable');
var tr = table.getElementsByTagName('tr');
var td;
function filterTable(){ //(hopefully) filters table
    filter = query.value.toUpperCase();
    for (var i = 1; i < tr.length; i++) {//loops through each row
        //td = tr[i].getElementsByTagName("td");
        var rowToggle = false;
        for (var j = 0; j<tr[i].cells.length; j++){//loops through each cell in each row     
            txtValue = tr[i].cells[j].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {//if cell contains value similar to seach query
                //console.log("found "+filter);
                tr[i].style.display = "table-row";
                rowToggle = true;
            } 
            else {//query not in cell
                if(!rowToggle){
                    tr[i].style.display = "none";
                } 
                //console.log("did not find "+filter);
            }
        }
        console.log("row: "+rowToggle);
    }
}//--------------END OF JS FILTER FUNCTION FOR PURE TEXT TABLES-------------//


//---------------FUNCTION TO RESET THE TABLE TO ITS DEFAULT STATE----------------//
function resetTable(){
    query.value="";
    filterTable();
}
//-----------END OF FUNCTION TO RESET THE TABLE TO ITS DEFAULT STATE-------------//


//---------------FUNCTION TO REDIRECT TO viewdevice.php----------------//
function viewTicket(rowElement){
    window.location.href = "viewdevice.php?device_id="+rowElement.id;
}
//------------END OF FUNCTION TO REDIRECT TO viewdevice.php------------//

</script>
</html>