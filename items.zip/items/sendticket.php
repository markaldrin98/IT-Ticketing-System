'<?php include 'misc/config.php';?>
<?php
if(isset($_POST['Submit'])) {//checks if ticket was submitted
    //printPost();
    //input fields for ticket creation


    
    $employee_type=mysqli_real_escape_string($conn,$_POST['employee_type']);
    $last_name=mysqli_real_escape_string($conn,$_POST['last_name']);
    $first_name=mysqli_real_escape_string($conn,$_POST['first_name']);
    $employeename=escapeString($first_name." ".$last_name);
    $office=mysqli_real_escape_string($conn,$_POST['office']);
    $concern=mysqli_real_escape_string($conn,$_POST['concern']);
    $concern_details=mysqli_real_escape_string($conn,$_POST['concern_details']);
    //input fields for ticket creation

    $idQuery="SELECT MAX(RIGHT(LEFT(ticket_id, 10),3)) AS 'maxim' FROM tickets WHERE ticket_id LIKE '".date('ymd')."-%' HAVING maxim IS NOT NULL";
    $idResult = mysqli_query($conn,$idQuery);
        if(!$idResult || mysqli_num_rows($idResult)==0) {//no appropriate records are extant
            toConsole('No records for the current day');
            $idQuery=date('ymd')."-001";
        }
        else{
            $idRes = mysqli_fetch_array($idResult);
            toConsole('Retrieved '.$idRes["maxim"]);
            $idQuery=date('ymd')."-".sprintf('%03d',(intval($idRes['maxim'])+1));
        }

        $queryString = 'INSERT INTO tickets (ticket_id,employee_type,client_name,client_first_name,client_last_name,office,concern,concern_details,approval_status,job_status) VALUES ("'.$idQuery.'","'.$employee_type.'","'.$employeename.'","'.$first_name.'","'.$last_name.'","'.$office.'","'.$concern.'","'.$concern_details.'","Not Approved","Open");'; //query string to create entry in the ticket table - probs more efficient to just use joins for the extra details
           if (mysqli_query($conn, $queryString)) {
            //echo $qString;    
                $logString=mysqli_real_escape_string($conn,"Ticket created with the following parameters: ".$employee_type.",".$employeename.",".$office.",".$concern." - ").$concern_details;
                logChange($employeename, $idQuery, $logString);
                //redirect('ticketcreated.php?ticket='.$idQuery);
                echo "
                <form method='post' action='ticketcreated.php' id='passform'>
                    <input type='hidden' name='ticket_id' value='$idQuery'>
                </form>
                ";
                echo "
                <script>
                    
                </script>
                ";
            } 
            else {    //report sql error
                echo mysqli_error($conn);
            }
}
else{
    redirect('index.php');
}
                  
?>

