<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
$ticket_id = $_POST["ticket_id"];

$assignCheck = false;   //gate variable
$ticketCheck = false;   //gate variable
printPost();

if(checkPost('Submit')=='Resume Ticket'){
    //below code block updates ticket currently assigned to the tech in the 'tech_credentials' table if Submit='Resume Ticket'
    $queryString = 'UPDATE tech_credentials SET current_ticket = "'.$ticket_id.'", suspended_ticket = NULL WHERE employee_name="'.$_SESSION["client_name"].'"';  
                   if (mysqli_query($conn, $queryString)) { 
                        //echo $queryString;
                        $assignCheck = true;
                    } 
                    else {    //report sql error
                    }
    //end of code block

    //below code block updates which tech is assigned to the ticket represented by $ticket_id in the 'tickets' table
    $queryString = 'UPDATE tickets SET date_accepted=now(), job_status = "Ongoing",respondent = "'.$_SESSION["client_name"].'" WHERE ticket_id="'.$ticket_id.'"';  
                   if (mysqli_query($conn, $queryString)) { 
                        $ticketCheck = true;
                        //echo $queryString;
                    } 
                    else {    //report sql error
                        //echo "<script>console.log('".$queryString."')</script>";
                    }
    //end of code block

}
else{
    if(checkTicketOwner($ticket_id)){
        redirect("outstanding.php?attempt=failed&ticket_id=$ticket_id");
    }
    //below code block updates ticket currently assigned to the tech in the 'tech_credentials' table if Submit='Accept Ticket'
    $queryString = 'UPDATE tech_credentials SET current_ticket = "'.$ticket_id.'" WHERE employee_name="'.$_SESSION["client_name"].'"';  
                   if (mysqli_query($conn, $queryString)) { 
                        //echo $queryString;
                        $assignCheck = true;
                    } 
                    else {    //report sql error
                    }
    //end of code block

    //below code block updates which tech is assigned to the ticket represented by $ticket_id in the 'tickets' table
    $queryString = 'UPDATE tickets SET date_accepted=now(), job_status = "Ongoing",respondent = "'.$_SESSION["client_name"].'" WHERE ticket_id="'.$ticket_id.'"';  
                   if (mysqli_query($conn, $queryString)) { 
                        $ticketCheck = true;
                        //echo $queryString;
                    } 
                    else {    //report sql error
                        //echo "<script>console.log('".$queryString."')</script>";
                    }
    //end of code block

}

    if($assignCheck && $ticketCheck){   //checks gate variables - if both gate variables return true, then both queries were successful and the page should redirect
        //echo "<script>console.log('"."Redirecting to activeticket"."')</script>";
        redirect('activeticket.php');
    }
    else{   //else do nothing
        //echo "<script>console.log('"."Doing nothing"."')</script>";
    }

?>

</div>