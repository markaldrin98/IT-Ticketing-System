<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/viewticket.css">
  <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />
</head>
<body>
<div id="primary_display" style="display:none;">
<?php
//code block to retrieve and then forward data to fields

$ticket_id='';
if(checkGet('ticket_id')){
  $ticket_id = checkGet('ticket_id');
  if(!ticketExists($ticket_id)){
    redirect("index.php");
  }
}
else{
  redirect('index.php');
}
$resultQueryString = "SELECT * FROM tickets WHERE ticket_id = '".$ticket_id."' ORDER BY date_created AND client_name DESC";//query to select user's active ticket from tickets table
          $result = mysqli_query($conn, $resultQueryString);
          if(!$result || mysqli_num_rows($result)==0) {//tech's active ticket doesn't exist - remove tech's active ticket
              $queryString = 'UPDATE tech_credentials SET current_ticket = NULL WHERE employee_name="'.$_SESSION["client_name"].'"';  
              if (mysqli_query($conn, $queryString)) {
                  $message = "<center>Ticket ".$ticket_id." does not exist!";
                  $message .= "<br>Click <a href='outstanding.php'>here</a> to select a new ticket.</center>";
                  $displayMainTable = "display:none";
                  $displayNullMessage = "";
              }               
          }   
          else{//record exists
            $res=mysqli_fetch_array($result);         

            toConsole("Current Ticket: ".checkCurrentTicket());
            toConsole("Ticket Being Viewed: ".$res['ticket_id']);
            if(checkCurrentTicket()==$res['ticket_id']){//if ticket being viewed is user's current ticket
              redirect("activeticket.php");
            }

            $ticket_id = $res['ticket_id'];
            $date_created = $res['date_created'];
            $date_accepted = $res['date_accepted'];
            $date_assessed = $res['date_assessed'];
            $date_fulfilled = $res['date_fulfilled'];
            $office = $res['office'];
            $client_name = $res['client_first_name']." ".$res['client_last_name'];
            $employee_type = $res['employee_type'];
            $concern = $res['concern'];
            $concern_details = $res['concern_details'];
            $assessment = $res['assessment'];
            $job_description = $res['job_description'];
            $job_details = $res['job_details'];
            $participation = $res['participation'];
            $approval_status = $res['approval_status'];
            $respondent = $res['respondent'];
            $job_status = $res['job_status'];
            $remarks = $res['remarks'];
          }
?>
<div class="container" id="adminModule">
  <div class="lineBorder">
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
      <?php
        //echo "<b style='font-size:20;'>Ticket ".$ticket_id."</b><br><br>";
        outputTitle("Ticket ".$ticket_id);
        echo '<div class="form-group"><input type="hidden" name="ticket_id" value="'.$ticket_id.'"></div>';
      ?>
             <div class="form-group">
                  <label>Date/Time Created:</label>
                  <textarea disabled id="date_created" name="date_created" class="form-control adjustHeight"><?php echo $date_created;?></textarea>
              </div>
              <div class="form-group">
                  <label>Date/Time Accepted:</label>
                  <textarea disabled id="date_accepted" name="date_accepted" class="form-control adjustHeight"><?php echo $date_accepted;?></textarea>
              </div>
              <div class="form-group">
                  <label>Date/Time Assessed:</label>
                  <textarea disabled id="date_assessed" name="date_assessed" class="form-control adjustHeight"><?php echo $date_assessed;?></textarea>
              </div>
              <div class="form-group">
                  <label>Date/Time Fulfilled:</label>
                  <textarea disabled id="date_fulfilled" name="date_fulfilled" class="form-control adjustHeight"><?php echo $date_fulfilled;?></textarea>
              </div>
          </div><!--end of ticket panel-->
          <br>

          <div class="lineBorder"><!--start of client panel-->
              <?php outputTitle("Client");?>
              <!--<div class="form-group">
                  <label>Ticket ID:</label>
                  <textarea disabled id="ticket_id_display" name="ticket_id_display" class="form-control"></textarea>
                  <input type="hidden" name="ticket_id" id="ticket_id" class="form-control"> 
              </div>-->

              <div class='form-group'>
                  <label>Office</label>
                  <div class="input-group mb-3">
                  <?php
                    $officeString=$res['office'];
                    echo "<input type='text' class='form-control' value='$officeString' disabled>";
                  ?>
                  <div class="input-group-append">
                    <button class='btn btn-info' data-toggle="modal" data-target="#editOffice"><i class='fa fa-pencil-alt outline'></i></button>
                  </div>
                </div>
              </div>

              <div class="form-group">
                  <label>Client Name:</label>
                  <!--<input type="text" class="form-control" id="client_name" name="client_name">-->
                  <div class="input-group mb-3">
                      <textarea disabled id="client_name" name="client_name" class="form-control adjustHeight" onkeyup="textAreaAdjust(this)"><?php echo $client_name;?></textarea>
                    <div class="input-group-append">
                      <button class='btn btn-info' data-toggle="modal" data-target="#editName"><i class='fa fa-pencil-alt outline'></i></button>
                    </div>
                  </div>
              </div>

              <div class="form-group">
                  <label>Employee Type:</label>
                  <!--<input type="text" class="form-control" id="employee_type" name="employee_type">-->
                  <textarea disabled id="employee_type" name="employee_type" class="form-control adjustHeight"><?php echo formatString($employee_type);?></textarea>
              </div>
              <div class="form-group">
                  <label>Concern:</label>
                  <textarea disabled id="concern" name="concern" class="form-control adjustHeight"><?php echo $concern;?></textarea>
              </div>
              <div class="form-group">
                  <label>Concern Details:</label>
                  <textarea id="concern_details" onfocus='textAreaAdjust(this)' name="concern_details" class="form-control"><?php echo $concern_details;?></textarea>
              </div>


            <form action='acceptticket.php' id="acceptForm" name="acceptForm" method='post'>
              <?php
                if((!checkCurrentTicket() && !$res['date_accepted'])){
                  echo '<input type="submit" value="Accept Ticket" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">';
                }
                createHiddenInput('ticket_id',$ticket_id);
              ?>
            </form>
            
            <?php
              //if(checkSuspendedTicket(callUsername())==$res['ticket_id'] && !checkCurrentTicket() && $res['job_status']=='Suspended'){  
              if(callUser()==$res['respondent'] && !checkCurrentTicket() && $res['job_status']=='Suspended'){                              
                  echo '
                    <form class="login100-form validate-form" action="acceptticket.php" id="resumeFormAdmin" name="resumeFormAdmin" method="post">
                    <input type="submit" value="Resume Ticket" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">';
                  createHiddenInput('ticket_id',$ticket_id);
                  echo '  </form>';
              }

            ?>
            </div><!--end of client panel-->
            <br>

            <!--this div needs css!-->
            <div class="lineBorder"> <!--Start of Borderline for History-->
              <legend class="headerStyle">Ticket History</legend>
              <?php
                getTicketHistory($ticket_id);
              ?>
            </div>
            <br>
  

            <div class="lineBorder"><!--start of assessment panel-->
              <?php outputTitle("Assessment");?>
            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
                <?php
                  $isAssessed = isset($date_assessed);
                  if(!$isAssessed){
                    echo "<div id='notAssessed'>
                      <center><p>This ticket has not been assessed by a tech yet.</p></center>
                      </div>";
                  }
                ?>

                  <div id='editAssessment' style='display:none;'>
                  <form id='finishAssessment' action='finishassessment.php' method='post'><!--form used to Close Ticket assessment-->
                  <dataset id="assessmentDataset">
                    <div class="form-group">
                        <label>Assessment:</label>
                        <?php
                          $valueArray = retrieveOptions('assessment',true);
                          outputSelect('assessment',$res['assessment'],$valueArray,true);
                        ?>
                    </div>
                    <div class="form-group">
                        <label>Job Description:</label>
                        <?php
                            $valueArray = retrieveOptions('job_description',true);
                            outputSelect('job_description',$res['job_description'],$valueArray,true);
                            //echo "<input type='text' name='job_description_others' id='job_description_others'>";
                              $valueArray = retrieveOptions('software',false);
                              outputSelect('software','',$valueArray,false);
                              echo "<input type='text' class='form-control' name='software_others' id='software_others' placeholder='Enter installed software...'>";

                              //below code block contains scripts that control secondary inputs (for when user selects 'others')    
                              echo "<script>
                              
                                window.load=updateJobDescriptionInputs();
                                      document.getElementById('software_others').required = false;
                                      document.getElementById('software_others').style.display = 'none';

                                document.getElementById('job_description').onchange=function(){
                                  updateJobDescriptionInputs();};
                                document.getElementById('software').onchange=function(){
                                  updateJobDescriptionInputs();};

                                function updateJobDescriptionInputs(){
                                  if(document.getElementById('job_description').value == 'Install'){
                                    document.getElementById('software').required = true;
                                    document.getElementById('software').style.display = 'block';
                                    if(document.getElementById('software').value == 'Others'){
                                      document.getElementById('software_others').required = true;
                                      document.getElementById('software_others').style.display = 'block';
                                    }
                                    else{
                                      document.getElementById('software_others').required = false;
                                      document.getElementById('software_others').style.display = 'none';
                                    }
                                  } 
                                  else{
                                    document.getElementById('software').required = false;
                                    document.getElementById('software').style.display = 'none';
                                  }
                                }
                              </script>";
                              //end of code block
                        ?> 
                    </div>
                    <div class="form-group">
                        <label>Job Details:</label>
                          <?php
                            echo "<textarea id='job_details' name='job_details' class='form-control' required>$job_details</textarea>";
                            echo "<br>";
                            echo '<input class="saveStyle" type="submit" name="Submit" value="Change Assessment">';
                            echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";
                          ?>
                    </div>
                    <?php
                      if($isAssessed){
                        echo "<script>document.getElementById('editAssessment').style.display='block';</script>";
                      }

                      //toConsole("TRAIL : ".getUrl('FULL'));
                      createHiddenInput('trail',getUrl('FULL'));
                    ?>
                    </dataset>
                  </form><!--form used to Close Ticket assessment--> 
                  </div> 

            <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO ASSESS TICKET~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
            </div><!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~end of assessment panel~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

        <br>
        <div class="lineBorder"><!--start of admin panel-->
          <?php outputTitle("Admin");?>              
          <form class="login100-form validate-form" action='updatetickets.php' id="adminForm" name="adminForm" method='post'>

          <div id="adminPanel">
              <div class="form-group">
                  <label>Participation:</label>
                  <?php
                    $valueArray = retrieveOptions('participation',true);
                    outputSelect('participation',$res['participation'],$valueArray,false);
                  ?>
              </div>
              <div class="form-group">
                  <label>Approval Status:</label>
                  <?php
                    outputSelect('approval_status',$res['approval_status'],array("Approved" => "","Not Approved" => ""),false);
                    echo "
                      <script>
                        if(document.getElementsByName('approval_status')[0].value == 'Approved'){
                          document.getElementsByName('approval_status')[0].disabled = true;
                        }
                      </script>
                    ";
                  ?>
              </div>              
              <input type="submit" value="Save Changes" name="Submit" class="saveStyle">
          </div>

          <div id="noTechPanel">
            <center>This ticket has not been assessed by a tech yet.</center>
          </div>
          <?php
              echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";//hidden input to send ticket_id to finishactiveticket.php
              createHiddenInput('username',getTechUsername($res['respondent']));//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
              createHiddenInput('trail','outstanding.php');
          ?>
          </form>

<!--FORM USED TO Close Ticket-->


<div id='finishTicketDiv'>

              <div class="form-group">
                  <label>Status:</label>
                  <?php
                    echo "<span disabled class='form-control'>".$res['job_status']."</span><br>";
                  ?>    
  <form id='finishTicket' action='finishactiveticket.php' method='post'><!--form used to Close Ticket-->
  <?php
      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";//hidden input to send ticket_id to finishactiveticket.php
      createHiddenInput('username',getTechUsername($res['respondent']));//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
      createHiddenInput('trail',getUrl('FULL'));
  ?>
    <?php
    echo "<center>";
    if(isAccepted($ticket_id) && $res['job_status']!="Closed" && !$res['date_fulfilled']){
       echo '<input form="finishTicket" class="btn btn-primary btn-inline" type="submit" name="Submit" value="Close Ticket">
      <input form="finishTicket" class="btn btn-primary btn-inline" type="submit" name="Submit" value="Escalate Ticket">
      ';
        //code block determines if user should be able to suspend a ticket
        $suspendedTicket = checkSuspendedTicket(getTechUsername($res['respondent']));
        /*if(!$suspendedTicket){//user already has a suspended_ticket and cannot suspend another one
          echo '<input form="finishTicket" class="btn btn-default buttonStyle" type="submit" name="Submit" value="Suspend Ticket">';
        }
        else{
          echo '<input form="finishTicket" class="btn btn-default buttonStyle" type="submit" name="Submit" value="Suspend Ticket" disabled>';
        }*/

      //code block determines if user should be able to suspend a ticket
        

            echo '<input form="finishTicket" class="btn btn-primary btn-inline" type="submit" name="Submit" value="Suspend Ticket">';

          /*//uncomment this block to enable one-suspension limit
          $suspendedTicket = checkSuspendedTicket(callUsername());

          if($res['date_suspended'] && false){
            toConsole("Ticket has already been suspended");
            //echo '<div class="tooltip"><textarea disabled class="tooltiptext">This ticket has already been suspended and may not be suspended again.</textarea><input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Suspend Ticket" disabled></div>';
            echo '<input form="finishTicket" class="btn btn-primary btn-inline" type="submit" name="Submit" value="Suspend Ticket" disabled>';
            echo "<center><p>This ticket may not be suspended again.</p></center>";
          }
          else if(!$suspendedTicket && false){//respondent does not have a suspended ticket
            echo '<input form="finishTicket" class="btn btn-primary btn-inline" type="submit" name="Submit" value="Suspend Ticket">';
          }
          else{
            echo '<input form="finishTicket" class="btn btn-primary btn-inline" type="submit" name="Submit" value="Suspend Ticket" disabled>';
            echo "<center><p>You have already suspended ticket $suspendedTicket.</p></center>";
          }*/

    }
      echo "</center><input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";//hidden input to send ticket_id to finishactiveticket.php
      createHiddenInput('username',getTechUsername($res['respondent']));//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
      createHiddenInput('trail',getUrl('FULL'));
    ?>
</form>
</div>
                  <?php
                    /*$valueArray = retrieveOptions('status',true);
                    outputSelect('job_status',$res['job_status'],$valueArray,false);*/
                  ?>

              </div>
              <!--<div class="form-group">
                  <label>Time Elapsed:</label>
                  <textarea disabled id="" name=""></textarea>
              </div>-->
              <?php 
                //echo '<input type="hidden" name="ticket_id" value="'.$ticket_id.'">';
                //createHiddenInput('trail','outstanding.php');
              ?>
              <!--</form>-->
            </div>

            <br>

            <div class="lineBorder">
              <form class="login100-form validate-form" action='updatetickets.php' id="respondentForm" name="respondentForm" method='post'>
              <div class="form-group">
                  <?php
                  outputTitle("Respondent");
                    retrieveTechsSelected(true,$res['respondent']);
                    if($res['respondent']!=''){
                      toConsole("RESPONDENT: ".$res['respondent']);
                      echo "<script>setSelectedOption('respondent', '".$res['respondent']."');</script>";
                      echo "<script>document.getElementById('respondent').disabled=true;</script>";
                    }
                  ?>
              </div>              
                <input type="submit" value="Save Changes" name="Submit" class="saveStyle">
                <?php 
                  echo '<input type="hidden" name="ticket_id" value="'.$ticket_id.'">';
                  createHiddenInput('trail',getUrl('FULL'));
                  createHiddenInput('username',getTechUsername($res['respondent']));//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
                ?>
              </form>
            </div>
            
            <br>

            <div class="lineBorder">
              <form class="login100-form validate-form" action='updatetickets.php' id="remarksForm" name="remarksForm" method='post'>
                <div class="form-group">                    
                    <?php outputTitle("Remarks");?>
                    <div id="chatlog" name="chatlog">
                    </div>

                    <!--CODE BLOCK FOR REMARKS/CHAT LOG-->
                    <div class="form-group">
                      <!--<textarea disabled class='login100-form-title p-b-48'>Chat Log</textarea>-->     
                          <div class="chat">   
                              <div class="chat-history">
                                  <ul class="chat-ul">
                                  <?php
                                    echo prepareChatlog($res['remarks']);
                                    //toConsole($res['remarks']);
                                  ?>
                                  </ul>
                              </div> <!-- end chat-history -->
                          </div> <!-- end chat -->
                        <div class="form-group">
                            <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Type a message...">
                        </div><!-- /input-group -->              
                      </div>
                  </div>

              <input type="submit" value="Save Remark" name="Submit" class="saveStyle">
              <?php 
                echo '<input type="hidden" name="ticket_id" value="'.$ticket_id.'">';
                createHiddenInput('trail',getUrl('FULL'));
              ?>
              </form>
            </div>

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
<br>

<div class="lineBorder"> <!-- Start of Borderline for Device Details -->
<div class="login100-form validate-form">
<?php
if(($res['device_id'])){  //device is set
  $device_id=$res['device_id'];
  echo "<legend class='headerStyle'>Device $device_id</legend>";
  echo "<center><p></p>Click <a href='viewdevice.php?device_id=$device_id'>here</a> to view device details for device $device_id.</center>";
}
else{  //no device set
  echo  "<legend class='headerStyle'>No Device Set</legend>";
  echo '<center><button type="button" class="saveStyle" style="width: 50%; height: 50px;" data-toggle="modal" data-target="#deviceRegistrationModal">Set Device</button></center>';
}
?>

<div id="device_info_container">
  <!--device info module-->
</div>
</div>
</div> <!-- End of Borderline for Device Details -->
<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF FORM USED TO SET/GET DEVICE INFORMATION~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

  <!--END OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
  <?php
      $isAssessed = isset($date_assessed);
      if(!$isAssessed){
        //echo "<script>document.getElementById('finishTicketDiv').style.display='none';</script>";
        echo "<script>document.getElementById('adminPanel').style.display='none';</script>";
      }
      else{        
        echo "<script>document.getElementById('noTechPanel').style.display='none';</script>";
        if($res['date_fulfilled'] && $res['job_status']=='Resolved'){
          echo "
            <script>
              document.getElementsByName('participation')[0].required = true;
              document.getElementsByName('approval_status')[0].required = true;
            </script>
          ";
        }
      }

  ?>
  
</div>
</div>

  <!--START OF MODULE FOR TECH DISPLAY-->
<div class="container" id="techModule">
<div class="lineBorder">
      <?php
        echo "<b style='font-size:20;'>Ticket ".$ticket_id."</b><br><br>";
        echo '<div class="form-group"><input type="hidden" name="ticket_id" value="'.$ticket_id.'"></div>';
      ?>
      <form id="clientForm" method="post" action="updatetickets.php">
              <div class="form-group">
                  <label>Date/Time Created:</label>
                  <textarea disabled id="date_created" name="date_created" class="form-control adjustHeight"><?php echo $date_created;?></textarea>
              </div>
              <div class="form-group">
                  <label>Office:</label>
                  <textarea disabled id="date_created" name="date_created" class="form-control adjustHeight"><?php echo $office;?></textarea>
              </div>
              <div class="form-group">
                  <label>Client Name:</label>
                    <div class="input-group mb-3">
                  <!--<input type="text" class="form-control" id="client_name" name="client_name">-->
                      <textarea disabled id="client_name" name="client_name" class="form-control adjustHeight"><?php echo $client_name;?></textarea>
                      <div class="input-group-append">
                        <button class='btn btn-info' data-toggle="modal" data-target="#editName"><i class='fa fa-pencil-alt outline'></i></button>
                      </div>
                    </div>
              </div>
              <div class="form-group">
                  <label>Employee Type:</label>
                  <!--<input type="text" class="form-control" id="employee_type" name="employee_type">-->
                  <textarea disabled id="employee_type" name="employee_type" class="form-control adjustHeight"><?php echo $employee_type;?></textarea>
              </div>
              <div class="form-group">
                  <label>Concern:</label>
                  <textarea disabled id="concern" name="concern" class="form-control adjustHeight"><?php echo $concern;?></textarea>
              </div>
              <div class="form-group">
                  <label>Concern Details:</label>
                  <textarea disabled id="concern_details" name="concern_details" class="form-control"><?php echo $concern_details;?></textarea>
              </div>  
      </form>

<form class="login100-form validate-form" action='acceptticket.php' id="acceptForm" name="acceptForm" method='post'>
  <?php
    if((!checkCurrentTicket() && !$res['date_accepted'])){
      echo '<input type="submit" value="Accept Ticket" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">';
    }
        echo '<div class="form-group"><input type="hidden" name="ticket_id" value="'.$ticket_id.'"></div>';
  ?>
</form>

          <div id="divIfAccepted" style="display:none;">
              <div class="form-group">
                  <label>Respondent:</label>
                  <?php
                    echo "<textarea disabled class='form-control adjustHeight'>".$res['respondent']."</textarea>";
                  ?>
              </div>
              <div id="divIfAssessed" style="display:none;">
                <div class="form-group">
                    <label>Assessment:</label>
                    <?php
                      echo "<textarea disabled class='form-control adjustHeight'>".$res['assessment']."</textarea>";
                    ?>
                </div>
                <div class="form-group">
                    <label>Job Description:</label>
                    <?php
                      echo "<textarea disabled class='form-control adjustHeight'>".$res['job_description']."</textarea>";
                    ?>
                </div>
                <div class="form-group">
                    <label>Job Details:</label>
                    <?php
                      echo "<textarea disabled class='form-control adjustHeight'>".$res['job_details']."</textarea>";
                    ?>
                </div>
              </div>

              <div class="form-group">
                  <label>Status:</label>
                  <?php
                    echo "<textarea disabled class='form-control adjustHeight'>".$res['job_status']."</textarea>";
                  ?>
              </div>
          </div>


            <?php
              //if(checkSuspendedTicket(callUsername())==$res['ticket_id'] && !checkCurrentTicket() && $res['job_status']=='Suspended'){
              if(callUser()==$res['respondent'] && !checkCurrentTicket() && $res['job_status']=='Suspended'){                
                  echo '
                    <form class="login100-form validate-form" action="acceptticket.php" id="resumeForm" name="resumeForm" method="post">
                    <input type="submit" value="Resume Ticket" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">';
                  createHiddenInput('ticket_id',$ticket_id);
                  echo '  </form>';
              }

            ?>
            <?php
              if($res['respondent']){
                echo "<script>document.getElementById('divIfAccepted').style.display='block';</script>";
              }
              if($res['date_assessed']){
                echo "<script>document.getElementById('divIfAssessed').style.display='block';</script>";
              }
            ?>
              
</form>
</div>
            <br>
            <div class="lineBorder">
              <form class="login100-form validate-form" action='updatetickets.php' id="remarksForm" name="remarksForm" method='post'>
                <div class="form-group">                    
                    <?php outputTitle("Remarks");?>
                    <div id="chatlog" name="chatlog">
                    </div>

                    <!--CODE BLOCK FOR REMARKS/CHAT LOG-->
                    <div class="form-group">
                      <!--<textarea disabled class='login100-form-title p-b-48'>Chat Log</textarea>-->     
                          <div class="chat">   
                              <div class="chat-history">
                                  <ul class="chat-ul">
                                  <?php
                                    echo prepareChatlog($res['remarks']);
                                    //toConsole($res['remarks']);
                                  ?>
                                  </ul>
                              </div> <!-- end chat-history -->
                          </div> <!-- end chat -->
                        <div class="form-group">
                            <input type="text" class="form-control" id="remarks" name="remarks" placeholder="Type a message...">
                        </div><!-- /input-group -->              
                      </div>
                  </div>

              <input type="submit" value="Save Remark" name="Submit" class="saveStyle">
              <?php 
                echo '<input type="hidden" name="ticket_id" value="'.$ticket_id.'">';
                createHiddenInput('trail',getUrl('FULL'));
              ?>
              </form>
              </div>

</div>  <!-- END OF MODULE FOR TECH DISPLAY-->

<!--MODAL FOR DELETE CONFIRMATION-->
  <div class="modal fade" id="deleteParts">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Confirm Deletion</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
        <!-- Modal body -->
        <form method="post" action="deletepartspec.php">
          <div class="modal-body">
            Are you sure you want to delete [<textarea disabled id="toDelete"></textarea>]?
          </div>
          <!-- Modal footer -->
          <div class="modal-footer">
            <input type="submit" class="btn btn-primary mr-auto" style="width: 100%;" value="Yes">
            <button type="submit" class="btn btn-danger" data-dismiss="modal" style="width: 100%;">No</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<!--END OF MODAL FOR DELETE CONFIRMATION-->

<!--MODAL USED TO UPDATE CLIENT NAME-->
  <div class="modal fade" id="editName">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Update Client Name</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
        <!-- Modal body -->
          <div class="modal-body">

            <form id="clientForm" method="post" action="updatetickets.php">
                    <?php
                      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";//hidden input to send ticket_id to finishactiveticket.php
                      createHiddenInput('username',getTechUsername($res['respondent']));//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
                      createHiddenInput('trail',getUrl('FULL'));
                    ?>
              <div class="form-group">
                  <label>Client First Name:</label>
                  <?php
                    $client_first_name=$res['client_first_name'];
                    echo "<input type='text' class='form-control adjustHeight' id='client_first_name' name='client_first_name' value='$client_first_name'>";
                  ?>
                  <!--<textarea disabled id="client_name" name="client_first_name" class="form-control" onkeyup="textAreaAdjust(this)"><?php echo $client_first_name;?></textarea>-->
              </div>
              <div class="form-group">
                  <label>Client Last Name:</label>
                  <?php
                    $client_last_name=$res['client_last_name'];
                    echo "<input type='text' class='form-control adjustHeight' id='client_last_name' name='client_last_name' value='$client_last_name'>";
                  ?>
                  <!--<input type="text" disabled id="client_name" name="client_last_name" class="form-control" onkeyup="textAreaAdjust(this)"><?php echo $client_last_name;?></textarea>-->
              </div>
              <div class="form-group">
                <input type="submit" value="Update Client" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">
              </div>
            </form>
          </div>
          <!-- Modal footer -->
          <!--<div class="modal-footer">
            <button type="submit" class="btn btn-danger" data-dismiss="modal" style="width: 100%;">Cancel</button>
          </div>-->
      </div>
    </div>
  </div>
<!--END OF MODAL USED TO UPDATE CLIENT NAME-->




<!--MODAL USED TO UPDATE OFFICE-->
  <div class="modal fade" id="editOffice">
    <div class="modal-dialog">
      <div class="modal-content">
        <!-- Modal Header -->
          <div class="modal-header">
            <h4 class="modal-title">Update Office</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
        <!-- Modal body -->
          <div class="modal-body">

            <form id="officeForm" method="post" action="updatetickets.php">
                    <?php
                      echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";//hidden input to send ticket_id to finishactiveticket.php
                      createHiddenInput('username',getTechUsername($res['respondent']));//creates a hidden input named 'username' with a value equal to the username of the curretly logged-in user
                      createHiddenInput('trail',getUrl('FULL'));
                    ?>
              <div class="form-group">
                  <label>Office:</label>
                  <?php
                    $office=$res['office'];
                    $valueArray = retrieveOptions('office',true);
                    outputSelect('office',$office,$valueArray,true);
                  ?>
              </div>
              <div class="form-group">
                <input type="submit" value="Update Office" name="Submit" style="width: 100%; padding: 10px; background-color: darkorange; border-color: darkorange; font-size: 18px; font-weight: bold; border-radius: 10px;">
              </div>
            </form>
          </div>
          <!-- Modal footer -->
          <!--<div class="modal-footer">
            <button type="submit" class="btn btn-danger" data-dismiss="modal" style="width: 100%;">Cancel</button>
          </div>-->
      </div>
    </div>
  </div>
<!--END OF MODAL USED TO UPDATE OFFICE-->



<!--MODULE TO SWITCH BETWEEN TECH DISPLAY AND ADMIN DISPLAY-->
<?php

  if(checkUserPrivilege()=='admin'){
    toConsole('User is an administrator');
  echo "<script>
    document.getElementById('techModule').style.display='none';
    document.getElementById('adminModule').style.display='block';
  </script>";
  }
  else if(checkUserPrivilege()=='tech' || checkUserPrivilege()=='intern'){
    toConsole('User is a tech');
  echo "<script>
    document.getElementById('techModule').style.display='block';
    document.getElementById('adminModule').style.display='none';
  </script>";
  }
  else if(!checkUserPrivilege()){
    toConsole('Redirecting to index');
    redirect('index.php');
  }
?>
<!--END OF MODULE TO SWITCH BETWEEN TECH DISPLAY AND ADMIN DISPLAY-->

</div>

<?php
  echo'  <div class="container" id="redirect_display" style="display:none;">
      <center>
        <img src="img/ITDOLogo.png" style="width: 30%;">
        <br><br><p class="whiteText">You already have an active ticket!</p>
        <p class="whiteText">Click <a href="activeticket.php">here</a> to view your active ticket.</p>
      </center>
    </div>';
?>

<?php
    showElement('primary_display');
/*THIS CODE BLOCK PREVENTS TECHS FROM VIEWING TICKETS WHEN THEY ALREADY HAVE AN ACTIVE TICKET
//MODULE DETERMINES IF USER SHOULD SEE INTERFACE//
  if(checkCurrentTicket()){
    //SHOW MAIN DISPLAY, HIDE REDIRECT DISPLAY
    showElement('primary_display');
  }
  else{
    //HIDE MAIN DISPLAY, SHOW REDIRECT DISPLAY
    showElement('redirect_display');
  }
  */
?>

<?php

//insert logic that chooses which forms to disable
if($res['approval_status']=='Approved' && $res['date_fulfilled']){
  disableForm('adminForm');
  disableForm('finishAssessment');
}
if($res['respondent']){
  disableForm('respondentForm');
}

?>
</div>

<!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~MODAL CODE FOR SETTING A DEVICE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->
    <div class="modal fade" id="deviceRegistrationModal" style="color:black;">
        <div class="modal-dialog">
          <div class="modal-content">
            <ul class="nav nav-tabs" role="tablist">    
              <li class="nav-item">
                  <a class="nav-link active" data-toggle="tab" href="#home">Register New Device</a>
              </li>
              <li class="nav-item">
                  <a class="nav-link" data-toggle="tab" href="#menu1">Select Existing Device</a>
              </li>
            </ul>
            <div class="tab-content">

                <div id="home" class="container tab-pane active">  
                    <div class="modal-header"><!-- Modal Header -->
                        <h4 class="modal-title">Register New Device</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body"><!-- Modal body -->
                      <form id='registerDeviceForm' action='createdevice.php' method='post'><!--form used to register new device-->
                          <?php createHiddenInput('trail',basename($_SERVER['PHP_SELF']));?>
                          <?php echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";?>
                          <div class="form-group">
                              <label>Device Type</label>
                                <?php
                                  $valueArray = retrieveOptions('device_type',true);
                                  outputSelect('device_type','',$valueArray,true);
                                ?>
                          </div>
                          <div class="form-group">
                              <label>Owner:</label>
                              <input type='text' class="form-control" name='owner' id='owner' placeholder='Owner' required>
                          </div>
                          <div class="form-group">
                              <label>Office:</label>
                              <?php
                                $valueArray = retrieveOptions('office',true);
                                outputSelect('office',$res['office'],$valueArray,true);

                                createHiddenInput('trail',getUrl('BASE'));
                                createHiddenInput('ticket_id',$res['ticket_id']);
                              ?>
                          </div>
                          <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Register">
                      </form>
                  </div>  
                </div>

                <div id="menu1" class="container tab-pane fade">
                <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title centerText">Select Existing Device</h4><br><br>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>     
                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Device ID:</label>
                            <form id='setDeviceForm' action='setdevice.php' method='post'>
                                <input type='text' name='device_id' id='device_id' placeholder='Enter device ID...' list='deviceList' class="form-control">
                                <br>
                                <?php 
                                  retrieveDevices();
                                  //initializes combo box with list of all registered devices
                                ?>
                                <?php echo "<input type='hidden' name='ticket_id' value='".$res['ticket_id']."'>";?>
                                <input type='submit' class="btn btn-default buttonStyle" name='Submit' value='Set Device' id='toggleSetDevice'>
                            </form>
                        </div>
                    </div>
                </div>
              </div>  
          </div>
        </div>
      </div> 
  <!--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~END OF MODAL CODE FOR SETTING A DEVICE~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~-->

</body>

<script>

window.onload=loadingScreen();
    function isNumberKey(evt){//checks whether the key pressed is a number - currently not in use
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}


  function hidePanels(){//hides all panels with the class 'borderLine'
    console.log('No ticket set - hiding elements');
    var x = document.getElementsByClassName('borderLine');
    console.log(x.length);
    var i;
    for (i = 0; i < x.length; i++) {
      console.log('hiding: '+x[i].name);
      x[i].style.display='none';
    }    
  }

  document.addEventListener('DOMContentLoaded', function() {
    console.log('switch function : '+!!document.getElementById("no_ticket"));
    //console.log(!!document.getElementById("no_ticket"));
    if(!!document.getElementById("no_ticket")){
      hidePanels();
    }
  }, false);  

function ifTicketAccepted(){

}
function textAreaAdjust(o) {
  o.style.height = (o.scrollHeight > o.clientHeight) ? (o.scrollHeight)+"px" : "60px";
}


</script>
</html>