<?php include 'misc/config.php';?>
<div style="color:white;">
<br><br><br><br><br><br><br><br><br><br>

	<?php
		if(!checkPost('Submit') || !checkPost('username')){
			redirect('index.php');
		}

		$username = checkPost('username');
		$techDetails = getTechDetails($username);

		$updateQuery = "UPDATE tech_credentials SET status='inactive' WHERE username='$username'";
		if(mysqli_query($conn, $updateQuery)){
			escalateTicket($techDetails['current_ticket']);//escalate tech's current ticket
				$suspendedTickets=getSuspendedTickets($user);
				foreach($suspendedTickets as $ticket_id){//escalates tech's suspended tickets
					escalateTicket($ticket_id);
				}
			redirect("index.php?deactivate_success=$username");
		}
		else{
			redirect("index.php?deactivate_failure=$username");
		}

	?>

</div>
<script>  
</script>