<?php include 'misc/config.php';?>
<?php
	echo "<br><br><br><br><br><center>CONFIRM UPDATE</center><br><br><br>";
	global $conn;
	if(!checkPost('Submit')){
		//shoot($user);
		redirect('index.php');
	}
	//printPost();
	$user=checkPost('user');
	$status=checkPost('status');
	$designation=checkPost('designation');
	$privilege=checkPost('privilege');
	$trail=checkPost('trail');


	$techUsername=getTechUsername($user);
	$userDetails=getTechDetails($techUsername);

	if($status!=$userDetails['status']){//status was changed - deactivate user
		$updateQuery="UPDATE tech_credentials SET status='$status' WHERE employee_name='$user'";
		if($result=mysqli_query($conn,$updateQuery)){
			//success - escalate tickets
			if($status=='inactive'){
				escalateTicket($userDetails['current_ticket']);
				$suspendedTickets=getSuspendedTickets($user);
				foreach($suspendedTickets as $ticket_id){
					escalateTicket($ticket_id);
				}
			}
		}
		else{
			checkSQLError();
		}
	}

	if($designation!=$userDetails['designation']){

	    $values=retrieveOptionsNum('designation',true);
	    toConsole(in_array($designation,$values));
	    if(!in_array($designation,$values)){
	    	$insertQuery="
	    		INSERT INTO field_values
	    		VALUES ('designation','$designation','');
	    	";
	    	if($result=mysqli_query($conn,$insertQuery)){
	    		//new designation added to field_values
	    	}
	    }

		$updateQuery="UPDATE tech_credentials SET designation='$designation' WHERE employee_name='$user'";
		if($result=mysqli_query($conn,$updateQuery)){
			//success
		}
		else{
			checkSQLError();
		}
	}

	//exit clause - this php page redirects to usermanagement.php by default
	if($trail){
		redirect($trail);
	}
	else{
		redirect('usermanagement.php');
	}
?>
<script>  
</script>