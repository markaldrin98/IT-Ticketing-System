<html>
<body>

<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_records";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
dtconsole("Connected successfully");

$sql = "CREATE DATABASE IF NOT EXISTS student_records";
if ($conn->query($sql) === TRUE) {
    dtconsole("Database created successfully");
} else {
    dtconsole("Error creating database: " . $conn->error);
}

// Create connection
$conn = mysqli_connect($servername, $username, $password,$dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
dtconsole("Connected successfully");

$sql = "CREATE TABLE IF NOT EXISTS student_info (
id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
lname VARCHAR(30) NOT NULL,
fname VARCHAR(30) NOT NULL,
mname VARCHAR(30) NOT NULL,
snumber VARCHAR(30) NOT NULL,
email VARCHAR(50),
reg_date TIMESTAMP
)";
//echo "<br>";
if (mysqli_query($conn, $sql)) {
    dtconsole("Table student_info created successfully");
} else {
    dtconsole("Error creating table: " . mysqli_error($conn));
}


$conn->close();

function dtconsole($data){
	$output=$data;
	if(is_array($output)){
		$output=implode(',',$output);
	}
	echo "<script>console.log('".$output."');</script>";
}

function insertIntoDB($givenLName, $givenFName, $givenMName, $givenSNumber, $givenEMail){
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student_records";

	$lname = $givenLName;
	$fname = $givenFName;
	$mname = $givenMName;
	$snumber = $givenSNumber;
	$email =  $givenEMail;
	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);

	// Check connection
	if (!$conn) {
	    die("Connection failed: " . mysqli_connect_error());
	}
	dtconsole("Connected successfully");

	$sql = "INSERT INTO student_info (lname, fname, mname, snumber, email) VALUES ('".$lname."', '".$fname."', '".$mname."', '".$snumber."','".$email."')";

	if ($conn->query($sql) === TRUE) {
	    dtconsole("New record created successfully");
	} else {
	    dtconsole("Error inserting: " . $conn->error);
	}
	header("location: srecords.php");
}
?>

<?php
    $lname = $_POST['lname'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $snumber = $_POST['snumber'];
    $email = $_POST['email'];
    insertIntoDB($lname, $fname, $mname, $snumber, $email)
?>

</body>
</html>