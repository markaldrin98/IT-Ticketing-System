<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php
include_once("misc/config.php");  
echo "<br><br><br><br><br><br><br><br>";  
$ticket_id = $_POST["ticket_id"];
if(isFinished($ticket_id)){
    $trail='';
    if(checkPost('trail')){
        $trail=checkPost('trail');
    }
    else{
        $trail="outstanding.php?ticket_status=already_finished&ticket_id=$ticket_id";
    }
   redirect($trail); 
}
$assignmentCheck = false;   //gate variable
$ticketUpdateCheck = false;   //gate variable


if(isset($_POST['Submit']) && $_POST['Submit']!='' && checkPost('username')){//if clause checks to make sure user arrived on this page through the intended channel
    $techUsername = checkPost('username');
    //NOTE TO SELF - CURRENTLY RESTRUCTURING FUNCTIONS THAT UPDATE TECH'S CURRENT_TICKET AND SUSPENDED_TICKET
    //ASSIGN RETURN VALUE OF UPDATE FUNCTIONS TO BOOLEANS WHICH WILL THEN ACT AS GATES (assignmentCheck AND ticketUpdateCheck)

    //-----------------------------TICKET WAS ESCALATED-----------------------------------//
    if(checkPost('Submit') == "Escalate Ticket"){//ticket was escalated

        if(escalateTicket($ticket_id)){
            $assignmentCheck=true;
            $ticketUpdateCheck = true;
        }

        /*if(dropTicket($techUsername)){//if tech's ticket was successfully dropped, run this clause
            $assignmentCheck=true;
        }*/

    }//-----END OF CODE FOR TICKET ESCALATION------//

    //-----------------------------TICKET WAS FINISHED-----------------------------------//
    else if(checkPost('Submit') == "Close Ticket"){//ticket was closed

        /*
            clauses should be:
                >if admin closes ticket prematurely and ticket belongs to admin
                    >check to see if ticket a) has been assessed and b) has been completed, so as not to overwrite data
                >if admin closes ticket prematurely and ticket belongs to another user
                >if admin 


        */

        $ticketDetails = getTicketDetails($ticket_id);

        if(!isAssessed($ticket_id) && checkUserPrivilege()=='admin'){
            //ticket has not been assessed, admin closes ticket prematurely
            endUnassessedTicket($ticket_id);
            $ticketUpdateCheck = true;
        }
        else if(isSuspended($ticket_id) && checkUserPrivilege()=='admin'){
            //ticket has been suspended, admin closes ticket prematurely
            endSuspendedTicket($ticket_id);
            $ticketUpdateCheck = true;
        }
        else if(isAssessed($ticket_id) && checkUserPrivilege()=='admin' && !isSuspended($ticket_id)){
            //assessed, non-suspended ticket was closed by an admin
            endTicket($ticket_id);
            $ticketUpdateCheck = true;
        }
        else{        
            //default clause, this clause runs when an ordinary tech closes a ticket    
            $queryString = 'UPDATE tickets SET date_fulfilled=now(), job_status="Closed" WHERE ticket_id="'.$ticket_id.'"';
            if(mysqli_query($conn, $queryString)){
                $ticketUpdateCheck = true;
            }
        }


        /*if(!isAssessed($ticket_id) && checkUserPrivilege()=='admin' && $ticketDetails['respondent']==callUser()){//ticket is not assessed, ticket belongs to admin and current user
            endAdminTicket($ticket_id,true);
            $ticketUpdateCheck = true;
        }
        else if(checkUserPrivilege()=='admin' && $ticketDetails['respondent']==callUser()){
            $admin=callUser();
            $updateQuery = "UPDATE tickets SET date_fulfilled=now(), job_status='Closed' , admin='$admin', participation='Performed', approval_status='Approved' WHERE ticket_id='$ticket_id'";
            if(mysqli_query($conn, $updateQuery)){
                $ticketUpdateCheck = true;
            }
        }
        else if(!isAssessed($ticket_id) && checkUserPrivilege()=='admin'){
            endUnassessedTicket($ticket_id);
            $ticketUpdateCheck = true;
        }
        else if($ticketDetails['job_status']=='Suspended' && checkUserPrivilege()=='admin'){
            endSuspendedTicket($ticket_id);
        }
        //study suggests this clause may be unnecessary
        else if(checkUserPrivilege()=='admin'){
            $admin=callUser();
            $updateQuery = "UPDATE tickets SET date_fulfilled=now(), job_status='Closed' , admin='$admin', participation='Supervised', approval_status='Approved' WHERE ticket_id='$ticket_id'";
            if(mysqli_query($conn, $updateQuery)){
                $ticketUpdateCheck = true;
            }
        }
        else{            
            $queryString = 'UPDATE tickets SET date_fulfilled=now(), job_status="Resolved" WHERE ticket_id="'.$ticket_id.'"';
            if(mysqli_query($conn, $queryString)){
                $ticketUpdateCheck = true;
            }
        }*/

        /*if ($ticketUpated) { //query passes, gate is cleared
            echo "<script>console.log('"."Check 2 clear"."')</script>";
        } 
        else {    //report sql error
            echo '<script>console.log("Check 2 - '.mysqli_error($conn).'");</script>';
            echo "<script>console.log('".$queryString."')</script>";
        }//deprecated code*/
        //end of code block
        if(dropTicket($techUsername)){//if tech's ticket was successfully dropped, run this clause
            $assignmentCheck=true;
        }
    }
    //-----------------------------TICKET WAS SUSPENDED-----------------------------------//
    else if(checkPost('Submit') == "Suspend Ticket"){//ticket was suspended
        //code block double-checks if user already has a suspended ticket        
          //3$techDetails = getTechDetails(callUsername());
          //3if(!$techDetails['suspended_ticket']){//user does not have a suspended ticket
            //code block that suspends a ticket
                $suspensionQueryString = 'UPDATE tickets SET date_suspended=now(), job_status="Suspended" WHERE ticket_id="'.$ticket_id.'"';//query updates ticket
                if (mysqli_query($conn, $suspensionQueryString)) { //query passes, gate is cleared
                    echo "<script>console.log('"."Check 2 clear"."')</script>";
                    $ticketUpdateCheck = true;
                }
                else {    //report sql error
                    echo '<script>console.log("Check 2 - '.mysqli_error($conn).'");</script>';
                    echo "<script>console.log('".$suspensionQueryString."')</script>";
                }
          /*3}
          else{//user has a suspended ticket
            $redirectAddress="outstanding.php?suspend_fail=fail&ticket_id=$ticket_id";
            redirect($redirectAddress);
          }*/
          //uncomment all comments marked with '3' to allow single-suspension restriction
            if(suspendTicket($techUsername)){//if tech's ticket was successfully suspended, run this clause
                $assignmentCheck=true;
            }

    }
    else{//form was not submitted through prepared buttons; user shouldn't be here
        redirect("index.php");
    }

        if($assignmentCheck && $ticketUpdateCheck){   //checks gate variables - if both gate variables return true, then both queries were successful and the page should redirect
                //if $assignmentCheck returns true, ticket assignment was successfully processed
                //if $ticketUpdateCheck returns true, ticket status was successfully updated
            echo "<script>console.log('"."Redirecting to outstanding"."')</script>";
            /*if(checkPost('trail')){
                redirect(checkPost('trail'));
            }
            else{
                redirect('outstanding.php');
            }*/
            redirect('outstanding.php');
        }
        else{   //else do nothing
            toConsole("Acheck: ".$assignmentCheck);
            toConsole("Tcheck: ".$ticketUpdateCheck);
            echo "<script>console.log('"."Doing nothing"."')</script>";
        }

}//end of if clause

else{//user /did not/ arrive on this page through the intended channel, redirect to ticket creation
    redirect("index.html");
}

?>

</div>