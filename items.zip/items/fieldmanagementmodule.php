<script>
function hideTables(){
  console.log("Hiding tables");
  tableElements = document.getElementsByClassName('fieldDiv');
  for(counter=0;counter<tableElements.length;counter++){
    tableElements[counter].style.display='none';
  }
}

function showTable(tableSelect){
  hideTables();
  document.getElementById(tableSelect.value).style.display='block';
}
</script>



<!--MODAL USED TO CONFIRM DELETION OF FIELD ITEM-->
<div class="modal fade" id="deleteModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Confirm Deletion</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
      <!-- Modal body -->
      <form method="post" action="deletefieldvalue.php">
        <div class="modal-body">
          <p>Are you sure you want to delete [<span id="deleteString"></span>]?</p>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <?php //createHiddenInput('device_id',$device_id);?>
          <input type="hidden" name="delete_field" id="delete_field">
          <input type="hidden" name="delete_storedValue" id="delete_storedValue">
          <input type="hidden" name="delete_storedDescription" id="delete_storedDescription">
          <?php createHiddenInput('trail',getUrl('BASE'));?>
          <input type="submit" class="btn btn-primary mr-auto" name="Submit" style="width: 100%;" value="Yes">
          <button class="btn btn-danger" data-dismiss="modal" style="width: 100%;">No</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--END OF MODAL USED TO CONFIRM DELETION OF FIELD ITEM-->


<!--MODAL USED TO EDIT FIELD ITEM-->
<div class="modal fade" id="editModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Edit Item</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>  
      <!-- Modal body -->
        <form method="post" action="editfieldvalue.php">
        <div class="modal-body">
         <div class="form-group">
              <label title="Value" data-title="Value" style="font-size: 20px;">Value</label>
           
        <input type="text" class="form-control" name='value' id="new_value" required>
      </div>
       <br>
          <div class="form-group">
              <label title="Description" data-title="Description" style="font-size: 20px;">Description</label>
       
        <input type="text" class="form-control" name='description' id="new_desription" required>
      </div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <?php //createHiddenInput('device_id',$device_id);?>
          <input type="hidden" name="edit_field" id="edit_field">
          <input type="hidden" name="edit_storedValue" id="edit_storedValue">
          <input type="hidden" name="edit_storedDescription" id="edit_storedDescription">
          <?php createHiddenInput('trail',getUrl('BASE'));?>
          <input type="submit" class="btn btn-primary mr-auto" name="Submit" style="width: 100%;" value="Update Field Values">
          <button class="btn btn-outline-danger" data-dismiss="modal" style="width: 100%;">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--MODAL USED TO EDIT FIELD ITEM-->


<?php

  global $conn;

  $fieldArray = retrieveUniqueFields();
  echo "<select onchange='showTable(this)' class='btn btnField btn-lg dropdown-toggle'>";
  echo "<option value='' selected disabled>--select a field--</option>";
  foreach($fieldArray as $field){
    if($field=='status' || $field=='tech_status'){
      continue;
    }
    echo "<option value='$field'>"; 
    echo formatString($field)."</option>";
  }
  echo "</select><br><br>";

  $selectQuery="SELECT DISTINCT field FROM field_values ORDER BY field ASC";
  if ($selectResult=mysqli_query($conn, $selectQuery)) {//query passes, tickets retrieved
        while($res=mysqli_fetch_array($selectResult)){//while there are values to display
            if($res['field']=='status'){
              continue;
            }
            $populationQuery="SELECT * FROM field_values WHERE field='".$res['field']."' ORDER BY value ASC";
            if($populationResult=mysqli_query($conn, $populationQuery)){
              echo "<div id='".$res['field']."' class='fieldDiv'><center>";
                //echo "<span>".formatString($res['field'])."</span>";//title string
                $isRequired="";
                switch($res['field']){
                  case "assessment":
                    echo "<span>Used by techs to note the problem area.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                  case "office":
                    echo "<span>Used to note which office the client belongs to.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                  case "job_description":
                    echo "<span>Used by techs to note what type of work was done.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                  case "concern":
                    echo "<span>Used by the client to note the general problem area. <br>The details column is used to specify the type of problem that should be under each item.</span>";
                    $isRequired=" required ";
                    $placeHolder="Add a description (required)";
                  break;
                  case "status":
                    echo "<span>Used to note each ticket's current status.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                  case "participation":
                    echo "<span>Used to note admin's participation in each ticket.</span>";
                    
                    $placeHolder="Add a description (optional)";
                    break;
                  case "device_type":
                    echo "<span>Used to note the type of device being registered. <br>The details column is used to determine the device's ID.</span>";
                    $isRequired=" required ";
                    $placeHolder="Add a description (required)";
                  break;
                  case "software":
                    echo "<span>Used to note which software was installed.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                  case "specification":
                    echo "<span>Used to note which specification is being added.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                  case "peripheral":
                    echo "<span>Used to note which peripheral is being added.</span>";
                    $placeHolder="Add a description (optional)";
                  break;
                }
                echo "<br>";
              echo "
              <form action='newfieldvalue.php' method='post'>
              <br>
              <div class='setMaxWidth'>
                  <input type='text' class='leftInput btn marginBottom' name='new_value' placeholder='Add a new value...' required>
                  <input type='text' class='middleInput btn marginBottom' name='new_description' placeholder='$placeHolder' $isRequired>
                  <input type='submit' class='rightInput btn' name='Submit' value='Add Value'>";
                  createHiddenInput('field',$res['field']);
                  createHiddenInput('trail',getUrl('FULL'));
              echo "</div>";
              echo "</form>";

              echo "<br>";
              echo "<table>";
              echo "<tr style='text-align:center;'>
                <th>VALUE</th>
                <th>DESCRIPTION</th>
                <th>ACTION</th>
              </tr>";
              while($popRes=mysqli_fetch_array($populationResult,MYSQLI_NUM)){
                echo "<tr>";
                  for($counter=1;$counter<count($popRes);$counter++){
                      if($popRes[$counter]){echo "<td>".$popRes[$counter]."</td>";}
                      else{echo "<td>no description</td>";}
                  }
                  echo "<td>";
                    if($popRes[1]!="Others"){//"Others" field value should /never/ be editable or deletable, as it would cause malfunctions in the program
                      echo "<button class='btn btn-info' data-toggle='modal' data-target='#editModal' onclick=\"setEditModalValues('$popRes[0]','$popRes[1]','$popRes[2]')\"><i class='fa fa-pencil-alt outline'></i></button>
                      &nbsp; ";
                      echo "<button class='btn btn-outline-danger' data-toggle='modal' data-target='#deleteModal' onclick=\"setDeleteModalValues('$popRes[0]','$popRes[1]','$popRes[2]')\"><i class='fa fa-trash'></i></button>";
                    }
                    else{
                      echo "Cannot be modified";
                    }
                  echo "</td>";
                echo "</tr>";
              }
              echo "</table>";
              echo "</center>
              <br>
              </div>";
              echo "
                <script>";
                /*foreach(retrieveUniqueFields() as $field){
                  this part to be used to script functions to hide unselected tables
                }*/
              echo "</script>
              ";
            }
            else{
              checkSQLError();
            }
    }
  }
  else{//query fails or returns a falsy value, nothing to display
    echo "Nothing to display.";
  }
?>

<script>  
hideTables();


function setDeleteModalValues(field,field_value, description){
  console.log("Setting deletemodal values");
  entityString = document.getElementById('deleteString');
  if(!description){
    description = "no description";
  }
  entityString.innerHTML = ""+field_value + " - " + description+"";
  document.getElementById('delete_field').value=field;
  document.getElementById('delete_storedValue').value=field_value;
  document.getElementById('delete_storedDescription').value=description;
}


function setEditModalValues(field,field_value, description){

  document.getElementById('new_value').value=field_value;
  if(description){
    document.getElementById('new_desription').value=description;
  }
  else{
    document.getElementById('new_desription').placeholder="no description";
  }  

  document.getElementById('edit_field').value=field;
  document.getElementById('edit_storedValue').value=field_value;
  document.getElementById('edit_storedDescription').value=description;
}

/*
        <input class="form-control" name='value' id="new_value">
        <input class="form-control" name='description' id="new_desription">*/

</script>