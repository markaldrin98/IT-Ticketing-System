<?php include 'misc/config.php';?>
<?php
if(checkPost('Submit')=="Register User") {//checks if device_id is set
    $user_type=escapeString(checkPost('user_type'));
    $employee_name=escapeString(checkPost('employee_name')); //retrieves posted values
    $username=escapeString(checkPost('username'));
    $message="";

    if($usernameAvailable=usernameIsAvailable($username) && $nameAvailable=nameIsAvailable($employee_name)){
    	$insertQuery="INSERT INTO tech_credentials(user_type,username,employee_name,status,password) VALUES ('$user_type','$username','$employee_name','active','password')";
    	if(mysqli_query($conn,$insertQuery)){
    		redirect("registeruser.php?attempt=success&user_type=$user_type&newUser=$employee_name");
    	}
    	else{
    		checkSQLError();
    	}
    }
    else{
    	if(!$usernameAvailable){
    		$message.="<br>Username has already been taken.";
    	}
    	if(!$nameAvailable){
    		$message.="<br>Employee name has already been taken.";
    	}
    		redirect("registeruser.php?attempt=failure&user_type=$user_type&newUser=$employee_name&message=$message");
    }

    
}
else{
    //redirect('index.php');
}
                  
?>

