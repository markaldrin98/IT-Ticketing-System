
  <fieldset id="device_details">
     Device <?php echo $res['device_id'];?>
        
          <?php
            $deviceDetails = retrieveDetails($res['device_id']);
          ?>  
          <br><br>
          <div class="form-group">
              <label>Device Type</label>
              <span id="concern" name="concern" class="form-control"><?php echo $deviceDetails['device_type'];?></span>                          
          </div>
          <div class="form-group">
              <label>Device Owner</label>
              <span id="" name="concern" class="form-control"><?php echo $deviceDetails['owner'];?></span>
          </div>
          <div class="form-group">
              <label>Office</label>
              <span id="concern" name="concern" class="form-control"><?php echo $deviceDetails['office'];?></span>
          </div>
        
  </fieldset>
 
  <fieldset id="device_parts">
      <p>Device Parts</p>
        <li href="#showParts" class="list-group-item styleList pointerElements" data-toggle="collapse"><span>Show</span> Parts List</li>
          <div id="showParts" class="collapse">
            <ul class="list-group">
              <?php
                printArray(retrieveParts($res['device_id']));
              ?>
            </ul>
          </div>
          <hr class="borderGray">
      <li>Add New Peripheral
      <br><br>
        <form action="newpartspec.php" method="post"><!--form to add new peripheral to device-->
          <div class="form-group">
              <?php 
                createHiddenInput('device_id',$res['device_id']);
                createHiddenInput('trail',basename($_SERVER['PHP_SELF']));

                $optionArray=retrieveOptions('peripheral',true);
                outputFullSelect('new_value','',$optionArray,true,'Select a new peripheral...',true);
              ?>
            <input type="text" class="form-control" id="newPeripheral" name="new_item" placeholder="Please specify...">
            <br>        
            <input type="text" class="form-control" name="new_detail" placeholder="New Details..." required>
            <br>
            <input class="btn btn-default partStyle"  type="submit" name="Submit" value="Add Peripheral">
          </div>
        </form>
      </li>
  </fieldset>
  <hr class="borderGray">
  <fieldset id="device_specs">
      <p>Device Specifications</p>
          <li href="#showSpecs" class="list-group-item styleList" data-toggle="collapse"><span>Show</span> Specifications List</li>
          
          <div id="showSpecs" class="collapse">
              <ul class="list-group">
                <?php
                  printArray(retrieveSpecs($res['device_id']));
                ?>
              </ul>
          </div>
          <br>
          <form action="newpartspec.php" method="post"><!--form to add new spec to device-->
            <div class="form-group">
              <?php 
                createHiddenInput('device_id',$res['device_id']);
                createHiddenInput('trail',basename($_SERVER['PHP_SELF']));

                $optionArray=retrieveOptions('specification',true);
                outputFullSelect('new_value','',$optionArray,true,'Select a new specification...',true);
              ?>
              <input type="text" class="form-control" id="newSpecification" name="new_item" placeholder="Please specify...">
              <br>
              <input type="text" name="new_detail" class="form-control" placeholder="New Details..." required>
              <br>
              <input class="btn btn-default buttonStyle" type="submit" name="Submit" value="Add Specification">
            </div>
          </form>
  </fieldset>

