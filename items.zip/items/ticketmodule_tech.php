<?php
    function displayTech(){ //function to render tech's interface
        global $colorSwitch,$conn;
        $specialMessage="";
        $result='';
        $user=callUser();
        //below query only returns tickets belonging to the tech
        //$resultQuery="SELECT * FROM tickets WHERE ((respondent IS NULL) OR (respondent = '$user')) AND (date_fulfilled IS NULL) ORDER BY ticket_id ASC";
        
        $resultQuery="SELECT * FROM tickets WHERE ((date_fulfilled IS NOT NULL AND respondent = '$user') OR (date_fulfilled IS NULL)) AND (approval_status='Not Approved') ORDER BY ticket_id ASC";
            $result = mysqli_query($conn, $resultQuery);
            toConsole("result - ".addslashes($resultQuery));
            $rowCount = mysqli_num_rows($result);
            toConsole("row count - ".$rowCount);
            //************IF TICKET IS SUSPENDED, CHECK WHICH TECH IT BELONGS TO - IF IT BELONGS TO /THIS/ TECH, DISPLAY -> OTHERWISE HIDE************//
            //SHOULD ALSO SORT ACCORDING TO PRIORITY??? IF SO, JUST IMPORT THE CODE FROM ADMIN SIDE AFTER SORT IS CONSTRUCTED
        
        if(!$result || mysqli_num_rows($result)==0) {
            $specialMessage="<p class='whiteText'>No tickets to display!</p>";
        }//checks to make sure there are tickets to be displayed
        else{

        }
        $techCheck = false;

            $gateQuery = mysqli_query($conn, "SELECT * FROM tech_credentials WHERE employee_name = '".callUser()."'");
            if(!$gateQuery || mysqli_num_rows($gateQuery)==0) {//checks to make sure tech is extant - mostly unnecessary, but may prevent errors
            }   
            else{
                while($gateRes = mysqli_fetch_array($gateQuery)){                        
                    if($gateRes['current_ticket'] != NULL || $gateRes['current_ticket'] != ""){ //checks to make sure the tech doesn't already have a ticket selected. If he does, redirect to activeticket.php
                        $message = '<div class="darkText"><p><center>Error! You must finish your current ticket before accepting a new one!</p>';
                        $message .= '<p>Click <a href="activeticket.php">here</a> to view your active ticket.</p></center></div>';
                        echo $message;
                        //echo "<script>alert('".$message."');</script>";
                        //redirect('activeticket.php');
                    }     
                    else{//if tech does not have active ticket, set techCheck to true so the tech UI displays
                        $techCheck=true;
                    }
                }
            }

        if($techCheck){//if true, display tech interface
            echo "

                <tr bgcolor='#AAAAAA'>
                    <!--<th>Date/Time Created</th>-->
                    <th>Ticket ID</th>
                    <th>Office</th>
                    <th>Client Name</th>
                    <th>Concern</th>
                    <!--<th>Concern Details</th>-->
                    <th>Respondent</th>
                </tr>
            ";
            $rowCount = mysqli_num_rows($result);
            $somethingToDisplay=false;
            if($rowCount){
            	$somethingToDisplay=true;
            }
            else{
            	echo "<tr><td class='whiteText' style='text-align: center;' colspan='100%'>Nothing to display.</td></tr>";
            }

            while($res = mysqli_fetch_array($result)) {  //iterates through all tickets
                /*toConsole("iterating through tickets: ".$res['ticket_id']);
                if(!$res[0]){
                    toConsole("RES IS NULL");
                }
                else{
                    toConsole("RES IS NOT NULL");
                }*/
                $optionString = "";

                    echo '<tr ';

                    if($res['job_status']=='Escalated'){//code block changes row color
                        $priority = "1";
                            echo "class='rowText rowColorRed'";
                    }
                    else if($res['job_status']=='Suspended'){//ticket has been suspended
                        $priority = "2";
                            echo "class='rowText rowColorYellow'";
                    }
                    else if($res['job_status']=='Ongoing'){//ticket has been suspended
                        $priority = "2";
                            echo "class='rowText rowColorGreen'";
                    }
                    else if($res['job_status']=='Closed' && $res['approval_status']=='Not Approved'){//ticket has been suspended
                        $priority = "2";
                            echo "class='rowText rowColorBlue'";
                    }

                        if($res['date_fulfilled'] && $res['approval_status']=='Approved'){//checks if the ticket has been completed - if so, makes the ticket invisible
                            echo ' data-completion-status="completed" class="completed_ticket pointerElements"';
                        }
                        else{
                            echo ' data-completion-status="not completed" class="incomplete_ticket pointerElements"';                            
                        }

                        if(($res['job_status']=="Suspended") && $res['respondent']==callUser()){//checks if ticket has been suspended by current user | second clause is probably unnecessary but added as a failsafe

                        }

                    //echo 'onclick="callModal('.$res["ticket_id"].')"';   
                    echo ' onclick="viewTicket(this)" id="'.$res["ticket_id"].'"';
                    echo '>';

                    //echo "<td>".$res['date_created']."</td>";                                             //static
                    echo "<td class='expandTD'>".$res['ticket_id']."</td>";                                                  //displays ticket_id specified in ticket
                    echo "<td class='expandTD'>".$res['office']."</td>";                                                     //displays office specified in ticket
                    echo "<td class='expandTD'>".$res['client_first_name']." ".$res['client_last_name']."</td>";             //displays client_name specified in ticket
                    echo "<td class='expandTD'>".$res['concern']."</td>";                                                    //client concern - static
                    //echo "<td class='expandTD>".$res['concern_details']."</td>";                                            //concern details - static
                    echo "<td class='expandTD'>".$res['respondent']."</td>";                                                 //respondent assigned to ticket
                    //text display for 'concern'

                    /*if($res['respondent']==""){                       //code block displays the 'accept ticket' button - removed, function to be transferred to a modal displayed upon clicking the row (like in admin table)
                        echo '<td>
                        <input form="acceptForm" class="btn btn-default" type="submit" name="Submit" value="Accept Ticket" style="background-color: #242e39; border-color: black; color:white;">
                        <input form="acceptForm" type="hidden" name="acceptingRespondent" value="'.$_SESSION['client_name'].'"">
                        <input form="acceptForm" type="hidden" name="ticketID" value="'.$res['ticket_id'].'"">
                        </form></td>';
                    }
                    else{
                        echo "<td>".$res['respondent']."</td>"; 
                    }*/
                    
                    /*echo '<td><textarea style="color:black;resize:none;" value="'.$res["remarks"].'" name="remarksSelect'.$res["ticket_id"].'"></textarea></td>
                    ';//textarea control for 'remarks'*/
                    echo "</tr>";
            }//end of while loop

                    echo '
                    </table>  ';  //code block closes table
        }//end of techCheck if()

    }//end of displayTech function
?>
