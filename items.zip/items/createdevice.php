<?php include 'misc/config.php';?>
<?php
if(checkPost('device_type')) {//checks if device_id is set
    $device_type=checkPost('device_type');
    $owner=checkPost('owner'); //retrieves posted values
    $office=checkPost('office');
    $redirect = checkPost('trail');
    $current_time= date('Y-m-d H:i:s');
printPost();

    //---------------BELOW CODE BLOCK FORMS START OF THE NEW DEVICE'S ID STRING---------------//
    $idString = '';
    /*switch(checkPost('device_type')){
        case 'Desktop':
            $idString = 'DT-';
        break;
        case 'Laptop':
            $idString = 'LT-';
        break;
        case 'Mobile Device':
            $idString = 'MD-';
        break;
        case 'Tablet':
            $idString = 'TB-';
        break;
        default:
            $idString = 'TH-';
        break;
    }-deprecated, changed to allow table-based values*/
    if(checkPost('device_type')){
        $tagQuery="SELECT * FROM field_values WHERE field='device_type' AND value='".checkPost('device_type')."'";
        toConsole(addslashes($tagQuery));
        if($tagResult=mysqli_query($conn,$tagQuery)){
            $tagRes=mysqli_fetch_array($tagResult);
            $idString = $tagRes['details'].'-';
        }
    }
        $idString .= date('Y');

    //---------------BELOW CODE BLOCK CHECKS device_list TO DETERMINE NEW DEVICE'S device_id----------------//
    $idQuery="SELECT MAX(RIGHT(device_id, 5)) AS 'maxim' FROM device_list WHERE device_id LIKE '".$idString."%'";
        $idResult = mysqli_query($conn,$idQuery);
            if(!$idResult || mysqli_num_rows($idResult)==0) {//no appropriate records are extant
                toConsole('No device of this type registered yet');
                $idString.="00001";
            }
            else{
                $idRes = mysqli_fetch_array($idResult);
                toConsole('Retrieved '.$idRes["maxim"]);
                $idString .= sprintf('%05d',(intval($idRes['maxim'])+1));
            }

    //---------------BELOW CODE BLOCK INSERTS NEW DEVICE INTO DB & LOGS TRANSACTION----------------//
    $queryString = 'INSERT INTO device_list VALUES ("'.$idString.'","'.$device_type.'","'.$owner.'","'.$office.'","'.$current_time.'");'; //query string to create entry in the ticket table - probs more efficient to just use joins for the extra details;
    print($queryString);
   if (mysqli_query($conn, $queryString)) {
    //echo $qString;    
        $logString=mysqli_real_escape_string($conn,"Device registered - ".$device_type." belonging to ".$owner." at ".$office.".");
        logDeviceChange(callUser(), $idString, $logString);


        if(checkPost('trail')=='activeticket.php'){
            $updateQuery="UPDATE tickets SET device_id='$idString' WHERE ticket_id='".checkPost('ticket_id')."'";
            print("updateQuery: ".$updateQuery);
            if(mysqli_query($conn,$updateQuery)){
                //successful
            }
        }

        if(checkPost('trail')){
            redirect(checkPost('trail'));
        }
        else{
            redirect('activeticket.php');
        }
    } 
    else {    //report sql error
        echo mysqli_error($conn);
    }
}
else{
    redirect('index.php');
}
                  
?>

