<?php

?>
<script>
function isNumberKey(evt){//checks whether the key pressed is a number - returns true if it is, false if it isn't
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

Number.prototype.pad = function(size) { //automatically pads integers with 0s up to the tens (2) place
  var s = String(this);
  while (s.length < (size || 2)) {s = "0" + s;}
  return s;
}

//----------------------SCRIPT FOR TOGGLING CHECKBOXES--------------------//
function toggleCbox(cBox){  //script shows/hides all objects with a class value equal to the value of the checkbox
  console.log('Checkbox '+cBox+' toggled');
  var passValue = cBox.value;
  if(cBox.checked){
      showTableRowByClass(passValue);
      //console.log(cBox.checked);  
  }
  else{
      hideElementsByClass(passValue);
      //console.log(cBox.checked);
  }
}
//-----------------END OF SCRIPT FOR TOGGLING CHECKBOXES--------------------//

function textAreaAdjust(o) {
  o.style.height = "1px";
  o.style.height = (o.scrollHeight)+"px";
}




//-----------------------SCRIPT FOR TOGGLING NEGATIVE CHECKBOXES--------------------//
function toggleNegativeCbox(cBox){  //reverse of above function - an unchecked textbox means the elements it oversees are shown
  console.log('Checkbox '+cBox+' toggled');
  var passValue = cBox.value;
  console.log('is checked: '+cBox.checked);
  if(!cBox.checked){
      showTableRowByClass(passValue);
      //console.log(cBox.checked);  
  }
  else{
      hideElementsByClass(passValue);
      //console.log(cBox.checked);
  }
}
//-----------------END OF SCRIPT FOR TOGGLING NEGATIVE CHECKBOXES--------------------//


//------------SCRIPT FOR HIDING ELEMENTS WITH A CLASS EQUAL TO THE PARAMETER----------//
function hideElementsByClass(colID){
  console.log(colID+' toggled');
  var hideThis = document.getElementsByClassName(colID);
  for(var counter=0;counter<hideThis.length;counter++){
    hideThis[counter].style.display='none';
  }
}
//----------END OF SCRIPT FOR HIDING ELEMENTS WITH A CLASS EQUAL TO THE PARAMETER-------//


//------------SCRIPT FOR SHOWING TABLE ROWS WITH A CLASS EQUAL TO THE PARAMETER----------//
function showTableRowByClass(colID){
  console.log(colID+' toggled');
  var showThis = document.getElementsByClassName(colID);
  for(var counter=0;counter<showThis.length;counter++){
    showThis[counter].style.display='table-row';
  }
}
//---------END OF SCRIPT FOR SHOWING TABLE ROWS WITH A CLASS EQUAL TO THE PARAMETER-------//


//-------------------SCRIPT TO SELECT A SPECIFIC OPTION FROM A DROP-DOWN------------------//
function setSelectedOption(id, valueToSelect)
{    
    var element = document.getElementById(id);
    element.value = valueToSelect;
}
//----------------END OF SCRIPT TO SELECT A SPECIFIC OPTION FROM A DROP-DOWN--------------//

/*
//-------------------JS FILTER FUNCTION FOR PURE TEXT TABLES-----------------//
var query = document.getElementById('searchstr');
var filter = query.value.toUpperCase();
var table = document.getElementById('outputTable');
var tr = table.getElementsByTagName('tr');
var td;

function filterTable(){ //(hopefully) filters table
    filter = query.value.toUpperCase();
    for (var i = 1; i < tr.length; i++) {//loops through each row
        //td = tr[i].getElementsByTagName("td");
        var rowToggle = false;
        for (var j = 0; j<tr[i].cells.length; j++){//loops through each cell in each row     
            txtValue = tr[i].cells[j].innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {//if cell contains value similar to seach query
                //console.log("found "+filter);
                tr[i].style.display = "table-row";
                rowToggle = true;
                    //code block to check values
                    console.log(txtValue);
                    console.log(filter);
                    console.log(txtValue.toUpperCase().indexOf(filter));
                    //end of code block to check values
            } 
            else {//query not in cell
                if(!rowToggle){
                    tr[i].style.display = "none";
                } 
                //console.log("did not find "+filter);
            }
        }
        console.log("row: "+rowToggle);
    }
}//--------------END OF JS FILTER FUNCTION FOR PURE TEXT TABLES-------------//*/


//--------------FUNCTION TO SORT A TABLE ACCORDING TO THE VALUES IN A ROW-----------------//
function sortTableByPriority() {//this function is slow as hell - need to optimize
  var table, rows, switching, i, x, y, shouldSwitch;
  var holderX, holderY; //variables to hold the numeric values of row contents
  table = document.getElementById("outputTable");
  switching = true;
  /* Make a loop that will continue until
  no switching has been done: */
  while (switching) {
    // Start by saying: no switching is done:
    switching = false;
    rows = table.rows;
    /* Loop through all table rows (except the
    first, which contains table headers): */
    for (i = 1; i < (rows.length - 1); i++) {
      // Start by saying there should be no switching:
      shouldSwitch = false;
      /* Get the two elements you want to compare,
      one from current row and one from the next: */
      x = getPriority(rows[i].getElementsByClassName("jstatus")[0].innerHTML);
      y = getPriority(rows[i + 1].getElementsByClassName("jstatus")[0].innerHTML);
      //console.log("x:"+rows[i].getElementsByClassName('jstatus')[0].innerHTML+" - y:"+rows[i].getElementsByClassName('jstatus')[0].innerHTML);
      // Check if the two rows should switch place:
      if (x > y) {
        // If so, mark as a switch and break the loop:
        shouldSwitch = true;
        break;
      }
    }
    if (shouldSwitch) {
      /* If a switch has been marked, make the switch
      and mark that a switch has been done: */
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
}
//--------------FUNCTION TO SORT A TABLE ACCORDING TO THE VALUES IN A ROW-----------------//


//--------------FUNCTION TO SORT A TABLE ACCORDING TO THE VALUES IN A ROW-----------------//
function sortTableByPriorityV2() {//second pass change name
  var table, rows, i, h, x, y;
  var escalated = [], suspended = [], ongoing = [], closed = [], open = [],other = [];
  var big = [other, open, closed, ongoing, suspended, escalated];
  var holderX, holderY; //variables to hold the numeric values of row contents
  table = document.getElementById("outputTable");
  rows = table.rows;
  for (i = 1 ; i < rows.length - 1 ; i++) {
    /* Loop through all table rows (except the
    first, which contains table headers): */
      x = (rows[i].getElementsByClassName("jstatus")[0].innerHTML);
      switch (x){
        case "Escalated":
          escalated.push(rows[i]);
        break;
        case "Suspended":
          suspended.push(rows[i]);
        break;
        case "Ongoing":
          ongoing.push(rows[i]);
        break;
        case "Closed":
          closed.push(rows[i]);
        break;
        case "Open":
          open.push(rows[i]);
        break;
        default:
          //other.push(rows[i]);
      }
  }
  for( i = 0 ; i < big.length ; i++ ){
    for ( h = 0 ; h < big[i].length ; h++ ){
        big[i][h].parentNode.insertBefore(big[i][h],rows[1]);
    }
  }
}
//--------------FUNCTION TO SORT A TABLE ACCORDING TO THE VALUES IN A ROW-----------------//

//--------------AUXILLARY FUNCTION USED BY sortTableByPriority TO ASSIGN NUMERICAL VALUES TO PRIORITY-------------------//
  function getPriority(priority){
    var statuses = ["Escalated","Suspended","Ongoing","Closed","Open"];
    for(var counter = 0 ; counter <= statuses.length ; counter++){
        if (statuses[counter] == priority){
          return (counter+1);
        }
        else if (counter == statuses.length){
          return 10;
        }
    } 
  }
//--------------AUXILLARY FUNCTION USED BY sortTableByPriority TO ASSIGN NUMERICAL VALUES TO PRIORITY-------------------//

</script>