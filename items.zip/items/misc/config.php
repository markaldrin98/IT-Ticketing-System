<?php if(session_status()!=PHP_SESSION_ACTIVE) session_start();
?>
<!-- jQuery library -->
<script src="js/jquery.min.js"></script>
<script src="misc/dyntables/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" type="text/css" href="misc/dyntables/jquery.dataTables.min.css">
<?php

include 'config_php_functions.php';
include 'config_scripts.php';

   global $conn;
   //BELOW CONNECTION PARAMS ARE FOR WHEN THE SYSTEM IS BEING DEVELOPED/TESTED
   
   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "testticketdatabase"; //change this -> temporarily changed
   
   
   //BELOW CONNECTION PARAMS ARE FOR WHEN THE SYSTEM IS LIVE
   /*
   $servername = "127.0.0.1:3307";
   $username = "marko";
   $password = "Markomalapitan";
   $dbname = "testticketdatabase"; //change this -> temporarily changed
   */
   

   $conn = mysqli_connect($servername, $username, $password, $dbname);

  //----------------------FILTER TO CHECK IF USER SHOULD BE ON THIS PAGE---------------------//
    $openPages = array("index.php", "createticket.php", "sendticket.php","login.php","checkcredentials.php","proof.php","ticketcreated.php");
    $currentPage = basename($_SERVER['PHP_SELF']);
    toConsole("current page: ".$currentPage);
    if(!callUser() && !in_array($currentPage, $openPages)){//executes this clause when no user is logged in and page is not 'open'
      redirect('index.php');
    }
  //-------------------END OF FILTER TO CHECK IF USER SHOULD BE ON THIS PAGE-----------------//

/*if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){
  //redirect('login.php?op=login');
}
else{  //this function forces login
  redirect('login.php');
}*/
?>
<style>/* Center the loader */

.log-in-style {
  
  font-size: 0.8rem !important;
}

.btnLogin {
  border-radius: 25px !important;
}

#loader {

position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid orange;
  -webkit-animation: spin 1s linear infinite;
  animation: spin 1s linear infinite;
  zoom: 50%;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

/* Add animation to "page content" */
.animate-bottom {
  position: relative;
  -webkit-animation-name: animatebottom;
  -webkit-animation-duration: 1s;
  animation-name: animatebottom;
  animation-duration: 1s
}

@-webkit-keyframes animatebottom {
  from { bottom:-100px; opacity:0 } 
  to { bottom:0px; opacity:1 }
}

@keyframes animatebottom { 
  from{ bottom:-100px; opacity:0 } 
  to{ bottom:0; opacity:1 }
}

#myDiv {
  display: none;
  }

@media screen and (max-width: 800px){#loader {zoom: 20%;}}

</style>
<div id="myContainer">
<body class="bgBox" id="bg">

<nav class="navbar navbar-expand-sm navbar-dark fixed-top navbar-custom">
  <img src="img/ITDOLogo.png" width="30"> &nbsp;
  <a class="navbar-brand" href="index.php">ITDO Ticketing System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item"><a class="nav-link" href="index.php"><span class="oi oi-rss-alt"></span> Home</a></li>
          <?php //sets right end of nav bar (changes elements depending on whether or not there is a user logged in)
        if(isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true){  
           echo '
           <li class="nav-item dropdown"><a class="nav-link dropdown-toggle" id="navbardrop" data-toggle="dropdown" href="#"><span class="glyphicon glyphicon-user"></span> Welcome, '.$_SESSION["client_name"].' <span class="glyphicon glyphicon-triangle-bottom"></span></a>
                <ul class="dropdown-menu">
                  <li class="nav-item"><a class="dropdown-item" href="createticket.php"><span class="glyphicon glyphicon-file"></span> Create Ticket</a></li>
                  <li class="nav-item"><a class="dropdown-item" href="outstanding.php"><span class="glyphicon glyphicon-list"></span> Outstanding Tickets</a></li>
                  <li class="nav-item"><a class="dropdown-item" href="activeticket.php"><span class="glyphicon glyphicon-check"></span> Active Ticket</a></li>
                  <li class="nav-item"><a class="dropdown-item" href="references.php"><span class="glyphicon glyphicon-check"></span> References</a></li>';

            if(checkUserPrivilege()=="admin"){
                  echo '<li class="nav-item"><a class="dropdown-item" href="registeruser.php"><span class="glyphicon glyphicon-check"></span> Register New User</a></li>';
                  echo '<li class="nav-item"><a class="dropdown-item" href="usermanagement.php"><span class="glyphicon glyphicon-check"></span> Manage Users</a></li>';
                  echo '<li class="nav-item"><a class="dropdown-item" href="fieldmanagement.php"><span class="glyphicon glyphicon-check"></span> Manage Field Values</a></li>';
                  echo '<li class="nav-item"><a class="dropdown-item" href="reports.php"><span class="glyphicon glyphicon-tasks"></span> Reports</a></li>';
            }

            echo '
                  <li class="nav-item"><a class="dropdown-item" href="devicemanagement.php"><span class="glyphicon glyphicon-list-alt"></span> Device Management</a></li>
                  <li class="nav-item"><a class="dropdown-item" href="changepass.php"> Change Password</a></li>
                  <li class="nav-item"><a class="dropdown-item" data-toggle="modal" href="#" data-target="#deactAccount"> Deactivate Account</a></li>
                  
                  <li class="nav-item"><a class="dropdown-item" href="#">
                  <div class="custom-control custom-switch">
                    <input class="custom-control-input myCheckbox" id="switch1" type="checkbox" name="checkbox" value="value" onclick="myFunction()"> <label class="custom-control-label" for="switch1" ><span id="demo">Dark</span> Mode</label>
                    </div>
                    </a></li>
                  <li class="nav-item"><a class="dropdown-item" href="logout.php"><span class=" glyphicon glyphicon-log-out"></span> Log Out</a></li>
                </ul>
           </li>'; 
       /*    echo '<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log Out</a></li>'; */
        }
        else{
         /*  echo '<a href="register.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a>'; */
           echo '
           <li class="nav-item">
              <a class="nav-link" data-toggle="modal" data-target="#loginModal" href="index.php">
                <span class="glyphicon glyphicon-home"></span>Login
              </a>
           </li>
      ';

        }
    ?> 
    <li style="<?php //echo $navigation;?>" class="nav-item dropdown"><a class="nav-link dropdown-toggle" data-toggle="dropdown" id="navbardrop" href="#">Ticket Queue <span class="glyphicon glyphicon-triangle-bottom"></span></a>
                <ul class="dropdown-menu ticketStyle">
                  <div class="lineBottom">
                    <div class="textLeft">
                      <li class="nav-item">
                        <span class="dropdown-item-text" style="color: lightgreen;">Ongoing: </span>
                      </li>
                    </div>
                    <div class="textRight">  
                      <li class="nav-item">
                        <ul>
                        <?php printTickets(getTickets('Ongoing'));
                        if(!getTickets('Ongoing')){
                          echo "<li><span style='color:white'>No Tickets</span></li>";
                        }
                        ?>
                        <!--above function call outputs all ticket IDs tagged 'Ongoing'-->
                        </ul>
                    </div>
                  </div> 
                  <div class="lineBottom">
                    <div class="textLeft"> 
                      <li class="nav-item">
                        <span class="dropdown-item-text" style="color: #00ccff;">Pending: </span>
                      </li>
                    </div>
                    <div class="textRight">  
                      <li class="nav-item">
                        <ul>
                        <?php 
                          printTickets(getTickets('Escalated'));
                          printTickets(getTickets('Open'));
                          if(!getTickets('Escalated') && !getTickets('Open')){
                            echo "<li><span style='color:white'>No Tickets</span></li>";
                          }
                        ?>
                        <!--above function call outputs all ticket IDs tagged 'Open'-->
                        </ul>
                      </li>
                    </div>
                  </div>         
              </ul>
           </li>
    </ul>
  </div>  
</nav>

<!-- Modal for Deactivate Account --> 
 <div class="modal fade" id="deactAccount">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Confirmation</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <div class="modal-body">
          <p>Are you sure you want to deactivate your account?</p>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
        <form action="deactivate.php" method="post">
          <input type="submit" class="btn btn-danger" name="Submit" style="width: 100%;" value="Yes">
          <?php
            createHiddenInput('username',callUsername());
          ?>
        </form>
          <button class="btn btn-primary mr-auto" data-dismiss="modal" style="width: 100%;">No</button>
        </div>
        
      </div>
    </div>
  </div>
 

<!-- Modal for Login -->
<div id="loginModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header bgOrange">
        <h4 class="modal-title centerText">Log In</h4>
      </div>
      <div class="modal-body">
        <form class='login100-form validate-form' action='checkcredentials.php' method='post'>
            <div class='form-group'>
              <label for='username' title='Username' data-title='Username'>Username</label>
              <input type='text' required autocomplete='off' id='username' required name='username' class='form-control log-in-style' autofocus autocapitalize="off">
            </div>        
            <div class='form-group'>
              <label for='password' title='Password' data-title='Password'>Password</label>
              <input type='Password' id='password' required name='password' class='form-control log-in-style'>
            </div>
            <div class='container-login100-form-btn'>
              <div class='wrap-login100-form-btn'>             
                <input type='submit' value='Log In' name='Submit' id='Submit' class='modalButton btnLogin'>
              </div>    
            </div>
        </form>
      </div>  
    </div>
  </div>
</div>
</body>

<head>
  <link rel="stylesheet" type="text/css" href="css/dropdown.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
  <link rel="stylesheet" href="css/all.css">
  <link rel="stylesheet" type="text/css" href="css/fontStyle.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="darkmode.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="js/bootstrap.min.js"></script>
<script src="js/all.js"></script>
<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Open+Sans" />

<!--Library used to sort tables-->
<!--<script src="misc/sorttable.js"></script>-->

</head>
<script>

  var myVar;

function loadingScreen() {
  myVar = setTimeout(showPage, 1500);
  console.log("Loading timeout");
}

function showPage() {
  document.getElementById("loader").style.display = "none";
  document.getElementById("myDiv").style.display = "block";
}

</script>


<script></script>