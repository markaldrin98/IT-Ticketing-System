<?php
function checkSQLError(){ //prints most recent SQL error to console
        global $conn;
        echo '<script>console.log("Error - '.mysqli_error($conn).'");</script>';
}

//---------------------------------FUNCTION TO PREPARE -> EXECUTE UPDATE QUERY & LOG CHANGE-----------------//
function prepareUpdate($ticketID, $fieldName, $storedValue, $givenValue){
  global $conn;
  $givenValue = mysqli_real_escape_string ($conn,$givenValue);  //escapes $givenValue with respect to $conn
  $givenValue = str_replace(";","",$givenValue);  //primitive method to prevent sql injection - improve this
if($givenValue!=$storedValue){   
  $outString = "UPDATE tickets SET ".$fieldName." = '".$givenValue."' WHERE ticket_id='".$ticketID."'";//code block updates field if stored value does not equal given value
  if (mysqli_query($conn, $outString)) {
      } else { 
          checkSQLError();
      }          
  //end of code block

    $logString = "Changed ".$fieldName." from "; //code block prepares string that logs what field was changed and what it was changed from and to
    if($storedValue==null){
        $storedValue= 'empty';
    }   
      $logString.=$storedValue;
      $logString.=" to ";
    if($givenValue==null){
        $givenValue= 'empty';
    }     
      $logString.=$givenValue;
      print($ticketID);
      print($logString);
      print($outString);
    logChange($_SESSION['client_name'],$ticketID,$logString);//logs change
    //end of code block
  }
}
//-----------------------------END OF FUNCTION TO PREPARE -> EXECUTE UPDATE QUERY & LOG CHANGE-----------------//


function redirect($url) //----function to redirect browser to specified $url
{
    if (!headers_sent())
    {    
        header('Location: '.$url);
        exit;
        }
    else
        {
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
    }
}                       //----end of function to redirect browser to specified $url

//----------------------------FUNCTION TO LOG A CHANGE MADE TO A TICKET----------------------------//
function logChange($admin,$ticket,$change_made){ //function to log a change
    echo "<script>console.log('Logger called')</script>";
    global $conn;
    $logString = "INSERT INTO ticket_changelog(admin,ticket,change_made) VALUES('".$admin."','".$ticket."','".$change_made."')";
    if (mysqli_query($conn, $logString)) {
        echo "<script>console.log('Change log created')</script>";
        } else {
        echo "<script>console.log('Failed to create change log".mysqli_error($conn)."')</script>";
        }   

}                       //end of function to log a change
//-------------------------END OF FUNCTION TO LOG A CHANGE MADE TO A TICKET------------------------//

//----------------------------FUNCTION TO LOG A CHANGE MADE TO A DEVICE----------------------------//
function logDeviceChange($admin,$device,$change_made){ //function to log a change
    echo "<script>console.log('Logger called')</script>";
    global $conn;
    $logString = "INSERT INTO device_changelog(admin,date_time_logged,device_id,change_made) VALUES('".$admin."',now(),'".$device."','".$change_made."')";
    if (mysqli_query($conn, $logString)) {
        echo "<script>console.log('Change log created')</script>";
        } else {
        echo "<script>console.log('Failed to create change log: ".addslashes(mysqli_error($conn))."')</script>";
        }   
}                       //end of function to log a change
//-------------------------END OF FUNCTION TO LOG A CHANGE MADE TO A DEVICE------------------------//

//----------------------------FUNCTION TO LOG A CHANGE MADE TO THE field_values TABLE----------------------------//
function logFieldValueChange($admin,$change_made){ //function to log a change
    echo "<script>console.log('Logger called')</script>";
    global $conn;
    $logString = "INSERT INTO field_values_changelog(admin,date_time_logged,change_made) VALUES('".$admin."',now(),'".$change_made."')";
    if (mysqli_query($conn, $logString)) {
        echo "<script>console.log('Change log created')</script>";
        } else {
        echo "<script>console.log('Failed to create change log: ".addslashes(mysqli_error($conn))."')</script>";
        }   

}                       //end of function to log a change
//-------------------------END OF FUNCTION TO LOG A CHANGE MADE TO THE field_values TABLE------------------------//


//------------------------------------FUNCTION THAT PRINTS PARAMETER TO CONSOLE------------------------------------//
function toConsole($consoleString){  //function outputs parameter into browser console via script  
    $consoleString=addslashes($consoleString);
    echo "<script>console.log('".$consoleString."');</script>";
}
//--------------------------------END OF FUNCTION THAT PRINTS PARAMETER TO CONSOLE------------------------------------//


//------------------------------------FUNCTION THAT CHECKS PRIVILEGE OF USER------------------------------------//
function checkUserPrivilege(){  //function checks userType of user in $_SESSION
    if(isset($_SESSION['userType']) && $_SESSION['userType']!=''){
      toConsole('True: '.$_SESSION['userType']);
      return($_SESSION['userType']);
    }
    else{
      toConsole('False: no user logged in');
      return(false);
    }
}
//--------------------------------END OF FUNCTION THAT CHECKS PRIVILEGE OF USER------------------------------------//



//---------------------------------------FUNCTION THAT CHECKS NAME OF USER-----------------------------------------//
function checkUser(){  //function checks userType of user in $_SESSION
    if(isset($_SESSION['client_name']) && $_SESSION['client_name']!=''){
      toConsole('True: '.$_SESSION['client_name']);
      return($_SESSION['client_name']);
    }
    else{
      toConsole('False: '.$_SESSION['client_name']);
      return false;
    }
}
//----------------------------------END OF FUNCTION THAT CHECKS NAME OF USER---------------------------------------//


//------------------------------------FUNCTION CHECKS IF PARAMETER IS PRESENT IN $_POST ARRAY----------------------------------------//
function checkPost($parameterToCheck){
    if(isset($_POST[$parameterToCheck]) && $_POST[$parameterToCheck]!=''){
      //toConsole($parameterToCheck.' present: '.$_POST[$parameterToCheck]);
      return($_POST[$parameterToCheck]);       //parameter is present, return value
    }
    else{
      //toConsole($parameterToCheck.' absent');
      return(false);                           //parameter is absent, return false
    }
}
//-------------------------------END OF FUNCTION TO CHECK IF PARAMETER IS PRESENT IN $_POST ARRAY-----------------------------------//


//------------------------------------FUNCTION CHECKS IF PARAMETER IS PRESENT IN $_GET ARRAY----------------------------------------//
function checkGet($parameterToCheck){
    if(isset($_GET[$parameterToCheck]) && $_GET[$parameterToCheck]!=''){
      //toConsole($parameterToCheck.' present: '.$_GET[$parameterToCheck]);
      return($_GET[$parameterToCheck]);       //parameter is present, return value
    }
    else{
      //toConsole($parameterToCheck.' absent');
      return(false);                           //parameter is absent, return false
    }
}
//-------------------------------END OF FUNCTION TO CHECK IF PARAMETER IS PRESENT IN $_GET ARRAY------------------------------------//

function printPost(){  
        foreach ($_POST as $key => $entry)
        {
             print $key . ": " . $entry . "<br>";
        }
}
//------------------------------END OF FUNCTION THAT CHECKS IF PARAMETER IS PRESENT IN $_POST ARRAY----------------------------------//

function callUser(){//returns name of current user
  if(isset($_SESSION["client_name"]) && $_SESSION["client_name"]!=''){
    return $_SESSION["client_name"];    
  }
  else{
    return false; 
  }
}

function checkArray($givenArray){//prints a list of all key-value pairs in givenArray to console(givenArray should be associative)
  foreach ($givenArray as $key => $value){
    toConsole($key." : ".$value);
  }
}

//------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE FIELDS OF table PARAMETER------//
function retrieveFields($tableName){//receives table name and returns numbered array containing the names of its fields - if query fails (i.e. table specified doesn't exist), return false
  global $conn;
  $fieldQuery = "
    SELECT COLUMN_NAME
    FROM INFORMATION_SCHEMA.COLUMNS
    WHERE TABLE_NAME = '".$tableName."'
    ORDER BY ORDINAL_POSITION
  "; 
  if($fieldResult = mysqli_query($conn,$fieldQuery)){
    $values = array();                                          //numeric array to contain field names
    while($fieldRes = mysqli_fetch_array($fieldResult)){
      array_push($values, $fieldRes['COLUMN_NAME']);            //push each column name into $values
    }
    return $values;
  }
  else{
    return false;
  }
}//---------------------------------end of retrieveFields--------------------------//


//------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE OPTIONS FOR A SELECT CONTROL TAGGED <parameter>------//
function retrieveOptions($selectTag,$sortToggle){//receives select tag and sort toggle then returns an associative array containing a key-value pair with value(key)=>details(value) - if query fails (i.e. select tag specified doesn't exist), return false
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM field_values 
  WHERE field = '".$selectTag."'
  "; 
  if($sortToggle){
    $optionQuery .= " ORDER BY value";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      $key=$optionRes['value'];
      $value=$optionRes['details'];
      $values[$key]=$value;
    }
    return $values;
  }
  else{
    return false;
  }
}//-------------------------------------------end of retrieveOptions---------------------------------------//



//------FUNCTION THAT RETURNS AN ARRAY CONTAINING ALL VALUES OF $selectTag THAT HAVE BEEN USED IN THE TICKETS OF THE GIVEN $year------//
function retrieveActiveValues($selectTag,$start,$end){//returns an associative array containing a key-value pair with value(key)=>details(value) - if query fails (i.e. select tag specified doesn't exist), return false
  global $conn;
  $optionQuery = "
    SELECT DISTINCT $selectTag
    FROM tickets 
    WHERE 
      date_fulfilled IS NOT NULL
      AND datediff(date_fulfilled,'$start') >= 0
      AND datediff(date_fulfilled,'$end') <= 0 
    ORDER BY $selectTag
  ";

  /*if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    $counter = 0;
    while($optionRes = mysqli_fetch_array($optionResult,MYSQLI_NUM)){
      //print_r($optionRes);
      $values[$counter] = $optionRes[0];
      $counter++;
    }
    return $values;
  }
  else{
    return false;
  }*///old return clause

    $values = array();
    if($optionResult = mysqli_query($conn,$optionQuery)){
      $counter = 0;
      while($optionRes = mysqli_fetch_array($optionResult,MYSQLI_NUM)){
        //print_r($optionRes);
        $values[$counter] = $optionRes[0];
        $counter++;
      }
    }
    return $values;
}//-------------------------------------------end of retrieveOptions---------------------------------------//


//------FUNCTION THAT RETURNS A NUMERIC ARRAY CONTAINING THE OPTIONS FOR A SELECT CONTROL TAGGED <parameter>------//
function retrieveOptionsNum($selectTag,$sortToggle){//receives select tag and sort toggle then returns an associative array containing a key-value pair with value(key)=>details(value) - if query fails (i.e. select tag specified doesn't exist), return false
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM field_values 
  WHERE field = '".$selectTag."'
  "; 
  if($sortToggle){
    $optionQuery .= " ORDER BY value";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      array_push($values, $optionRes['value']);
    }
    return $values;
  }
  else{
    return false;
  }
}//-------------------------------------------end of retrieveOptions---------------------------------------//

//------FUNCTION THAT RETURNS A NUMERIC ASSOCIATIVE ARRAY CONTAINING THE PARTS AND DETAILS FOR A GIVEN device_id------//
function retrieveParts($device_id){//receives select tag and sort toggle then returns an associative array containing a key-value pair with value(key)=>details(value) - if query fails (i.e. select tag specified doesn't exist), return false
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM device_parts_table 
  WHERE device_id = '".$device_id."'
  "; 
  if($specsResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($specsRes = mysqli_fetch_array($specsResult)){
      $key=$specsRes['peripheral'];
      $value=$specsRes['details'];
      $values[$key]=$value;
    }
    return $values;
  }
  else{
    return false;
  }
}//-------------------------------------------end of retrieveParts---------------------------------------//


//------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE SPECS FOR A GIVEN device_id------//
function retrieveSpecs($device_id){//queries given device_id against device_specs_table
  global $conn;
  $optionQuery = "
  SELECT * 
  FROM device_specs_table 
  WHERE device_id = '".$device_id."'
  "; 
  if($specsResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($specsRes = mysqli_fetch_array($specsResult)){
      $key=$specsRes['specification'];
      $value=$specsRes['details'];
      $values[$key]=$value;
    }
    return $values;//returns numeric array containing all given specs of device_id
  }
  else{
    return false;//query fails, return false
  }
}//-------------------------------------------end of retrieveSpecs---------------------------------------//


//------FUNCTION THAT RETURNS AN ARRAY OF DETAILS FOR A GIVEN device_id------//
function retrieveDetails($device_id){
  global $conn;
  $detailQuery = "
  SELECT * 
  FROM device_list 
  WHERE device_id = '".$device_id."'
  ";   
  if($specsResult = mysqli_query($conn,$detailQuery)){
    return mysqli_fetch_array($specsResult);
  }
  else{
    return false;
  }
}
//---END OF FUNCTION THAT RETURNS AN ARRAY OF DETAILS FOR A GIVEN device_id---//

//---FUNCTION THAT TAKES AN ASSOCIATIVE ARRAY AND ECHOES IT AS A COLLECTION OF LIST ITEMS <li>---//
function printArray($list){
  if(!$list){//$list is empty, nothing to display
    echo "<li class='list-group-item'>Nothing to display</li>";
  }
  else{//$list is populated, display all items
    foreach($list as $key => $value){
      echo "<li class='list-group-item'>".$key." - ".$value."</li>";
    }
  }
}
//---END OF FUNCTION THAT TAKES AN ASSOCIATIVE ARRAY AND ECHOES IT AS A COLLECTION OF LIST ITEMS <li>---//


function displayArrayValues($values){
  for($i=0;$i<count($values);$i++){
    echo $values[$i];
  }
}


//------FUNCTION THAT RETURNS AN ARRAY CONTAINING A LIST OF REGISTERED TECHS AND THEIR CURRENT ACTIVE TICKETS------//
function retrieveTechs($sortToggle){//retrieves list of techs - if parameter is true, sort array alphabetically
  global $conn;
  $optionQuery = "
  SELECT employee_name, current_ticket 
  FROM tech_credentials 
  WHERE status = 'active'
  "; 
  if($sortToggle){
    $optionQuery .= " ORDER BY employee_name";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      $key=$optionRes['employee_name'];
      $value=$optionRes['current_ticket'];
      $values[$key]=$value;
    }
    //return $values;//uncomment this 
  }
  /*else{
    return false;//and this if function should only return an associative array where (employee_name=>current_ticket)
  }*/

  //--------------------MODULE TO OUTPUT A SELECT--------------------//
    $selectString = '<select class="form-control" name="respondent" id="respondent" ';
        $selectString.= '>';
        $selectString.= '<option value="">None</option>';
        foreach ($values as $key => $value){
              $selectString .='<option value="';                     //start of option
              $selectString .=$key.'" ';                             //value of option
              $selectString .='data-option-description="'.$value.'" ';//append option details as an extraneous property
              if($value!=""){
                $selectString .= "disabled";
              }
              if($key == ""){                                        //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                  $selectString.='>none</option>';}                  //null-value fields are expressed as 'none'
                  //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
              else{
                  $selectString.='>'.$key.'</option>';}              //end of option      
        }
        $selectString.= '</select>';
        echo $selectString;
  //----------------END OF MODULE TO OUTPUT A SELECT-----------------//
}
//------FUNCTION THAT RETURNS AN ARRAY CONTAINING A LIST OF REGISTERED TECHS AND THEIR CURRENT ACTIVE TICKETS------//

//------FUNCTION THAT RETURNS AN ARRAY CONTAINING A LIST OF REGISTERED TECHS AND THEIR CURRENT ACTIVE TICKETS------//
function retrieveTechsSelected($sortToggle,$techname){//retrieves list of techs - if parameter is true, sort array alphabetically
  global $conn;
  $optionQuery = "
  SELECT employee_name, current_ticket 
  FROM tech_credentials 
  WHERE status = 'active'
  "; 
  if($sortToggle){
    $optionQuery .= " ORDER BY employee_name";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      $key=$optionRes['employee_name'];
      $value=$optionRes['current_ticket'];
      $values[$key]=$value;
    }
    //return $values;//uncomment this 
  }
  /*else{
    return false;//and this if function should only return an associative array where (employee_name=>current_ticket)
  }*/

  //--------------------MODULE TO OUTPUT A SELECT--------------------//
    $selectString = '<select class="form-control" name="respondent" id="respondent" ';
        $selectString.= '>';
        $selectString.= '<option value="">None</option>';
        foreach ($values as $key => $value){
              $selectString .='<option value="';                     //start of option
              $selectString .=$key.'" ';                             //value of option
              $selectString .='data-option-description="'.$value.'" ';//append option details as an extraneous property
              if($key==$techname){
                $selectString .= " selected";
              }
              if($value!=""){
                $selectString .= " disabled";
              }
              if($key == ""){                                        //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                  $selectString.='>none</option>';}                  //null-value fields are expressed as 'none'
                  //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
              else{
                  $selectString.='>'.$key.'</option>';}              //end of option      
        }
        $selectString.= '</select>';
        echo $selectString;
  //----------------END OF MODULE TO OUTPUT A SELECT-----------------//
}
//------FUNCTION THAT RETURNS AN ARRAY CONTAINING A LIST OF REGISTERED TECHS AND THEIR CURRENT ACTIVE TICKETS------//


//------FUNCTION THAT RETURNS A LIST OF REGISTERED DEVICES------//
function retrieveDevices(){//retrieves and outputs a list of registered devices
  global $conn;
  $optionQuery = "
  SELECT device_id
  FROM device_list
  "; 
  $values = array();
  if($optionResult = mysqli_query($conn,$optionQuery)){
    while($optionRes = mysqli_fetch_array($optionResult)){
      array_push($values,$optionRes['device_id']);
    }
  }
  //--------------------MODULE TO OUTPUT A DATALIST--------------------//
    $selectString = "<datalist id='deviceList'>";                     //start of datalist
        for ($counter = 0 ; $counter < count($values) ; $counter++){
              $selectString .='<option value="';                      //start of option
              $selectString .=$values[$counter].'" ';                 //inserts value of option
              $selectString.='>'.$values[$counter].'</option>';       //end of option     
        }
        $selectString.= '</datalist>';                                //end of datalist
        echo $selectString;
  //----------------END OF MODULE TO OUTPUT A DATALIST-----------------//
}
//------END OF FUNCTION THAT RETURNS A LIST OF REGISTERED DEVICES------//


  //---------------------------------FUNCTION TO RENDER A TIMER--------------------------------------//
  function outputTimer($queryString,$ticketID){ //takes a $queryString formatted to retrieve a specific TIMESTAMPDIFF, and a ticket ID to identify the row it queries        
      global $conn;
      if ($timeResult=mysqli_query($conn, $queryString)) { //code block retrieves date values to check
        $timeRes=mysqli_fetch_array($timeResult);
      } 
      else{                                                //query fails, echo error
        echo mysqli_error($conn);
        echo $queryString;
      }
          $outHours = (int)$timeRes['time_elapsed_hours'];
          $outMins = (int)$timeRes['time_elapsed_minutes'];
          $outSecs = (int)$timeRes['time_elapsed_seconds'];
      echo "<td>";       //starts td that echoes base value of time elapsed - updated by JS every second (see persistentClock()
      echo "<span id='hour_display".$ticketID."'>".sprintf('%02d', ($outHours))."</span>:";//hour value returned by sql is the current number of hours from stored value to now() //the query returns whole hours, so there's no need to mod (not sure if this would still apply if hours>24)
      echo "<span id='minute_display".$ticketID."'>".sprintf('%02d', ($outMins%60))."</span>:";//minute value returned by sql is the total number of minutes between now() and stored value - modding by 60 drops the full hours and leaves only the minutes short of an hour
      echo "<span id='second_display".$ticketID."'>".sprintf('%02d', ($outSecs%60))."</span>";//as above, leaves only the seconds short of a minute
      echo "</td>";       //ends that echoes base value of time elapsed
      //toConsole(gettype($timeRes['time_elapsed_minutes']));
  }
  //-----------------------------END OF FUNCTION TO RENDER A TIMER-------------------------------------//

  //---------------------------------FUNCTION TO OUTPUT A SELECT CONTROL----------------------------------//
  function outputSelect($nameString,$storedValue,$valueArray,$isRequired){
    $selectString = '<select class="form-control" name="'.$nameString.'" id="'.$nameString.'" ';
          if($isRequired){                                       //if select should be <required>, append tag to select
            $selectString.= "required";
          }
    $selectString.= '>';
    if(!array_key_exists($storedValue, $valueArray)){//stored value is not in $valueArray
      if(!$storedValue){//stored value is null or empty
        $selectString.= "<option disabled selected value=''>No ".$nameString."</option>";
      }
      else{//stored value is a unique/special value
        $selectString.= "<option disabled selected value='$storedValue'>$storedValue</option>";
      }
    }
    //$selectString.= "<option disabled selected value=''>No ".$nameString."</option>";
    foreach ($valueArray as $key => $value){
          $selectString .='<option value="';                        //start of option
          $selectString .=$key.'" ';                                //value of option
          $selectString .='data-option-description="'.$value.'" ';  //append option details as an extraneous property
          if($storedValue == $key){                               //check for equality between option value and stored value
             $selectString.="selected";}                          //if equal, add 'selected' property to option
          /*if(!$key){                                           //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
              //$selectString.='>none</option>';}                     //null-value fields are expressed as 'none'
              $selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
          else{*/
              $selectString.='>'.$key.'</option>';
              //}                 //end of option      
    }
    $selectString.= '</select>';
    echo $selectString;
  }
  //----------------------------END OF FUNCTION TO OUTPUT A SELECT CONTROL-----------------------------//


  //---------------------------------FUNCTION TO OUTPUT A SELECT CONTROL WITH A GIVEN DISPLAY STRING FOR VALUE="" AND A SWITCH TO OUTPUT AN "OTHERS" ITEM----------------------------------//
  function outputFullSelect($nameString,$storedValue,$valueArray,$isRequired,$nullString,$othersToggle){
    //if $othersToggle is true, output an Others item
    //$nullstring is the value placed inside the option that has a null value (i.e. the placeholder option)
    //each member of $valueArray is outputed as an option
    //the value of $storedValue is automatically selected, if the value is present in $valueArray
    $selectString = '<select class="form-control" name="'.$nameString.'" ';
          if($isRequired){                                       //if select should be <required>, append tag to select
            $selectString.= "required";
          }
    $selectString.= '>';
    if(!array_key_exists($storedValue, $valueArray)){//stored value is not in $valueArray
      if(!$storedValue){//stored value is null or empty
        $selectString.= "<option disabled selected value=''>".$nullString."</option>";
      }
      else{//stored value is a unique/special value
        $selectString.= "<option disabled selected value='$storedValue'>$storedValue</option>";
      }
    }
    //$selectString.= "<option disabled selected value=''>No ".$nameString."</option>";
    foreach ($valueArray as $key => $value){
          $selectString .='<option value="';                              //start of option
          $selectString .=$key.'" ';                                      //value of option
          $selectString .='data-option-description="'.$value.'" ';        //append option details as an extraneous property
          if($storedValue == $key){                                       //check for equality between option value and stored value
             $selectString.="selected";}                                  //if equal, add 'selected' property to option
          /*if(!$key){                                                    //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
              //$selectString.='>none</option>';}                         //null-value fields are expressed as 'none'
              $selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
          else{*/
              $selectString.='>'.$key.'</option>';
              //}                 //end of option      
    }
    if($othersToggle){
      $selectString .='<option value="Others">Others</option>';
    }
    $selectString.= '</select>';
    echo $selectString;
  }
  //----------------------------END OF FUNCTION TO OUTPUT A SELECT CONTROL WITH A GIVEN DISPLAY STRING FOR VALUE="" AND A SWITCH TO OUTPUT AN "OTHERS" ITEM-----------------------------//



  //---------------------------------FUNCTION TO OUTPUT A SELECT CONTROL WITH A GIVEN DISPLAY STRING FOR VALUE="" AND A SWITCH TO OUTPUT AN "OTHERS" ITEM----------------------------------//
  function outputFullerSelect($nameString,$storedValue,$valueArray,$isRequired,$nullString,$othersToggle,$changeFunction){
    //if $othersToggle is true, output an Others item
    //$nullstring is the value placed inside the option that has a null value (i.e. the placeholder option)
    //each member of $valueArray is outputed as an option
    //the value of $storedValue is automatically selected, if the value is present in $valueArray
    $selectString = '<select style="width: 70%;" class="form-control printHide"  name="'.$nameString.'" id="'.$nameString.'" ';
          if($isRequired){                                       //if select should be <required>, append tag to select
            $selectString.= "required";
          }
    $selectString.= "onchange='$changeFunction(this)'";
    $selectString.= '>';
    if(!array_key_exists($storedValue, $valueArray)){//stored value is not in $valueArrayxa
      if(!$storedValue){//stored value is null or empty
        $selectString.= "<option disabled selected value=''>".$nullString."</option>";
      }
      else{//stored value is a unique/special value
        $selectString.= "<option disabled selected value='$storedValue'>$storedValue</option>";
      }
    }
    //$selectString.= "<option disabled selected value=''>No ".$nameString."</option>";
    if(array_keys($valueArray) !== range(0, count($valueArray) - 1)){
      foreach ($valueArray as $key => $value){
            $selectString .='<option value="';                              //start of option
            $selectString .=$key.'" ';                                      //value of option
            $selectString .='data-option-description="'.$value.'" ';        //append option details as an extraneous property
            if($storedValue == $key){                                       //check for equality between option value and stored value
               $selectString.="selected";}                                  //if equal, add 'selected' property to option
            /*if(!$key){                                                    //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                //$selectString.='>none</option>';}                         //null-value fields are expressed as 'none'
                $selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
            else{*/
                $selectString.='>'.formatString($key).'</option>';
                //}                 //end of option      
      }      
    } 
    else{
      foreach ($valueArray as $key => $value){
            $selectString .='<option value="';                              //start of option
            $selectString .=$value.'" ';                                      //value of option
            if($storedValue == $value){                                       //check for equality between option value and stored value
               $selectString.="selected";}                                  //if equal, add 'selected' property to option
            /*if(!$key){                                                    //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
                //$selectString.='>none</option>';}                         //null-value fields are expressed as 'none'
                $selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
            else{*/
                $selectString.='>'.formatString($value).'</option>';
                //}                 //end of option      
      }      
    }
    if($othersToggle){
      $selectString .='<option value="Others">Others</option>';
    }
    $selectString.= '</select>';
    echo $selectString;
    echo "<br>";
  }
  //----------------------------END OF FUNCTION TO OUTPUT A SELECT CONTROL WITH A GIVEN DISPLAY STRING FOR VALUE="" AND A SWITCH TO OUTPUT AN "OTHERS" ITEM-----------------------------//



  //---------------------------------FUNCTION TO OUTPUT A SPECIAL SELECT CONTROL (HAS AN ONCHANGE FUNCTION)----------------------------------//
  function outputSpecialSelect($nameString,$storedValue,$valueArray,$isRequired,$selectOnchange){
    $selectString = '<select class="form-control" required autocomplete="off" name="'.$nameString.'" id="'.$nameString.'" ';
          if($isRequired){                                          //if select should be <required>, append tag to select
            $selectString.= "required";
          }
    $selectString.= "onchange='".$selectOnchange."'";
    $selectString.= '>';
    $selectString.= "<option selected disabled value=''>-select your concern-</option>";
    foreach ($valueArray as $key => $value){
          $selectString .='<option value="';                        //start of option
          $selectString .=$key.'" ';                                //value of option
          $selectString .='data-option-description="'.$value.'" ';  //append option details as an extraneous property
          if($storedValue == $key){                                 //check for equality between option value and stored value
             $selectString.="selected";}                            //if equal, add 'selected' property to option
          if($key == ""){                                           //this block checks if given value is empty and fills it in with a general 'no x selected' string if it is
              $selectString.='>none</option>';}                     //null-value fields are expressed as 'none'
              //$selectString.='>No '.$fieldString.' selected</option>';}   //null-value fields are expressed as 'no xfield selected'
          else{
              $selectString.='>'.$key.'</option>';}                 //end of option      
    }
    $selectString.= '</select>';
    echo $selectString;
  }
  //----------------------------END OF FUNCTION TO OUTPUT A SPECIAL SELECT CONTROL-----------------------------//


//------------------FUNCTION FORMATS CHATLOG AND RETURNS HTML CODE FOR A CHATLOG <ELEMENT>------------------//
/*
parameter should generally look like this:
sender1<02/05/1991 22:00:00>: message -:-
sender2<02/05/1991 22:02:00>: message2

every time user sends a new message, update the string, adding 
  -:- sender3<02/05/1991 22:05:00>: message3
*/
function prepareChatlog($chatlog){
  $chatlogOut="";
  $class="";
  $chatArray = explode('-:-',$chatlog);         //splits $chatlog input into an array of chatlog lines via the -:- delimiter
  //print_r($chatArray);
  if(count($chatArray)>1){                      //if chatArray (and by extension chatlog) is not null, true
    for($i=0;$i<count($chatArray);$i++){        //each chatArray[i] is a line in the chatlog with a distinct user, datetime, message
      if(empty($chatArray[$i])){                //code block checks if current item is empty - if it is, ignore current item
        continue;
      }
      $step1 = explode('<',$chatArray[$i],2);   //splits the current chat log row into <user name> and < datetime>:message >
      $user = $step1[0];                        //part of the step1 array that contains the name of the poster
      $step2 = explode('>:',$step1[1],2);       //separates the step1 array into
      $datetime = $step2[0];                    //part of the step2 array that contains the date and time comment was posted
      $message = $step2[1];                     //part of the step2 array that contains the message
        if($user == checkUser()){               //code block determines if the message was sent by the user - if it was, apply style within "userMessage" CSS class - else, apply style within "nonUserMessage" CSS class
          $class = "userMessage";
        }
        else{
          $class = "nonUserMessage";
        }
      $chatlogOut.="
      <li class='clearfix'>
        <div class='message'>".$message."
          <div class='message-details'>
            <p>".$user.", ".$datetime."</p>
          </div>
        </div>
      </li>
      ";
    } 
  }
  else{
    $chatlogOut.="
      <li class='clearfix'>
        <div class='message'>"."Nothing to display"."
          <div class='message-details'>
          </div>
        </div>
      </li>
      ";
  }
  return $chatlogOut;
}
//-------------END OF FUNCTION THAT FORMATS CHATLOG AND RETURNS HTML CODE FOR A CHATLOG <DIV>-------------//

function escapeString($inputString){//escapes a given string with respect to $conn
  global $conn;
  $outputString = mysqli_real_escape_string ($conn,$inputString);
  return $outputString;
}

function constructDisplay($label, $displayValue){//creates a design-formatted output box
  echo "
  <div class='form-group'>
      <label>$label</label>
      <textarea class='form-control' value='$displayValue' placeholder='$displayValue' style='height: 40px;' disabled></textarea>
  </div>
  ";
}


function createHiddenInput($name, $value){//creates a hidden input with a given name and value - mostly unnecessary but expedites the process
  echo "
  <input type='hidden' name='$name' value='$value'>
  ";
}

//------------------FUNCTION QUERIES TICKETS AND RETURNS ARRAY OF VALUES WITH A GIVEN STATUS------------------//
function getTickets($ticketStatus){
  global $conn;
  $ticketQuery = "
  SELECT ticket_id
  FROM tickets 
  WHERE job_status = '".$ticketStatus."'
  ";    
  if($ticketResult = mysqli_query($conn,$ticketQuery)){
    $values = array();
    $rowCount = mysqli_num_rows($ticketResult);
    if($rowCount==0){      
      return false;
    }
    while($ticketRes = mysqli_fetch_array($ticketResult)){
      array_push($values, $ticketRes['ticket_id']);
    }
    return $values;
  }
  else{
    return false;
  }
}
//-------------END OF FUNCTION THAT QUERIES TICKETS AND RETURNS ARRAY OF VALUES WITH A GIVEN STATUS-------------//

//----------------FUNCTION THAT PRINTS THE CONTENTS OF A NUMERIC ARRAY AS <LI> ELEMENTS----------------//
function printTickets($valueArray){  
    if($valueArray){
      foreach ($valueArray as $value)
      {
           echo "<li><a href='viewticket.php?ticket_id=".$value."'>".$value."</a></li>";
      }
    }
    else{
           //echo "<li><span style='color:white'>No Tickets</span></li>";
    }
}
//-------------END OF FUNCTION THAT PRINTS THE CONTENTS OF A NUMERIC ARRAY AS <LI> ELEMENTS-------------//

//-------------FUNCTION CHECKS IF CURRENTLY LOGGED-IN USER HAS AN ACTIVE TICKET-------------//
function checkCurrentTicket(){
  global $conn;
  $retrieveTicketQueryString = "SELECT * FROM tech_credentials WHERE employee_name = '".$_SESSION['client_name']."'";
    $retrieveTicket = mysqli_query($conn, $retrieveTicketQueryString);
            if(!$retrieveTicket || mysqli_num_rows($retrieveTicket)==0) {//IF USER DOES NOT EXIST, EXECUTE THIS CLAUSE - THERE SHOULD NEVER BE ANY NEED TO RUN THIS CLAUSE -> IF THIS CLAUSE RUNS, THERE IS A MAJOR ERROR ELSEWHERE
              toConsole("USER DOES NOT EXIST!");
            }
            else{//USER EXISTS, EXECUTE THIS CLAUSE
              while($retrieveRes=mysqli_fetch_array($retrieveTicket)){//RETRIEVE USER DATA       
                  if($retrieveRes['current_ticket']==null || $retrieveRes['current_ticket']==''){//user has no active ticket
                    return false;
                  }
                  else{//user has an active ticket
                    return $retrieveRes['current_ticket'];
                  }
              }
            } 
}
//---------END OF FUNCTION THAT CHECKS IF CURRENTLY LOGGED-IN USER HAS AN ACTIVE TICKET--------//

//--------FUNCTION THAT USES ECHOED JAVASCRIPT TO HIDE AN HTML ELEMENT WITH THE GIVEN ID--------//
function hideElement($element_id){
  echo "<script>";
  echo "document.getElementById('".$element_id."').style.display='none';";
  echo "</script>";
}
//----END OF FUNCTION THAT USES ECHOED JAVASCRIPT TO HIDE AN HTML ELEMENT WITH THE GIVEN ID-----//

//--------FUNCTION THAT USES ECHOED JAVASCRIPT TO SHOW AN HTML ELEMENT WITH THE GIVEN ID--------//
function showElement($element_id){
  echo "<script>";
  echo "document.getElementById('".$element_id."').style.display='block';";
  echo "</script>";
}
//----END OF FUNCTION THAT USES ECHOED JAVASCRIPT TO SHOW AN HTML ELEMENT WITH THE GIVEN ID-----//

//--------FUNCTION THAT UPDATES A WHICH TICKET IS ASSIGNED TO A TECH--------//
function updateTechTicket($tech_id, $ticket_id){
  global $conn;
  $outString = "UPDATE tech_credentials SET current_ticket = '".$ticket_id."' WHERE employee_name='".$tech_id."'";
  toConsole("Assigning ticket to tech");
  toConsole(addslashes($outString));
  if (mysqli_query($conn, $outString)) {
      } else {
          checkSQLError();//query fails, echo error
      }          
}
//-----END OF FUNCTION THAT UPDATES A WHICH TICKET IS ASSIGNED TO A TECH----//


//-----FUNCTION THAT OUTPUTS A SPECIFICALLY FORMATTED SET OF <li> CONTROLS-----//
function printArrayWithX($list,$type){
  if($list){
	  foreach($list as $key => $value){
	    echo "
	    <li class='list-group-item d-flex justify-content-between align-items-center' ";//start of <li>
	    echo "
	      data-entity-type='".$type."'      
	      data-part-name='".$key."'
	      data-part-details='".$value."'
	    ";
	    echo ">".$key." - ".$value;
	    $argumentString=(("'$type','$key','$value'"));
	    echo '
	        <span>
	          <button class="close" data-toggle="modal" data-target="#deletePartSpec" 
	          onclick="setModalValues('.$argumentString.')">&times;</button>
	        </span>
	    </li>';//end of <li>
  	  }
  }
  else{
  	echo "<li class='list-group-item d-flex justify-content-between align-items-center'>Nothing to display.</li>";
  }
}
//-----END OF FUNCTION THAT OUTPUTS A SPECIFICALLY FORMATTED SET OF <li> CONTROLS-----//

//-----FUNCTION THAT RETURNS THE URL OF CURRENT PAGE-----//
function getUrl($qStringToggle){
  if(strtoupper($qStringToggle) == "FULL"){//if parameter is 'FULL', returns full address (base url+ query string)
    return (basename($_SERVER['PHP_SELF'])."?".$_SERVER['QUERY_STRING']);
  }
  else if(strtoupper($qStringToggle) == "BASE"){//if parameter is 'BASE', returns base address (base url without query string)
    return (basename($_SERVER['PHP_SELF']));
  }
  elseif(strtoupper($qStringToggle) == "QUERY"){//if parameter is 'QUERY', returns query string
    return ($_SERVER['QUERY_STRING']);
  }
  else{
    return null;
  }
}
//-----END OF FUNCTION THAT RETURNS THE URL OF CURRENT PAGE-----//

//-----FUNCTION THAT RETURNS THE username OF LOGGED-IN USER, RETURNS FALSE IF NO USER IS LOGGED IN-----// 
function callUsername(){
  if(isset($_SESSION["username"]) && $_SESSION["username"]!=''){
    return $_SESSION["username"];    
  }
  else{
    return false; 
  }
}
//-----END OF FUNCTION THAT RETURNS THE username OF LOGGED-IN USER, RETURNS FALSE IF NO USER IS LOGGED IN-----//

//-----FUNCTION THAT SHOULD RETURN AN ASSOCIATIVE ARRAY CONTAINING THE TECH'S DETAILS-----//
function getTechDetails($username){
  global $conn;
  $retrieveTechDetailsQuery = "SELECT * FROM tech_credentials WHERE username = '".$username."'";
    $retrieveTech = mysqli_query($conn, $retrieveTechDetailsQuery);
            if(!$retrieveTech || mysqli_num_rows($retrieveTech)==0) {//IF USER DOES NOT EXIST, EXECUTE THIS CLAUSE - THERE SHOULD NEVER BE ANY NEED TO RUN THIS CLAUSE -> IF THIS CLAUSE RUNS, THERE IS A MAJOR ERROR ELSEWHERE
              print "USER DOES NOT EXIST!";
            }
            else{//USER EXISTS, EXECUTE THIS CLAUSE
              $retrieveRes=mysqli_fetch_array($retrieveTech,MYSQLI_ASSOC);
              return $retrieveRes;
            } 
}
//-----END OF FUNCTION THAT SHOULD RETURN AN ASSOCIATIVE ARRAY CONTAINING THE TECH'S DETAILS-----//


//-----FUNCTION THAT RETURNS AN ASSOCIATIVE ARRAY CONTAINING ALL OF A TICKET'S DETAILS-----//
function getTicketDetails($ticket_id){
  global $conn;
  $query = "
  SELECT *
  FROM tickets 
  WHERE ticket_id='".$ticket_id."'
  "; 
  if($queryResult = mysqli_query($conn,$query)){
    while($optionRes = mysqli_fetch_array($queryResult,MYSQLI_ASSOC)){
      return $optionRes;
    }
  }
}
//-----END OF FUNCTION THAT RETURNS AN ASSOCIATIVE ARRAY CONTAINING ALL OF A TICKET'S DETAILS-----//


//-----FUNCTION THAT RETURNS DETAILS OF THE DEVICE WITH A device_id OF $device_id-----//
function getDeviceDetails($device_id){
    global $conn;
    $deviceQuery = "SELECT owner, office FROM device_list WHERE device_id='$device_id'";
    if($deviceResult = mysqli_query($conn, $deviceQuery)){
            if(!$deviceResult || mysqli_num_rows($deviceResult)==0) {//device does not exist
              print "DEVICE DOES NOT EXIST!";
              return false;
            }
            else{//USER EXISTS, EXECUTE THIS CLAUSE
              $deviceRes=mysqli_fetch_array($deviceResult,MYSQLI_ASSOC);
              return $deviceRes;
            } 
    }
    else{
        return false;        
    }
}
//-----END OF FUNCTION THAT RETURNS DETAILS OF THE DEVICE WITH A device_id OF $device_id-----//



//---------FUNCTION THAT TAKES A TICKET ID AND RETURNS A FORMATTED TICKET ID FOR ITS NEXT ITERATION---------//
function getEscalatedId($ticket_id){
    $escalation_index = substr(strrchr($ticket_id,'-'),1);
    if(ctype_alpha($escalation_index)){//ESCALATION INDEX PRESENT (e.g. 190506-001-/A/)
        return substr($ticket_id,0,10)."-".++$escalation_index;
    }
    else{//NO ESCALATION INDEX (e.g. 190506-001)
        return $ticket_id."-A";
    }
}
//---------END OF FUNCTION THAT TAKES A TICKET ID AND RETURNS A FORMATTED TICKET ID FOR ITS NEXT ITERATION---------//

//-----------FUNCTION USED TO CHECK IF TICKET HAS AN ESCALATION INDEX--------------//
function hasBeenEscalated($ticket_id){
    $escalation_index = substr(strrchr($ticket_id,'-'),1);
    if(ctype_alpha($escalation_index)){//ESCALATION INDEX PRESENT (e.g. 190506-001-/A/)
        return true;
    }
    else{//NO ESCALATION INDEX (e.g. 190506-001)
        return false;
    }
}
//-----------END OF FUNCTION USED TO CHECK IF TICKET HAS AN ESCALATION INDEX--------------//

//--------FUNCTION CHECKS FOR AND RETURNS ID OF TECH'S SUSPENDED TICKET--------//
function checkSuspendedTicket($tech_username){
  $tech_details = getTechDetails($tech_username);
  if($tech_details['suspended_ticket']){
    return $tech_details['suspended_ticket'];
  }
  else{
    return false;
  }
}
//--------END OF FUNCTION THAT CHECKS FOR AND RETURNS ID OF TECH'S SUSPENDED TICKET--------//

//---------FUNCTION TO OUTPUT A PANEL TITLE----------//
function outputTitle($title){
  echo "<center><br><legend class='headerStyle'>";
  echo $title;
  echo '</legend></center>';
}
//-------END OF FUNCTION TO OUTPUT A PANEL TITLE-----//

//-------FUCNTION TO SUSPEND A TECH'S TICKET-------//
function suspendTicket($techUsername){
  global $conn;
  $techDetails = getTechDetails($techUsername);
  $techQueryString = "UPDATE tech_credentials SET suspended_ticket='".$techDetails['current_ticket']."', current_ticket=NULL WHERE username='".$techUsername."'";//query updates tech_credentials
  if (mysqli_query($conn, $techQueryString)) { //query passes
    return true;
  } 
  else {//query fails
      //echo '<script>console.log("Error - '.mysqli_error($conn).'");</script>';
      //echo "<script>console.log('Bad Query - ".$techQueryString."')</script>";
    sendAlert("Bad Query.\nQuery - $techQueryString\nError - ".addslashes(mysqli_error($conn)));
    return false;
  }
}
//-----END OF FUNCTION TO SUSPEND A TECH'S TICKET---//

//-------FUNCTION TO DROP A TECH'S TICKET-------//
function dropTicket($techUsername){
  global $conn;
  $techQueryString = "UPDATE tech_credentials SET current_ticket=NULL WHERE username='".$techUsername."'";//query updates tech_credentials
  if (mysqli_query($conn, $techQueryString)) { //query passes
    return true;
  } 
  else {    //report sql error
      //echo '<script>console.log("Check 2 - '.mysqli_error($conn).'");</script>';
      //echo "<script>console.log('".$techQueryString."')</script>";
    sendAlert("Bad Query.\nQuery - $techQueryString\nError - ".addslashes(mysqli_error($conn)));
    return false;
  }
}
//----END OF FUNCTION TO DROP A TECH'S TICKET----//

//-------FUNCTION TO DROP A TECH'S TICKET-------//
function dropSuspendedTicket($techUsername){
  global $conn;
  $techQueryString = "UPDATE tech_credentials SET suspended_ticket=NULL WHERE username='".$techUsername."'";//query updates tech_credentials
  if (mysqli_query($conn, $techQueryString)) { //query passes
    return true;
  } 
  else {    //report sql error
      //echo '<script>console.log("Check 2 - '.mysqli_error($conn).'");</script>';
      //echo "<script>console.log('".$techQueryString."')</script>";
    sendAlert("Bad Query.\nQuery - $techQueryString\nError - ".addslashes(mysqli_error($conn)));
    return false;
  }
}
//----END OF FUNCTION TO DROP A TECH'S TICKET----//

//------FUNCTION TO SEND AN ALERT-------//
function sendAlert($alertMessage){
  $alertMessage=addslashes($alertMessage);
  echo "
    <script>
    alert('$alertMessage');
    </script>
  ";
}
//---END OF FUNCTION TO SEND AN ALERT---//


//-----FUNCTION TO RETRIEVE A TICKET'S HISTORY - RETURNS A <ul> CONTAINING LINKS TO PREVIOUS ITERATIONS OF THE TICKET, AS WELL AS INFORMATION AS TO WHO ESCALATED THE TICKET-----//
function getTicketHistory($ticket_id){
  global $conn;

  //below code block checks if ticket has an escalation index and returns only the base ticket_id if it does
    $ticket_memory = $ticket_id;
    $ticket_hold = $ticket_id;
    $ticket_memory = substr(strrchr($ticket_id,'-'),1);
    $hasBeenEscalated = false;
    if(ctype_alpha($ticket_memory)){//ESCALATION INDEX PRESENT (e.g. 190506-001-/A/)
      $ticket_id=substr($ticket_hold,0,10);
      $hasBeenEscalated = true;
    }

  $selectQuery = "SELECT * FROM tickets WHERE ticket_id LIKE '$ticket_id%'";
  //print($selectQuery);
  if ($selectResult=mysqli_query($conn, $selectQuery)) {//query passes, tickets retrieved
      $rowcount=mysqli_num_rows($selectResult);
      echo "<ul>";
      //toConsole("row count: ".$rowcount);
      if($rowcount){
        $techHolder='';
        while($res=mysqli_fetch_array($selectResult)){//while there are tickets to display
            /*if($res['ticket_id']==$ticket_hold){ 
              //do nothing
            }*/
              echo "<li>";
              $techHolder='';
              if (is_numeric(substr($res['ticket_id'],-1,1))) {
                echo "=>Ticket <a href='viewticket.php?ticket_id=".$res['ticket_id']."'>".$res['ticket_id']."</a> created by ".$res['client_name']." on ".$res['date_created'];
                $techHolder=$res['respondent'];
              }
              else{
                echo "=>Ticket <a href='viewticket.php?ticket_id=".$res['ticket_id']."'>".$res['ticket_id']."</a> escalated on ".$res['date_created'];
              }
              echo "</li>";
              if($res['date_accepted']){
                echo "<ul><li>";
                  echo "=>>Ticket <a href='viewticket.php?ticket_id=".$res['ticket_id']."'>".$res['ticket_id']."</a> accepted by ".$res['respondent']." on ".$res['date_accepted'];
                echo "</li>";
                if($res['date_fulfilled'] && $res['job_status']=='Closed'){
                  //echo "<ul><li>";
                  echo "<li>";
                    echo "=>>Ticket <a href='viewticket.php?ticket_id=".$res['ticket_id']."'>".$res['ticket_id']."</a> completed by ".$res['respondent']." on ".$res['date_fulfilled'];
                  echo "</li></ul>";
                }
                else{
                  echo "</ul>";
                }
              }
              
        }
      }
      else{
        echo "<li>Nothing to display.</li>";
      }
      echo "</ul>";
  }
  else{//query fails or returns a falsy value, nothing to display
    echo "<ul><li>Nothing to display.</li></ul>";
  }
}
//-----END OF FUNCTION TO RETRIEVE A TICKET'S HISTORY-----//

//-----FUNCTION THAT RETRIEVES UNIQUE VALUES FOR <field> IN <field_values>----->
function retrieveUniqueFields(){
  global $conn;
  $selectQuery="SELECT DISTINCT field FROM field_values";
  if ($selectResult=mysqli_query($conn, $selectQuery)) {//query passes, tickets retrieved
    $values = array();
        while($res=mysqli_fetch_array($selectResult)){//while there are tickets to display
            array_push($values,$res['field']);
        }
    return $values;
  }
  else{//query fails or returns a falsy value, nothing to display
    return false;
  }
}
//-----END OF FUNCTION THAT RETRIEVES UNIQUE VALUES FOR <field> IN <field_values>----->


//-----SHORT FUNCTION THAT REMOVES UNDERSCORES FROM A STRING AND CAPITALIZES ALL FIRST LETTERS------//
function formatString($rawString){
  if($output = ucwords(str_replace('_',' ',$rawString))){
    return $output;
  }
  else{
    return false;
  }
}
//--END OF SHORT FUNCTION THAT REMOVES UNDERSCORES FROM A STRING AND CAPITALIZES ALL FIRST LETTERS--//

//----FUNCTION TO RETRIEVE A DEVICE'S CHANGELOG----//
function getDeviceChangeLog($device_id){
  global $conn;
  $logQuery="SELECT * FROM device_changelog WHERE device_id='$device_id'";
  if ($logResult=mysqli_query($conn, $logQuery)) {//query passes, logs retrieved
      echo "<ul>";
      $rowcount=mysqli_num_rows($logResult);
      if($rowcount){
        while($res=mysqli_fetch_array($logResult)){//while there are logs to display
          $admin=$res['admin'];
          $date_time_logged=$res['date_time_logged'];
          $change_made=$res['change_made'];
          echo "<li>";
            echo "$admin ($date_time_logged): $change_made";
          echo "</li>";
        }
      }
      else{
        echo "<li>Nothing to display.</li>";
      }
      echo "</ul>";
  }
}
//----END OF FUNCTION TO RETRIEVE A DEVICE'S CHANGELOG----//


//----FUNCTION TO RETRIEVE A DEVICE'S SERVICE HISTORY----//
function getDeviceHistory($device_id){
  global $conn;
  if(!$device_id){
    echo "<ul><li>Nothing to display.</li></ul>";
    return false;
  }
  global $conn;
  $historyQuery="SELECT * FROM tickets WHERE (device_id='$device_id' AND date_fulfilled IS NOT NULL)";
  //echo $historyQuery;
  if ($historyResult=mysqli_query($conn, $historyQuery)) {//query passes, logs retrieved
      echo "<ul>";
      $rowcount=mysqli_num_rows($historyResult);
      if($rowcount){
        while($res=mysqli_fetch_array($historyResult)){//while there are logs to display
          $ticket_id=$res['ticket_id'];
          $respondent=$res['respondent'];
          $date_fulfilled=$res['date_fulfilled'];
          $job_description=$res['job_description'];
          $job_details=$res['job_details'];
          echo "<li>";
            echo "Ticket <a href='viewticket.php?ticket_id=$ticket_id'>$ticket_id</a> | $respondent ($date_fulfilled): $job_description - $job_details";
          echo "</li>";
        }
      }
      else{
        echo "<li>Nothing to display.</li>";
      }
      echo "</ul>";
  }
}
//----END OF FUNCTION TO RETRIEVE A DEVICE'S SERVICE HISTORY----//

//-----FUNCTION TO CHECK IF TICKET BELONGS TO ANY TECH-----//
function checkTicketOwner($ticket_id){
  global $conn;
  $checkQuery = "SELECT * FROM tech_credentials WHERE (current_ticket = '$ticket_id' OR suspended_ticket = '$ticket_id')";
  if($checkResult = mysqli_query($conn,$checkQuery)){
    $rowcount=mysqli_num_rows($checkResult);
    if($rowcount){
      $checkRes=mysqli_fetch_array($checkResult);
      return $checkRes['username'];
    }
    else{
      return false;
    }
  }
  else{
    checkSQLError();
  }
}
//-----END OF FUNCTION TO CHECK IF TICKET BELONGS TO ANY TECH-----//

//------FUNCTION THAT CHECKS IF PROVIDED USERNAME IS NOT YET IN tech_credentials AND IS THUS AVAILABLE------//
function usernameIsAvailable($username){
  global $conn;
  $usernameQuery = "SELECT username FROM tech_credentials WHERE username='$username'";
  $usernameResult = mysqli_query($conn,$usernameQuery);
  if(!mysqli_num_rows($usernameResult)){
    return true;//username has not been registered yet
  }
  else{
    return false;//username has already been registered
  }
}
//------FUNCTION THAT CHECKS IF PROVIDED USERNAME IS NOT YET IN tech_credentials AND IS THUS AVAILABLE------//


//------FUNCTION THAT CHECKS IF PROVIDED NAME IS NOT YET IN tech_credentials AND IS THUS AVAILABLE------//
function nameIsAvailable($name){
  global $conn;
  $nameQuery = "SELECT username FROM tech_credentials WHERE employee_name='$name'";
  $nameResult = mysqli_query($conn,$nameQuery);
  if(!mysqli_num_rows($nameResult)){
    return true;//name has not been registered yet
  }
  else{
    return false;//name has already been registered
  }
}
//------FUNCTION THAT CHECKS IF PROVIDED NAME IS NOT YET IN tech_credentials AND IS THUS AVAILABLE------//

//-------FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//
  function outputHeadRow($leftElement){
    $leftElement = strtoupper(formatString($leftElement));
    echo "<tr style='font-weight: bold;'>";
    echo "<td>$leftElement</td>";
    for($month=1; $month<=12; ++$month){
        echo "<td>".strtoupper(date('M', mktime(0, 0, 0, $month, 1))).'</td>';
        if($month==6) echo "<td>1ST SEM</td>";
        else if($month==12){
          echo "<td>2ND SEM</td>";
          echo "<td>TOTAL</td>";  
        } 
    }
    echo "</tr>";    
  }
//-------END OF FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//


//-------FUNCTION THAT RETURNS THE NUMBER OF DEVICES REGISTERED TO A DEPARTMENT-------//  
  function getDeviceCount($office){
    global $conn;
    $selectQuery = "
      SELECT COUNT(*) as count
      FROM device_list
      WHERE office='$office'
    ";
    if($result = mysqli_query($conn, $selectQuery)){
      if(mysqli_num_rows($result)>0){
        $res = mysqli_fetch_array($result);
        return $res['count'];
      }
      else return false;
    }
    else return false;
  }
//-------END OF FUNCTION THAT RETURNS THE NUMBER OF DEVICES REGISTERED TO A DEPARTMENT-------// 

//-------FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//
  function outputDataRow($fieldTarget,$targetTable,$name,$start,$end){
    global $conn;
    $lefthandFields=retrieveOptionsNum($fieldTarget,false);
    foreach($lefthandFields as $field){
        $targetTable = "tickets";
        $queryField = $field;
        $fieldDisplay = formatString($field);       
            echo "<tr style='align:right;'>";
            echo "<td style='align:left;'>$fieldDisplay</td>";

            $dataArray = array();
            $dataQuery = "SELECT 
                            COUNT(*) AS count, 
                            MONTH(date_fulfilled) AS month 
                          FROM $targetTable 
                          WHERE (datediff(date_fulfilled,'$start') >= 0
                            AND datediff(date_fulfilled,'$end') <= 0 
                            AND $fieldTarget='$field' 
                            AND admin='$name') 
                          GROUP BY MONTH(date_fulfilled)";
            //print($dataQuery);
            //toConsole(addslashes($dataQuery));
            checkSQLError();
            if($dataResult = mysqli_query($conn, $dataQuery)){
              if($rowCount = mysqli_num_rows($dataResult)){
                while($dataRes = mysqli_fetch_array($dataResult)){
                  $dataArray[$dataRes['month']]=$dataRes['count'];
                }
              }
            }
            //print_r($dataArray);

            for($month=1; $month<=12; ++$month){
              if(isset($dataArray[$month])){
                echo "<td>".$dataArray[$month]."</td>";
              }
              else{
                $dataArray[$month]=0;
                echo "<td>".$dataArray[$month]."</td>";
              }
                if($month==6){
                  $semTotal=0;
                  for($counter=1;$counter<7;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                } 
                else if($month==12){
                  $semTotal=0;
                  for($counter=7;$counter<13;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                  $yearTotal=0;
                  for($counter=1;$counter<13;$counter++){
                    $yearTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center;'>$yearTotal</td>";
                }
            }
            echo "</tr>";
      }
  }
//-------END OF FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//

//-------FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//
  function outputTechDataRow($name,$start,$end){
    global $conn;
        $targetTable = "tickets";
        $fieldDisplay = formatString($name);       
            echo "<tr style='align:right;'>";
            echo "<td style='align:left;'>$fieldDisplay</td>";
            $dataArray = array();
            $dataQuery = "
                          SELECT 
                            COUNT(*) AS count, 
                            MONTH(date_fulfilled) AS month 
                          FROM $targetTable 
                          WHERE datediff(date_fulfilled,'$start') >= 0
                            AND datediff(date_fulfilled,'$end') <= 0 
                            AND respondent='$name'
                          GROUP BY MONTH(date_fulfilled)";
            //print($dataQuery);
            echo "<!--DATA QUERY - $dataQuery-->";
            if($dataResult = mysqli_query($conn, $dataQuery)){
              if($rowCount = mysqli_num_rows($dataResult)){
                while($dataRes = mysqli_fetch_array($dataResult)){
                  $dataArray[$dataRes['month']]=$dataRes['count'];
                }
              }
            }
            //print_r($dataArray);

            for($month=1; $month<=12; ++$month){
              if(isset($dataArray[$month])){
                echo "<td>".$dataArray[$month]."</td>";
              }
              else{
                $dataArray[$month]=0;
                echo "<td>".$dataArray[$month]."</td>";
              }
                if($month==6){
                  $semTotal=0;
                  for($counter=1;$counter<7;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                } 
                else if($month==12){
                  $semTotal=0;
                  for($counter=7;$counter<13;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                  $yearTotal=0;
                  for($counter=1;$counter<13;$counter++){
                    $yearTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center;'>$yearTotal</td>";
                }
            }
            echo "</tr>";
  }
//-------END OF FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//

//-------FUNCTION TO OUTPUT A <tr> CONTAINING COUNT OF TECH'S ESCALATIONS PER MONTH---------//
  function outputEscalationCount($name,$start,$end){
    global $conn;
        $targetTable = "tickets";
        $fieldDisplay = formatString($name);       
            echo "<tr style='align:right;'>";
            echo "<td style='align:left;'>$fieldDisplay</td>";
            $dataArray = array();
            $dataQuery = "
                          SELECT 
                            COUNT(*) AS count, 
                            MONTH(date_fulfilled) AS month 
                          FROM $targetTable 
                          WHERE datediff(date_fulfilled,'$start') >= 0
                            AND datediff(date_fulfilled,'$end') <= 0 
                            AND respondent='$name'
                            AND job_status='Unresolved - Escalated'
                          GROUP BY MONTH(date_fulfilled)";
            //print($dataQuery);
            echo "<!--DATA QUERY - $dataQuery-->";
            if($dataResult = mysqli_query($conn, $dataQuery)){
              if($rowCount = mysqli_num_rows($dataResult)){
                while($dataRes = mysqli_fetch_array($dataResult)){
                  $dataArray[$dataRes['month']]=$dataRes['count'];
                }
              }
            }
            //print_r($dataArray);

            for($month=1; $month<=12; ++$month){
              if(isset($dataArray[$month])){
                echo "<td>".$dataArray[$month]."</td>";
              }
              else{
                $dataArray[$month]=0;
                echo "<td>".$dataArray[$month]."</td>";
              }
                if($month==6){
                  $semTotal=0;
                  for($counter=1;$counter<7;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                } 
                else if($month==12){
                  $semTotal=0;
                  for($counter=7;$counter<13;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                  $yearTotal=0;
                  for($counter=1;$counter<13;$counter++){
                    $yearTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center;'>$yearTotal</td>";
                }
            }
            echo "</tr>";
  }
//-------END OF FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//

//-------FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//
  function outputTechTimeDataRow($tech_name,$start,$end,$type){
    global $conn;
        $fieldDisplay = formatString($tech_name);       
            echo "<tr style='align:right;'>";
            echo "<td style='align:left;'>$fieldDisplay</td>";
            $dataArray = array();

            for($month=1; $month<=12; ++$month){
              //$dataArray[$month]=getAverageTimeElapsed($tech_name, $month, $year);
              echo "<td>";
              getAverageTimeElapsed($tech_name, $month, $start,$end,$type);
              echo "</td>";
              /*if(($dataArray[$month])){
                echo "<td>".$dataArray[$month]."</td>";
              }
              else{
                echo "<td>"."00:00:00"."</td>";
              }*/
              if($month==6){
                echo "<td>";
                  getAverageTimeElapsedSem($tech_name, "1st", $start,$end,$type);
                echo "</td>";
              } 
              else if($month==12){
                echo "<td>";
                  getAverageTimeElapsedSem($tech_name, "2nd", $start,$end,$type);
                echo "</td>";

                echo "<td>";
                  getAverageTimeElapsedSem($tech_name, "Total", $start,$end,$type);
                echo "</td>";
              }
            }
            echo "</tr>";
  }
//-------END OF FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//



//-------FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//
  function outputGeneralDataRow($name,$start,$end,$targetTable,$targetField,$targetValue){
    global $conn;
        $fieldDisplay = formatString($name);       
            echo "<tr style='align:right;'>";
            echo "<td style='align:left;'>$fieldDisplay</td>";
            $dataArray = array();
            $dataQuery = "
              SELECT COUNT(*) AS count, 
                MONTH(date_fulfilled) AS month 
              FROM $targetTable 
              WHERE datediff(date_fulfilled,'$start') >= 0
                AND datediff(date_fulfilled,'$end') <= 0 
                AND $targetField='$targetValue'
              GROUP BY MONTH(date_fulfilled)";
            //print($dataQuery);
            echo "<!--General Data ($name): $dataQuery-->";
            if($dataResult = mysqli_query($conn, $dataQuery)){
              if($rowCount = mysqli_num_rows($dataResult)){
                while($dataRes = mysqli_fetch_array($dataResult)){
                  $dataArray[$dataRes['month']]=$dataRes['count'];
                }
              }
            }
            //print_r($dataQuery);

            for($month=1; $month<=12; ++$month){
              if(isset($dataArray[$month])){
                echo "<td>".$dataArray[$month]."</td>";
              }
              else{
                $dataArray[$month]=0;
                echo "<td>".$dataArray[$month]."</td>";
              }
                if($month==6){
                  $semTotal=0;
                  for($counter=1;$counter<7;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                } 
                else if($month==12){
                  $semTotal=0;
                  for($counter=7;$counter<13;$counter++){
                    $semTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center'>$semTotal</td>";
                  $yearTotal=0;
                  for($counter=1;$counter<13;$counter++){
                    $yearTotal+=$dataArray[$counter];
                  }
                  echo "<td style='text-align:center;'>$yearTotal</td>";
                }
            }
            echo "</tr>";
  }
//-------END OF FUNCTION TO OUTPUT A <tr> CONTAINING <td>'s REPRESENTING MONTHS AND SEMESTERS---------//



//------FUNCTION THAT RETURNS AN ARRAY OF EMPLOYEES------//
function retrieveEmployees($user_type,$sortToggle){//retrieves of all employees with position of $user_type - if sortToggle is true, sort array alphabetically
  global $conn;
  if($user_type=='tech'){
    $optionQuery = "
    SELECT employee_name, username 
    FROM tech_credentials 
    WHERE 
      (user_type = 'tech' 
      OR user_type = 'intern')
      AND status = 'active'
    "; 
  }
  else{
    $optionQuery = "
    SELECT employee_name, username 
    FROM tech_credentials 
    WHERE user_type = '$user_type'
      AND status = 'active'
    ";    
  } 

  if($sortToggle){
    $optionQuery .= " ORDER BY employee_name";
  }
  if($optionResult = mysqli_query($conn,$optionQuery)){
    $values = array();
    while($optionRes = mysqli_fetch_array($optionResult)){
      $key=$optionRes['employee_name'];
      $value=$optionRes['username'];
      $values[$key]=$value;
    }
    return $values;//uncomment this 
  }
  else{
    return false;//and this if function should only return an associative array where (employee_name=>current_ticket)
  }
}
//------FUNCTION THAT RETURNS AN ARRAY OF EMPLOYEES------//


//------FUNCTION TAKES TECH NAME AND RETURNS TECH'S USERNAME------//
function getTechUsername($techName){
  global $conn;
  $usernameQuery="SELECT username FROM tech_credentials WHERE employee_name='$techName'";
  if($usernameResult=mysqli_query($conn,$usernameQuery)){
    $rowCounter=mysqli_num_rows($usernameResult);
    if($rowCounter){
      $usernameRes = mysqli_fetch_array($usernameResult);
      return $usernameRes['username'];
    }
  }
  else{
    return false;
  }
}
//------END OF FUNCTION THAT TAKES TECH NAME AND RETURNS TECH'S USERNAME------//

/*
function ticketExists($ticket_id){
  global $conn;
  $checkQuery = "SELECT * FROM tickets WHERE ticket_id='$ticket_id'";
  if($checkResult=mysqli_query($conn,$checkQuery)){
    $rowCounter=mysqli_num_rows($checkResult);
    if($rowCounter){
      return true;
    }
  }
  else{
    return false;
  }
}*/


//-----FUNCTION THAT OUTPUTS A SPECIFICALLY FORMATTED SET OF <li> CONTROLS-----//
function printFieldValueButtons($list,$type){
  foreach($list as $key => $value){
    echo "
    <li class='list-group-item d-flex justify-content-between align-items-center' ";//start of <li>
    echo "
      data-entity-type='".$type."'      
      data-part-name='".$key."'
      data-part-details='".$value."'
    ";
    echo ">".$key." - ".$value;
    $argumentString=(("'$type','$key','$value'"));
    echo '
        <span>
          <button class="close" data-toggle="modal" data-target="#deletePartSpec" 
          onclick="setModalValues('.$argumentString.')">&times;</button>
        </span>
    </li>';//end of <li>
  }
}
//-----END OF FUNCTION THAT OUTPUTS A SPECIFICALLY FORMATTED SET OF <li> CONTROLS-----//

//--------FUNCTION THAT RETURNS THE AVERAGE time_elapsed OF A TECH IN A GIVEN MONTH OF A GIVEN YEAR-------//
function getAverageTimeElapsed($tech_name, $month, $start, $end, $type){ //month and year should both be numbers (1-12 and 2019 onward, respectively)
  global $conn;
  $averageQuery="";
  if($type=='assessment'){
    $averageQuery = "SELECT 
      AVG(TIMESTAMPDIFF(SECOND,date_accepted,date_assessed)) AS average_seconds";
  }  
  else if($type=='job'){//this part is likely failing due to integer-NULL data type errors
    $averageQuery = "SELECT 
      AVG(TIMESTAMPDIFF(SECOND,date_assessed,date_fulfilled)-COALESCE(TIMESTAMPDIFF(SECOND,date_suspended,date_resumed),0)) AS average_seconds";
  }

  $averageQuery.="
  FROM tickets 
  WHERE 
    MONTH(date_assessed)=$month 
    AND datediff(date_fulfilled,'$start') >= 0
    AND datediff(date_fulfilled,'$end') <= 0 
    AND date_assessed IS NOT NULL 
    AND date_accepted IS NOT NULL 
    AND respondent='$tech_name'";
  echo "<!--averageQuery : $averageQuery-->";
      if ($averageResult=mysqli_query($conn, $averageQuery)) { 
        $averageRes=mysqli_fetch_array($averageResult);
        //echo sprintf('%02d',($averageRes['average_seconds'])/3600 ).":".sprintf('%02d',($averageRes['average_seconds'])/60).":".sprintf('%02d',($averageRes['average_seconds'])%60);
        echo sprintf('%02d',($averageRes['average_seconds'])/60).":".sprintf('%02d',($averageRes['average_seconds'])%60);
      } 
      else{
        checkSQLError();
      }
}
//--------FUNCTION THAT RETURNS THE AVERAGE time_elapsed OF A TECH IN A GIVEN MONTH OF A GIVEN YEAR-------//



//--------FUNCTION THAT RETURNS THE AVERAGE time_elapsed OF A TECH IN EACH SEMESTER OF A GIVEN YEAR-------//
function getAverageTimeElapsedSem($tech_name, $semester, $start,$end,$type){ //month and year should both be numbers (1-12 and 2019 onward, respectively)
  global $conn;
  $averageQuery="";
  if($type=='assessment'){
    $averageQuery = "SELECT 
      AVG(TIMESTAMPDIFF(SECOND,date_accepted,date_assessed)) AS average_seconds";
  }  
  else if($type=='job'){//this part is likely failing due to integer-NULL data type errors
    $averageQuery = "SELECT 
      AVG(TIMESTAMPDIFF(SECOND,date_assessed,date_fulfilled)-COALESCE(TIMESTAMPDIFF(SECOND,date_suspended,date_resumed),0)) AS average_seconds";
  }

  if($semester == '1st'){
    $averageQuery .= "
    FROM tickets 
    WHERE 
      MONTH(date_assessed)<7 
      AND datediff(date_fulfilled,'$start') >= 0
      AND datediff(date_fulfilled,'$end') <= 0 
      AND date_assessed IS NOT NULL 
      AND date_accepted IS NOT NULL 
      AND respondent='$tech_name'";
  }
  else if($semester == '2nd'){
    $averageQuery .= "
    FROM tickets 
    WHERE 
      MONTH(date_assessed)<13
      AND MONTH(date_assessed)>6
      AND datediff(date_fulfilled,'$start') >= 0
      AND datediff(date_fulfilled,'$end') <= 0 
      AND date_assessed IS NOT NULL 
      AND date_accepted IS NOT NULL 
      AND respondent='$tech_name'";
  }
  else if($semester == 'Total'){
    $averageQuery .= "
    FROM tickets 
    WHERE 
      datediff(date_fulfilled,'$start') >= 0
      AND datediff(date_fulfilled,'$end') <= 0 
      AND date_assessed IS NOT NULL 
      AND date_accepted IS NOT NULL 
      AND respondent='$tech_name'";
  }

      if ($averageResult=mysqli_query($conn, $averageQuery)) { 
        //echo "<br>".(addslashes($averageQuery));
        $averageRes=mysqli_fetch_array($averageResult);
        //echo sprintf('%02d',($averageRes['average_seconds'])/3600 ).":".sprintf('%02d',($averageRes['average_seconds'])/60).":".sprintf('%02d',($averageRes['average_seconds'])%60);
        echo sprintf('%02d',($averageRes['average_seconds'])/60).":".sprintf('%02d',($averageRes['average_seconds'])%60);
      } 
      else{
        checkSQLError();
      }
}
//--------FUNCTION THAT RETURNS THE AVERAGE time_elapsed OF A TECH IN A GIVEN MONTH OF A GIVEN YEAR-------//


//--------FUNCTION THAT GENERATES A TABLE CONTAINING THE CHANGELOG NAMED &target----------//
function retrieveSelectedChangelog($target,$start,$end){

  global $conn;

  $tableHeadValues=retrieveFields($target);

  echo "<div id='$target' class='activeTableDiv'>";
  echo "<a onclick='exportF(this)' data-target='$target' class='btn btnField printHide'>Export to excel</a>
      <br><br>";
  echo "<table name='$target' id='$target' style='width:100%;'>";

  echo "<tr class='styleHeader'><td colspan='100%' style='text-align:center;'>".strtoupper(formatString($target))."</td></tr>";
  echo "<tr>";
  foreach($tableHeadValues as $value){
    echo "<th>$value</th>";
  }
  echo "</tr>";

  $tableBodyValuesQuery = "SELECT * FROM $target WHERE 
      datediff(date_time_logged,'$start') >= 0
      AND datediff(date_time_logged,'$end') <= 0 ";
  $result = mysqli_query($conn, $tableBodyValuesQuery);

  if(mysqli_num_rows($result)==0){//nothing to display
    echo "<tr><td colspan='100%' style='text-align:center;'>Nothing to display</td></tr>";
  }

  while($res = mysqli_fetch_array($result,MYSQLI_NUM)){
    echo "<tr>";
    foreach($res as $value){
      echo "<td>$value</td>";
    }
    echo "</tr>";
  }
  echo "</table></div>";
}
//--------END OF FUNCTION THAT GENERATES A TABLE CONTAINING THE CHANGELOG NAMED &target----------//


//------FUNCTION THAT RETURNS TRUE IF TICKET DENOTED BY ticket_id IS COMPLETED--------//
function isCompleted($ticket_id){
  $ticketDetails = getTicketDetails($ticket_id);
  if($ticketDetails['date_fulfilled']){
    return true;
  }
  else{
    return false;
  }
}
//------END OF FUNCTION THAT RETURNS TRUE IF TICKET DENOTED BY ticket_id IS COMPLETED--------//


//-------FUNCTION OUTPUTS SCRIPT THAT DISABLES A FORM-------//
//**functions like this output script to alter elements 
//**that have already been loaded into the DOM
//**it would probably be wise to restructure the program 
//**so it doesn't have to rely on clauses like this
//**that is, the program shouldn't load elements into the DOM
//**when loading them isn't necessary at all
function disableForm($formName){
  echo "
    <script>
        selectObjects = document.getElementById('$formName');
        elementList = selectObjects.elements;
        for(counter=0;counter<elementList.length;counter++){
          elementList[counter].disabled=true;
        }
        selectObjects.innerHTML+='<center>This form has been disabled.</center>';
    </script>
  ";
}
//-------END OF FUNCTION OUTPUTS SCRIPT THAT DISABLES A FORM-------//


//-------FUNCTION THAT CHECKS IF A TECH'S CURRENT AND SUSPENDED TICKETS ARE STILL VIABLE-------//
function checkLiveTickets(){
          $techUsername=callUsername();
          $techDetails=getTechDetails($techUsername);

          $current_ticket_details=getTicketDetails($techDetails['current_ticket']);
          $suspended_ticket_details=getTicketDetails($techDetails['suspended_ticket']);

          if($current_ticket_details['job_status']!='Ongoing'){
            dropTicket($techDetails['username']);
          }
          if($suspended_ticket_details['job_status']!='Ongoing'){
            dropSuspendedTicket($techDetails['username']);
          }
}
//-------END OF FUNCTION THAT CHECKS IF A TECH'S CURRENT AND SUSPENDED TICKETS ARE STILL VIABLE-------//


//-------FUNCTION THAT RETURNS A NUMERIC ARRAY OF OFFICES WITH REGISTERED DEVICES-------//
  function getOfficesWithDevices(){
    global $conn;
    $values = array();
    $selectQuery = "
        SELECT DISTINCT office as office
        FROM device_list
        ORDER BY office ASC";
    if($result = mysqli_query($conn, $selectQuery)){
      if(mysqli_num_rows($result)>0){
        while($res = mysqli_fetch_array($result)){
          array_push($values, $res['office']);
        }
        return $values;
      }
      else return false;
    }    
    else return false;
  }

//-------END OF FUNCTION THAT RETURNS A NUMERIC ARRAY OF OFFICES WITH REGISTERED DEVICES-------//


//-------FUNCTION THAT COMPLETES A TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//
function endTicket($ticket_id){//first check if item is still suspended and unfinished
  global $conn;
  $participation='Supervised';
  $admin=callUser();
  if(checkUserPrivilege()!='admin'){
    return false;
  }
  if(getRespondent($ticket_id)==callUser()){//ticket belongs to user
    $participation='Performed';
  }
  $updateQuery = "UPDATE tickets SET date_fulfilled=now(), job_status='Closed', participation='$participation', approval_status='Approved' , admin='$admin' WHERE ticket_id='$ticket_id'";
  if(mysqli_query($conn, $updateQuery)) return true;
  else return false;
}
//-------END OF FUNCTION THAT COMPLETES A TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//


//-------FUNCTION THAT COMPLETES A SUSPENDED TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//
function endSuspendedTicket($ticket_id){//first check if item is still suspended and unfinished
  global $conn;
  $participation='Supervised';
  $admin=callUser();
  if(checkUserPrivilege()!='admin' || !isSuspended($ticket_id)){
    return false;
  }
  if(getRespondent($ticket_id)==callUser()){//ticket belongs to user
    $participation='Performed';
  }
  $updateQuery = "UPDATE tickets SET date_resumed=now(), date_fulfilled=now(), job_status='Closed', participation='$participation', approval_status='Approved' , admin='$admin'  WHERE ticket_id='$ticket_id'";
  if(mysqli_query($conn, $updateQuery)) return true;
  else return false;
}
//-------END OF FUNCTION THAT COMPLETES A SUSPENDED TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//

//-------FUNCTION THAT RETURNS A TICKET'S RESPONDENT, IF ANY-------//
  function getRespondent($ticket_id){
    $ticketDetails=getTicketDetails($ticket_id);
    if($ticketDetails['respondent']){
      return $ticketDetails['respondent'];
    }
    else return false;
  }
//-------END OF FUNCTION THAT RETURNS A TICKET'S RESPONDENT, IF ANY-------//

//-------FUNCTION THAT COMPLETES AN UNASSESSED TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//
function endUnassessedTicket($ticket_id){
  global $conn;
  $participation="Supervised";
  if(checkUserPrivilege()!='admin' || isAssessed($ticket_id)){
    return false;
  }
  if(getRespondent($ticket_id)==callUser()){//ticket belongs to user
    $participation='Performed';
  }
  $admin=(callUser());
  //$disp_admin=strtoupper(callUser());
  $updateQuery = "UPDATE tickets 
    SET date_assessed=now(), 
      date_fulfilled=now(), 
      assessment='CLOSED PREMATURELY', 
      job_description='CLOSED PREMATURELY', 
      job_details='CLOSED PREMATURELY', 
      job_status='Closed', 
      participation='$participation', 
      approval_status='Approved' , 
      admin='$admin' 
    WHERE ticket_id='$ticket_id'";
  if(mysqli_query($conn, $updateQuery)) return true;
  else return false;
}
//-------END OF FUNCTION THAT COMPLETES AN UNASSESSED TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//


//-------FUNCTION THAT COMPLETES AN ADMIN'S TICKET PREMATURELY - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//
function endAdminTicket($ticket_id,$belongsToUser){
  global $conn;
  if(checkUserPrivilege()!='admin' || isAssessed($ticket_id)){
    return false;
  }
  $admin=(callUser());
  $disp_admin=strtoupper(callUser());
  $updateQuery = "UPDATE tickets 
    SET date_assessed=now(), 
      date_fulfilled=now(), 
      assessment='CLOSED PREMATURELY', 
      job_description='CLOSED PREMATURELY', 
      job_details='CLOSED PREMATURELY', 
      job_status='Closed', 
      participation='Performed', 
      approval_status='Approved' , 
      admin='$admin' 
    WHERE ticket_id='$ticket_id'";
  if(mysqli_query($conn, $updateQuery)) return true;
  else return false;
}
//-------END OF FUNCTION THAT COMPLETES AN UNASSESSED TICKET - SHOULD ONLY EVER BE CALLED FROM AN ADMIN ACCOUNT-------//

//-------FUNCTION THAT CHECKS IF TICKET IS SUSPENDED-------//
function isSuspended($ticket_id){
  $ticketDetails=getTicketDetails($ticket_id);
  if(($ticketDetails['job_status'] == 'Suspended') && $ticketDetails['date_suspended']){
    return true;
  }
  else{
    return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET IS SUSPENDED-------//


//-------FUNCTION THAT CHECKS IF TICKET IS ASSESSED-------//
function isAssessed($ticket_id){
  $ticketDetails=getTicketDetails($ticket_id);
  if($ticketDetails['date_assessed']){
    return true;
  }
  else{
    return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET IS ASSESSED-------//


//-------FUNCTION THAT CHECKS IF TICKET IS FINISHED-------//
function isFinished($ticket_id){
  $ticketDetails=getTicketDetails($ticket_id);
  if($ticketDetails['date_fulfilled']){
    return true;
  }
  else{
    return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET IS FINISHED-------//


//-------FUNCTION THAT CHECKS IF TICKET IS APPROVED-------//
function isApproved($ticket_id){
  $ticketDetails=getTicketDetails($ticket_id);
  if($ticketDetails['approval_status']=='Approved'){
    return true;
  }
  else{
    return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET IS APPROVED-------//


//-------FUNCTION THAT CHECKS IF TICKET IS ARCHIVED-------//
function isArchived($ticket_id){
  $ticketDetails=getTicketDetails($ticket_id);
  if($ticketDetails['date_fulfilled'] && $ticketDetails['approval_status']=='Approved'){
    return true;
  }
  else{
    return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET IS ARCHIVED-------//


//-------FUNCTION THAT CHECKS IF TICKET HAS BEEN ACCEPTED-------//
function isAccepted($ticket_id){
  $ticketDetails=getTicketDetails($ticket_id);
  if($ticketDetails['date_accepted'] && $ticketDetails['respondent']){
    return true;
  }
  else{
    return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET HAS BEEN ACCEPTED-------//

//-------FUNCTION THAT CHECKS IF TICKET IS EXTANT-------//
function ticketExists($ticket_id){
  global $conn;
  $selectQuery = "SELECT ticket_id FROM tickets WHERE ticket_id='$ticket_id'";
  if($result=mysqli_query($conn,$selectQuery)){
    if(mysqli_num_rows($result)>0){//ticket exists
      return true;
    }
    else return false;
  }
}
//-------END OF FUNCTION THAT CHECKS IF TICKET IS EXTANT-------//

//-------FUNCTION THAT ESCALATES A TICKET-------//
function escalateTicket($ticket_id){
  if(!$ticket_id){
    return true;//argument is null or falsy - nothing to process
  }
  if(!ticketExists($ticket_id)){
    return false;//ticket does not exist or input is invalid
  }
  global $conn;
  $ticketDetails = getTicketDetails($ticket_id);//fetches ticket details and assigns them to an associative array named $ticketDetails
  $techUsername = getTechUsername($ticketDetails['respondent']);

$participation="";//code block pushes participation into the query, if set
if(!$ticketDetails['participation']){
  $participation=', participation="Supervised"';
}
else{
  $participation=', participation="'.$res["participation"].'"';
}

$resumeString="";
if($ticketDetails['date_suspended'] && !$ticketDetails['date_resumed']){//ticket was suspended but not resumed
  $resumeString="date_resumed=now(),";
}

//below code block sets date_fulfilled, job_status in the 'tickets' table
$queryString = 'UPDATE tickets SET date_fulfilled=now(), job_status="UnClosed - Escalated", '.$resumeString.' approval_status="Approved", admin="'.callUser().'"'.$participation.' WHERE ticket_id="'.$ticket_id.'"';
    if (mysqli_query($conn, $queryString)) { //query passes, gate is cleared
        toConsole("Ticket values successfully updated");
        $ticketUpdateCheck = true;
    } 
    else {    //report sql error
        echo '<script>console.log("Ticket values were not successfully updated - '.addslashes(mysqli_error($conn)).'");</script>';
        echo "<script>console.log('".$queryString."')</script>";
    }
//end of code block that sets date_fulfilled, job_status in the 'tickets' table

//below code block creates a new copy of the escalated ticket, this time with slightly different parameters
  $new_id = getEscalatedId($ticket_id);
  $employee_type = $ticketDetails['employee_type'];
  $client_name = $ticketDetails['client_name'];
  $office = $ticketDetails['office'];
  $concern = $ticketDetails['concern'];
  $concern_details = $ticketDetails['concern_details'];
  $client_first_name = $ticketDetails['client_first_name'];
  $client_last_name = $ticketDetails['client_last_name'];
  $remarks = $ticketDetails['remarks'];//this bit and the reference to it in the query below causes <remarks> to persist between escalations -> ask whether this should be enabled

      $newTicketQuery = 'INSERT INTO tickets (ticket_id,employee_type,client_name,office,concern,concern_details,approval_status,job_status,client_first_name, client_last_name, remarks) VALUES ("'.$new_id.'","'.$employee_type.'","'.$client_name.', '.callUser().'","'.$office.'","'.$concern.'","'.$concern_details.'","Not Approved","Escalated","'.$client_first_name.'","'.$client_last_name.'","'.$remarks.'");'; //query string to create entry in the ticket table - probs more efficient to just use joins for the extra details
      if (mysqli_query($conn, $newTicketQuery)) {
      //echo $qString;    
          $logString=escapeString("Ticket escalated with the following parameters: ".$employee_type.", ".$client_name.", ".$office.", ".$concern);
          logChange(calluser(), $new_id, $logString);


          if($ticketDetails['date_suspended'] && !$ticketDetails['date_resumed'] && (checkSuspendedTicket($techUsername)==$ticket_id)){//if ticket is still suspended
            dropSuspendedTicket($techUsername);
            endSuspendedTicket($ticket_id);
          }

          if(!isAssessed($ticket_id)){//if ticket is still unassessed
            endUnassessedTicket($ticket_id);
          }

            dropTicket($techUsername);

          return true;
      } 
      else {    //report sql error
          return false;
      }
//end of code block that creates a new copy of the escalated ticket
}
//-------END OF FUNCTION THAT ESCALATES A TICKET-------//


//-------FUNCTION THAT SETS AN INPUT CONTROL'S PARENT FORM--------//
  function setForm($object,$form){
    echo "
      <script>
        document.getElementById('$object').setAttribute('form','$form');
      </script>
    ";
  }
//-------END OF FUNCTION THAT SETS AN INPUT CONTROL'S PARENT FORM--------//

//-------FUNCTION THAT CREATES A COMBO BOX--------//
  function createComboBox($name,$value,$field){
    $listName=$name.'Datalist';
    echo "<input type='text' autocomplete='off' name='$name' id='$name' list='$listName' class='form-control' value='$value'>";
    
    $values=retrieveOptionsNum($field,true);
    //--------------------MODULE TO OUTPUT A DATALIST--------------------//
      $selectString = "<datalist id='$listName'>";                     //start of datalist
          for ($counter = 0 ; $counter < count($values) ; $counter++){
                $selectString .='<option value="';                      //start of option
                $selectString .=$values[$counter].'" ';                 //inserts value of option
                $selectString.='>'.$values[$counter].'</option>';       //end of option     
          }
          $selectString.= '</datalist>';                                //end of datalist
          echo $selectString;
    //----------------END OF MODULE TO OUTPUT A DATALIST-----------------//
  }
//-------END OF FUNCTION THAT CREATES A COMBO BOX--------//


//-------FUNCTION THAT CHECKS IF INPUT IS AN OPTION OF GIVEN FIELD-------//
  //returns true if yes, false if no
  function isAnElement($value, $field){    
    global $conn;    
    $values=array();
    $optionQuery = "
      SELECT value
      FROM field_values 
      WHERE field = '".$field."'
      "; 
    $result=mysqli_query($conn,$optionQuery);
    if(mysqli_num_rows($result)==0) return false;//not an element of the field set because field set is empty or doesn't exist
    else{
      while($res=mysqli_fetch_array($result,MYSQLI_ASSOC)){
        array_push($values,$res['value']);
      }
      if(in_array($value,$values)){
        return true;
      }
      else{
        return false;
      }
    }
  }
//-------END OF FUNCTION THAT CHECKS IF INPUT IS AN OPTION OF GIVEN FIELD-------//


//-------FUNCTION THAT RETURNS AN ARRAY CONTAINING THE ticket_ids OF ALL SUSPENDED TICKETS ASSIGNED TO GIVEN TECH-------//
  function getSuspendedTickets($name){
    global $conn;
    $selectQuery="
      SELECT ticket_id
      FROM tickets 
      WHERE 
        respondent='$name'
        AND job_status='Suspended'
    ";
    $values=array();
    if($result = mysqli_query($conn,$selectQuery)){
      if(mysqli_num_rows($result)==0){
        toConsole('No suspended tickets');
        return $values;
      }
      else{
        while($res=mysqli_fetch_array($result,MYSQLI_ASSOC)){
          array_push($values,$res['ticket_id']);
        }
        return $values;
      }
    }
    else{
      checkSQLError();
    }
  }
//-------END OF FUNCTION THAT RETURNS AN ARRAY CONTAINING THE ticket_ids OF ALL SUSPENDED TICKETS ASSIGNED TO GIVEN TECH-------//


?>

<!--should this style snippet really be here?-->
<style>
  @media print {
         .printHide, #selectStyle {
          display: none !important;
         }
     
}
}
</style>
