<?php include 'misc/config.php';?>
<div style="color:white;">
<br><br><br><br>


<!--MODAL USED TO EDIT TECH FIELDS-->
<div class="modal fade" id="editTech">
  <div class="modal-dialog">
    <div class="modal-content">
      <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title"><span id='techIdentity'>Sample Tech Name</span></h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>  
      <!-- Modal body -->
        <form method="post" action="edittech.php">
        <div class="modal-body">
          	<div class="form-group">
              	<label title="Status" data-title="Status" style="font-size: 20px;">Status</label>
              	<!--MAKE THIS TABLE-BASED-->
              	<?php 
              		//createComboBox('status','','tech_status');
              		outputSelect('status','',retrieveOptions('tech_status',true),false); 
              	?>
      		</div>
       		<br>
          	<div class="form-group">
              	<label title="Designation" data-title="Designation" style="font-size: 20px;">Designation</label>
              	<!--MAKE THIS TABLE-BASED-->
              	<?php createComboBox('designation','','designation'); ?>
      		</div>
        </div>
        <!-- Modal footer -->
        <div class="modal-footer">
          <input type="hidden" name="user" id="user">
          <input type="hidden" name="privilege" id="privilege">
          <?php createHiddenInput('trail',getUrl('BASE'));?>
          <input type="submit" class="btn btn-primary mr-auto" name="Submit" style="width: 100%;" value="Update Tech Details">
          <button class="btn btn-outline-danger" data-dismiss="modal" style="width: 100%;">Cancel</button>
        </div>
      </form>
    </div>
  </div>
</div>
<!--END OF MODAL USED TO EDIT TECH FIELDS-->

<!--
	table that displays techs
	relevant fields (name, status, designation, privilege?)
-->

<?php

$selectQuery = "
	SELECT 
		employee_name, user_type, status, designation
	FROM tech_credentials
	WHERE true
	ORDER BY employee_name
";

$result = mysqli_query($conn, $selectQuery);
$outputString = "";

$rows=mysqli_num_rowS($result);
if($rows==0){
	$outputString.="<tr><td colspan='100%' style='text-align:center;'>Nothing to display</td></tr>";
}
else{
	while($res=mysqli_fetch_array($result,MYSQLI_ASSOC)){
		$outputString.="<tr>";
    $outUser=$res['employee_name'];
    $outType=$res['user_type'];
    $outStatus=$res['status'];
    $outDesignation=$res['designation'];
		foreach($res as $key=>$value){
			$editString='';
			if(!$value){
				$item="None";
			}
			$outputString.="<td style='text-align:center;text-overflow: ellipsis;'>$value</td>";
		}
		$outputString.="<td style='text-align:center;'><button class='btn btn-info' data-toggle='modal' data-target='#editTech' onclick=\"setEditModalValues('$outUser','$outStatus','$outDesignation','$outType')\"><i class='fa fa-pencil-alt outline'></i></button></td>";
		$outputString.="</tr>";
	}
}
?>
<center>

<span style='font-size:24;'><b>User Management</b></span>
<br><br>

<table>
	<tr style='text-align: center;'>
		<th style='width:100px'>User</th>
		<th style='width:100px'>User Type</th>
		<th style='width:100px'>Status</th>
		<th style='width:100px'>Designation</th>
		<th style='width:100px'>Action</th>
	</tr>
	<?php
		echo $outputString;
	?>
</table>
</center>
<br><br><br>
</div><!--end of div used to contain website-->


<script>  

function setEditModalValues(user,status,designation,privilege){
  console.log('user:'+user);
  console.log('status:'+status);
  console.log('designation:'+designation);
  console.log('privilege:'+privilege);
  document.getElementById('techIdentity').innerHTML=user;
  document.getElementById('user').value=user;
  document.getElementById('status').value=status;
  document.getElementById('designation').value=designation;
  document.getElementById('privilege').value=privilege;
}

</script>