<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<!DOCTYPE html>
<html lang="en">
<head>  
  <title>IT Ticketing System</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/createticket.css">
  <link rel="stylesheet" type="text/css" href="css/darkmode.css">
</head>
<body>
<div class="container" style="max-width: 600px;">
  <br>
  <div class="lineBorder">
    <!--START OF MODULE FOR TICKET DISPLAY (ADMIN DISPLAY)-->
<form class="login100-form validate-form" action='sendticket.php' method='post'>
<center>
  <img src="img/ITDOLogo.png" width="40%">
  <br><br>
  <h4>Create Ticket</h4>
</center>
<br>
    <div class="form-group inputStyle">
      <label for='office' title='Office' data-title='Office'>Office</label>
        <?php
          $valueArray = retrieveOptions('office',true);
          outputSelect('office','',$valueArray,true);
        ?>
    </div>
    <div class="form-group">
      <label>Employee Type </label>
        <br>  
          <div class="btn-group btn-group-toggle" data-toggle="buttons" style="width: 100% !important;">
              <label for='regular'  class="btn btn-outline-primary ">
                  <input type="radio" class="custom-control-input" required id="regular" name="employee_type" value="regular"/>Regular
              </label>
              <label for='Job Order' class="btn btn-outline-primary">
                <input type="radio" class="custom-control-input" required id="Job Order" name="employee_type" value="Job Order"/>JO
              </label>
          </div>
    </div>
    <!--<div class="form-group" id="employeenumber_select">
      <label for='employeenumber'  title='Enter your Employee Type' data-title='Employee Type'>Employee Type</label>
          <input style="text-transform: uppercase;" type="text" required autocomplete="off" id='employeenumber' class="form-control" name="employeenumber"/>
        </div>-->
        <div class="row">
          <div class="col-md-6">
            <div class="form-group">
              <label for='employeename' title='Name' data-title='Name'>Last Name</label>
              <input type="text" class="form-control inputStyle" required autocomplete="off" required name='last_name'>
            </div>
          </div>
          <div class="col-md-6">      
            <div class="form-group">
              <label for='employeename' title='Name' data-title='Name'>First Name</label>
              <input type="text" class="form-control inputStyle" required autocomplete="off" required name='first_name'>
            </div>  
          </div>
        </div>      
    <div class="form-group" id="concernDiv">
      <label for='concernDiv' title="Concern" data-title="Concern">Concern</label>
          <?php
            $valueArray = retrieveOptions('concern',true);
            outputSpecialSelect('concern','',$valueArray,false,'updateDetailsBox(this.options[this.selectedIndex].getAttribute("data-option-description"))');
          ?>
          <!--
          <center><div id="concernTooltip" style="text-align:center; display:none;">A tooltip will appear here with solutions <br>to common problems in this category</div></center>
-->
          <br>

      <textarea class="form-control inputStyle" id='concern_details' name='concern_details' onkeyup="textAreaAdjust(this)" required name='concern_details'></textarea>
        <!--<label id='concernDetailsLabel' for='concern_details' title="Describe your tech-related issue here" data-title="Concern Details">
            </label>-->
    </div>
        <input type='submit' class="btn btn-default sendTicketBtn" value='<?php if(!isset($_SESSION['userType'])) echo "Send"; else echo "Send";?> Ticket' name='Submit' class="form-submit btnClass" value="Send Ticket"/>
  </form>
</div>
</div>
<br>
</div>
</body>

<script>

var employeeNumberStorage = "";

function isNumberKey(evt){//checks whether the key pressed is a number
  var charCode = (evt.which) ? evt.which : event.keyCode
  if (charCode > 31 && (charCode < 48 || charCode > 57))
      return false;
  return true;
}
function textAreaAdjust(o) {
  o.style.height = "1px";
  o.style.height = (25+o.scrollHeight)+"px";
}

function updateDetailsBox(placeHolderFragment){
  console.log("select value changed");
  document.getElementById("concern_details").placeholder="Please describe your issue related to "+placeHolderFragment+".";
  textAreaAdjust(document.getElementById("concern_details"));
  document.getElementById("concernTooltip").style = "block";
  //document.getElementById("concernDetailsLabel").title="Please describe your issue related to "+placeHolderFragment+".";
}

function checkEmployeeType(element){
  if(element.value == "regular"){
    console.log("Regular selected");
    document.getElementById("employeenumber").value=employeeNumberStorage;
    document.getElementById("employeenumber").required=true;
    document.getElementById("employeenumber").disabled=false;
    employeenumber_select.style = "text-align:center;";
  }
  else{
    console.log("JO selected");
    employeeNumberStorage=document.getElementById("employeenumber").value;
    document.getElementById("employeenumber").value="";
    document.getElementById("employeenumber").required=false;
    document.getElementById("employeenumber").disabled=true;
    employeenumber_select.style = "display: none;";
  }
}

</script>
</html>