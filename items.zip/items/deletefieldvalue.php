<?php include 'misc/config.php';?>
<?php
	echo "<br><br><br><br><br><center>CONFIRM DELETION</center><br><br><br>";
	global $conn;
	if(!checkPost('Submit')){
		//shoot($user);
		redirect('index.php');
	}
	$field=checkPost('delete_field');
	$value=checkPost('delete_storedValue');
	$description=checkPost('delete_storedDescription');
	$trail=checkPost('trail');

		$deleteQuery="DELETE FROM field_values WHERE field='$field' AND value='$value'";

	print $deleteQuery;
	if(mysqli_query($conn, $deleteQuery)){
		toConsole("Field:Value ".$value.":".$description." deleted");
		if(!$description){
			$logString = "Deleted item <$value - no description> from $field list";
		}
		else{
			$logString = "Deleted item <$value - $description> from $field list";
		}
		
		logFieldValueChange(callUser(),$logString);

		if($trail){
			redirect($trail);
		}
		else{
			redirect('fieldmanagement.php');
		}
	}
?>
<script>  
</script>