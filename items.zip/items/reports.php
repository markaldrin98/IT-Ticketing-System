
<!-- 

NOTE: To fix the print, go to "More Settings", uncheck the Headers and Footers at "Options" and set the "Margins" to Default 

-->

<body onload="loadingScreen()">
		<script>
			function endChanged(){
			startDate = document.getElementById('startDate');
			endDate = document.getElementById('endDate');
				startDate.max=endDate.value;
				if(startDate.value > endDate.value){
					startDate.value = endDate.value;
				}
			}
			function startChanged(){
			startDate = document.getElementById('startDate');
			endDate = document.getElementById('endDate');
				endDate.min=startDate.value;
				if(endDate.value < startDate.value){
					endDate.value = startDate.value;
				}
			}
		</script>

<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">


<?php include 'misc/config.php';


    if(checkUserPrivilege()!="admin"){
      redirect('index.php');
    }
?>
<div style="margin-top:70px; max-width: 1300px;" class="container">
<center>
<div id="selectStyle">
<div class="form-group" style="max-width: 800px;" >
	<!--<h5 class="whiteText">NOTE: To fix the print, go to "More Settings", uncheck the Headers and Footers and set the "Margins" to Default.</h5>-->
		<br>

	<form method="get" id="inputForm" action="reports.php"><!--FORM THAT CONTROLS THE VALUES THE PROGRAM QUERIES AGAINST-->
	<select id="reportSelect" name="reportSelect" class="btn btn-primary" onchange="showReportDiv(this)"" style="margin-bottom: 10px; font-size: 20px;">
		<option value="">-select a report to display-</option>
		<option value="admin">Admin Technical Assistance</option>
		<option value="techservice_count">Technician Service Record - Service Count</option>
		<option value="escalation_count">Technician Service Record - Escalation Count</option>
		<option value="techservice_time">Technician Service Record - Assessment Time</option>
		<option value="techservice_job_time">Technician Service Record - Job Time</option>
		<option value="servicelog">Service Rendered Log</option>
		<option value="concernlog">Concern Log</option>
		<option value="officelog">Office Log</option>
		<option value="deviceCountDisplay">Device Count</option>
		<option value="changelogDisplay">Change Logs</option>
		<!--<option value="changelogs">Changelogs</option>-->
	</select>

	<?php
		$reportSelect=checkGet('reportSelect');
		$adminSelect=checkGet('adminSelect');
		$changelogSelect=checkGet('changelogSelect');
		echo "
			<script>
				var selectedItem='';
				reportSelect='$reportSelect';
				adminSelect='$adminSelect';
				changelogSelect='$changelogSelect';
			</script>";
		/*if(checkGet('reportSelect')){
			echo "
				<script>
					var val = '".checkGet('reportSelect')."';
					var sel = document.getElementById('reportSelect');
					  var opts = sel.options;
					  for (var opt, j = 0; opt = opts[j]; j++) {
					    if (opt.value == val) {
					      sel.selectedIndex = j;
					      break;
					    }
					  }
				</script>
			";
		}*/
	?>

	<div name='rangeSelect'><!--start of date select-->

	<?php

		$maxDate = date('Y-m-d');
		toConsole("Max date on start: ".$maxDate);
		$minDate = '2019-01-01';
		toConsole("max".$maxDate."min".$minDate);

		$startDate=checkGet('startDate');
		$endDate=checkGet('endDate');

		if(!$endDate){
			$endDate=$maxDate;
		}

		if(!$startDate){
			$startDate=$minDate;
		}

		toConsole("Max date after checks: ".$maxDate);

            echo "<div class='input-group mb-3'>";
                echo "  
                    <div class='input-group-prepend'>
                        <span class='input-group-text'>From:</span>
                    </div>
                <input type='date' id='startDate' class='form-control' name='startDate' value='$startDate' max='$endDate' onchange='startChanged()'>
                ";

                echo "
                    <div class='input-group-prepend'>
                        <span class='input-group-text'>To:</span>
                    </div>
                    <input type='date' id='endDate' class='form-control' name='endDate' value='$endDate' min='$minDate' max='$maxDate' onchange='endChanged()'>
                    ";
                echo "
                    <div class='input-group-prepend'>";
            	echo "<center>
            	<input type='submit' name='Submit' value='Change Date' class='btn btn-primary'>
            	</center>";
            echo "</div>";
         ?>
	</div><!--end of date select-->
	<?php
		/*this section contains vanilla year select, disabled due to request by admin to be able to output data from specific date spans
		<select id="yearSelect" name="yearSelect" onchange='this.form.submit()' class='btn btn-primary'>
			<?php
			$year=2019;
			if($year=checkGet('yearSelect')){
				//do nothing
			}
			else{
				$year = date('Y');
			}
				for($defaultYear=2019;$defaultYear<=date('Y');$defaultYear++){
					if($year==$defaultYear){
						echo "<option value='$defaultYear' selected>$defaultYear</option>";
					}
					else{
						echo "<option value='$defaultYear'>$defaultYear</option>";
					}
				}
			?>
		</select>*/
		?>
	</form>
</div>
</div>	<!--THIS IS THE START OF A REPORT BLOCK-->
<div class="form-group">
	<div id="admin" class="reportDiv">
		

	<?php
		$valueArray = retrieveEmployees('admin',true);
		$formValue='';
		if(checkGet('adminSelect')){
			$formValue=checkGet('adminSelect');
		}
		outputFullerSelect("adminSelect","$formValue",$valueArray,false,'-select an admin-',false,'showTable');
		setForm("adminSelect","inputForm");

		$activetableName="admin";
		foreach($valueArray as $name => $username){
			$activeTableName=str_replace(' ', '', $name);
			$nameDisplay=strtoupper($name);
			echo "<div id='$activeTableName' class='activeTableDiv'>";
			echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			
			echo "<table name='$activeTableName' id='$activeTableName'>";
			echo "<tr style='text-align:center; font-weight: bold;'><td colspan='100%'>ADMIN TECHNICAL ASSISTANCE - $nameDisplay</td></tr>";
			outputHeadRow("participation");			
			outputDataRow("participation","tickets",$name,$startDate,$endDate);

			echo "</table></div>";
		}
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->
</div>


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="techservice_count" class="reportDiv">
		
	<?php
		$valueArray = retrieveEmployees('tech',true);
		$activeTableName="techservice_count";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='$activeTableName'>";
			
			echo "<table name='$activeTableName' id='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>TECHNICIAN SERVICE RECORD - SERVICE COUNT</td></tr>";
			outputHeadRow("respondent");	
			foreach($valueArray as $name => $username){		
				outputTechDataRow($name,$startDate,$endDate);
			}

			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="techservice_time" class="reportDiv">
		
	<?php
		$valueArray = retrieveEmployees('tech',true);
		$activeTableName="techservice_time";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='$activeTableName'>";
			echo "<table name='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>TECHNICIAN SERVICE RECORD - ASSESSMENT TIME</td></tr>";
			outputHeadRow("respondent");	
			foreach($valueArray as $name => $username){		
				outputTechTimeDataRow($name,$startDate,$endDate,'assessment');
			}

			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="techservice_job_time" class="reportDiv">
		
	<?php
		$valueArray = retrieveEmployees('tech',true);
		$activeTableName="techservice_job_time";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='$activeTableName'>";
			echo "<table name='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>TECHNICIAN SERVICE RECORD - JOB TIME</td></tr>";
			outputHeadRow("respondent");	
			foreach($valueArray as $name => $username){		
				outputTechTimeDataRow($name,$startDate,$endDate,'job');//this part was likely failing due to integer-NULL data type errors
			}

			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="escalation_count" class="reportDiv">
		
	<?php
		$valueArray = retrieveEmployees('tech',true);
		$activeTableName="tech_escalation_count";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='$activeTableName'>";
			echo "<table name='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>TECHNICIAN SERVICE RECORD - ESCALATION COUNT</td></tr>";
			outputHeadRow("respondent");	
			foreach($valueArray as $name => $username){		
				outputEscalationCount($name,$startDate,$endDate);
			}
			
			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="servicelog" class="reportDiv">
		
	<?php
		$valueArray = retrieveActiveValues('job_description',$startDate,$endDate);
		$activeTableName="servicelog";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='$activeTableName'>";
			echo "<table name='$activeTableName' id='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>SERVICE RENDERED LOG</td></tr>";
			outputHeadRow("job_description");	
			foreach($valueArray as $name){		
				outputGeneralDataRow($name,$startDate,$endDate,'tickets','job_description',$name);//arguments:($name,$year,$targetTable,$targetField,$targetValue)
			}

			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="concernlog" class="reportDiv">
		
	<?php
		$valueArray = retrieveActiveValues('concern',$startDate,$endDate);
		$activeTableName="concernlog";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='activeTableName'>";
			echo "<table name='$activeTableName' id='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>SERVICE RENDERED LOG</td></tr>";
			outputHeadRow("concern");	
			foreach($valueArray as $name){		
				outputGeneralDataRow($name,$startDate,$endDate,'tickets','concern',$name);//arguments:($name,$year,$targetTable,$targetField,$targetValue)
			}

			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="officelog" class="reportDiv">
		
	<?php
		$valueArray = retrieveActiveValues('office',$startDate,$endDate);
		$activeTableName="officelog";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
			echo "<div class='' id='$activeTableName'>";
			echo "<table name='$activeTableName' id='$activeTableName'>";
			echo "<tr class='styleHeader'><td colspan='100%'>SERVICE RENDERED LOG</td></tr>";
			outputHeadRow("office");	
			foreach($valueArray as $name){		
				outputGeneralDataRow($name,$startDate,$endDate,'tickets','office',$name);//arguments:($name,$year,$targetTable,$targetField,$targetValue)
			}
			echo "</table></div><br><br>";
	?>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->		

<?php
?>


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="changelogDisplay" class="reportDiv">
	<?php
		$valueArray = array('ticket_changelog'=>0,'device_changelog'=>0,'field_values_changelog'=>0);

		$formValue='';
		if(checkGet('changelogSelect')){
			$formValue=checkGet('changelogSelect');
		}
		outputFullerSelect("changelogSelect","$formValue",$valueArray,false,'-select a changelog-',false,'showTable');
		//$activeTableName="changelogs";
		setForm("changelogSelect","inputForm");
		
		retrieveSelectedChangelog("ticket_changelog",$startDate,$endDate);
		retrieveSelectedChangelog("device_changelog",$startDate,$endDate);
		retrieveSelectedChangelog("field_values_changelog",$startDate,$endDate);
	?>
	<br><br>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->


	<!--THIS IS THE START OF A REPORT BLOCK-->
	<div id="deviceCountDisplay" class="reportDiv">
	<?php

		$values = getOfficesWithDevices();
		if(!$values){
			$values = array();
		}

		$activeTableName="deviceCount";
		echo "<a onclick='exportF(this)' data-target='$activeTableName' class='btn btn-primary printHide'>Export to excel</a>
			<br><br>";
		echo "<div class='' id='$activeTableName'>";
		echo "<table name='$activeTableName' id='$activeTableName'>";
		echo "<tr class='styleHeader'><td colspan='100%'>Device Count Per Office</td></tr>";
			echo "<tr>";
				echo "<td><b>OFFICE</b></td><td>Count</td>";
			echo "</tr>";
		foreach($values as $value){//outputs device count per office
			$count = getDeviceCount($value);
			echo "<tr>";
				echo "<td>$value</td><td>$count</td>";
			echo "</tr>";			
		}

		echo "<tr>";// code block outputs total number of registered devices
			$total='No devices registered';
			$countQuery = "
				SELECT COUNT(*) as count
				FROM device_list
				WHERE 1;
				";
			if($result = mysqli_query($conn, $countQuery)){
				if(mysqli_num_rows($result)>0){
					$res = mysqli_fetch_array($result);
					$total=$res['count'];
				}
			}
			echo "<td><b>TOTAL</b></td><td>$total</td>";
		echo "</tr>";
		
		echo "</table></div><br><br>";
	?>
	<br><br>
	</div>
	<!--THIS IS THE END OF A REPORT BLOCK-->		


</center>
</div>
</div>
<link rel="stylesheet" type="text/css" href="css/reports.css">


<script>  

	function hideReportDivs(){
	  console.log("Hiding report divs");
	  reportDivs = document.getElementsByClassName('reportDiv');
	  for(counter=0;counter<reportDivs.length;counter++){
	    reportDivs[counter].style.display='none';
	  }
	}

	function hideTables(){
	  console.log("Hiding tables");
	  tableElements = document.getElementsByTagName('table');
	  for(counter=0;counter<tableElements.length;counter++){
	    tableElements[counter].style.display='none';
	  }
	}

	function hideTableDivs(){
	  console.log("Hiding tables");
	  tableElements = document.getElementsByClassName('activeTableDiv');
	  for(counter=0;counter<tableElements.length;counter++){
	    tableElements[counter].style.display='none';
	  }

	}

	function showReportDiv(tableSelect){
	  console.log('Showing: '+tableSelect.value);
	  hideReportDivs();
	  document.getElementById(tableSelect.value).style.display='block';
	}

	function showTable(tableSelect){
	  hideTableDivs();
	  selectedTable = tableSelect.value.split(" ").join("");;
	  console.log("selected table: "+selectedTable);
	  document.getElementById(selectedTable).style.display='block';
	  //document.getElementById('adminReportButton').style.display='block';
	}

/*
	function requestPrint(buttonObject){
		console.log("button object: "+buttonObject.name);
		console.log(buttonObject.dataset.target);
		console.log("button target: "+buttonObject.dataset.target);
		var divToPrint=document.getElementById(buttonObject.dataset.target);
		console.log(divToPrint);
		newWin= window.print();
		newWin.document.write(divToPrint.outerHTML);
		window.close();
	}	
	*/
	function exportF(elem) {
	  var table = document.getElementById(elem.dataset.target);
	  var html = table.outerHTML;
	  var url = 'data:application/vnd.ms-excel,' + escape(html); // Set your html table into url 
	  elem.setAttribute("href", url);
	  elem.setAttribute("download", "export.xls"); // Choose the file name
	  return false;
	}

</script>

<script>//executes the following functions after page finishes loading

	function executeAfterLoad(){
		hideTableDivs();
		hideReportDivs();
		setSelectedOption('reportSelect',reportSelect);
		showReportDiv(document.getElementById('reportSelect'));
		if(reportSelect=='changelogDisplay' && changelogSelect){
			showTable(document.getElementById('changelogSelect'));
		}
		if(reportSelect=='admin' && adminSelect){
			showTable(document.getElementById('adminSelect'));
		}
	}

	if(window.attachEvent) {
		window.attachEvent('onload', executeAfterLoad);
	} 
	else {
	    if(window.onload) {
	        var curronload = window.onload;
	        var newonload = function(evt) {
	            curronload(evt);
	            executeAfterLoad(evt);
	        };
	        window.onload = newonload;
	    } 
	    else {
	        window.onload = executeAfterLoad;
	    }
	}

</script>

<head>
	<link rel="stylesheet" type="text/css" href="css/reports.css">
</head>