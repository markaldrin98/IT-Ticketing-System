<body onload="loadingScreen()">
<div id="loader"></div>
<div style="display:none;" id="myDiv" class="animate-bottom">
<?php include 'misc/config.php';?>
<?php

$logString="";
if(checkPost('Submit')) {//checks if a form was submitted
    if(($field=checkPost('field')) && $value=checkPost('new_value')){//if appropriate values have been posted     
        $field=escapeString($field);     
        $value=escapeString($value);  
        if($description=checkPost('new_description')){   
            $description=escapeString($description);  
            $insertQuery="INSERT INTO field_values VALUES('$field','$value','$description')";
            $logString = "Created new entry [$field - $value - $description]";
        }
        else{
            $insertQuery="INSERT INTO field_values VALUES('$field','$value',NULL)";   
            $logString = "Created new entry [$field - $value - NULL]";         
        }
        if(mysqli_query($conn,$insertQuery)){
            logFieldValueChange(callUser(),$logString);
            if($trail=checkPost('trail'))redirect($trail);
            else redirect('managefieldvalues.php');
        }
    }
}
else{//user arrived here via unintended channels and should be shot
    //shoot($user);
    redirect('index.php');
}                  
?>

</div>