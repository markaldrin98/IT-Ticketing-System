<?php include 'misc/config.php';?>
<?php
	echo "<br><br><br><br><br><center>CONFIRM UPDATE</center><br><br><br>";
	global $conn;
	if(!checkPost('Submit')){
		//shoot($user);
		redirect('index.php');
	}
	printPost();
	$field=checkPost('edit_field');
	$value=checkPost('edit_storedValue');
	$description=checkPost('edit_storedDescription');
	$trail=checkPost('trail');

	$new_value=checkPost('value');
	$new_description=checkPost('description');

	if(!$new_description){
		$updateQuery="UPDATE field_values SET value='$new_value', details=NULL WHERE field='$field' AND value='$value'";
	}
	else{
		$updateQuery="UPDATE field_values SET value='$new_value', details='$new_description' WHERE field='$field' AND value='$value'";
	}
	//print $updateQuery;

	$refreshQuery="UPDATE tickets SET $field='$new_value' WHERE $field='$value'";//this query updates tickets to reflect new values

	if(mysqli_query($conn, $updateQuery) && mysqli_query($conn,$refreshQuery)){
		//$logString = "Deleted item <$value - $description> from $field list";
		if(!$description)$description="no description";
		if(!$new_description)$new_description="no description";
		$logString = "Changed $field : $value : $description to $field : $new_value : $new_description";
		logFieldValueChange(callUser(),$logString);

		if($trail){
			redirect($trail);
		}
		else{
			redirect('fieldmanagement.php');
		}
	}
?>
<script>  
</script>